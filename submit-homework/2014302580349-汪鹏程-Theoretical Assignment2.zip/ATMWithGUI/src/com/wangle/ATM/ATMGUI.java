package com.wangle.ATM;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.text.JTextComponent;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;

public class ATMGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel content;
	private RedirectPrintStream out;

	private ATM atm;
	private String value;
	private String display;

	public static void main(String[] args){
		ATMGUI atmGUI=new ATMGUI();
		atmGUI.setVisible(true);
		atmGUI.getAtm().run();
	}

	public ATM getAtm() {
		return atm;
	}

	public ATMGUI() {
		atm=new ATM();
		value="";

		setTitle("So-called ATM");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		//根据屏幕大小设置窗口大小并且居中显示
		Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();
		int width=(int) screen.getWidth();
		int height=(int)screen.getHeight();
		setBounds(width*3/8, height/4, width/4, height/2);

		//将整个面板分为上下两个部分
		content= new JPanel();
		content.setLayout(new GridLayout(2,1));

		setContentPane(content);

		JScrollPane sp=new JScrollPane();
		//上方是个文本域显示重定向的输出信息
		JTextArea message=new JTextArea();
		//不可编辑
		message.setEditable(false);
		message.setBackground(new Color(30, 144, 255) );
		sp.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
		//将System.out重定向到此
		out=new RedirectPrintStream(System.out,message);
		System.setOut(out);

		sp.setViewportView(message);
		content.add(sp);

		//将display设置为此时文本域的文本值
		display=message.getText();

		//下方也是个面板，网格布局，适合数字键盘的排列，4行3列
		JPanel keys=new JPanel();

		keys.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));

		keys.setLayout(new GridLayout(4,3));
		MyMouseListener listener=new MyMouseListener(value,display,message,atm);
		for(int i=1;i<=12;i++){
			JButton button=null;
			if(i==10){
				button=new JButton("←");
			}
			else if(i==11){
				button=new JButton(new Integer(0).toString());
			}
			else if(i==12){
				button=new JButton("Enter");
			}
			else{
				button=new JButton(new Integer(i).toString());
			}
			button.setFont(new Font("宋体", Font.BOLD, 18));
			button.setBackground(new Color(30, 144, 255));
			button.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
			button.addMouseListener(listener);
			keys.add(button);
		}
		content.add(keys);
	}


	//按钮监听器
	public class MyMouseListener implements MouseListener{
		private String value;
		private String display;
		private JTextArea textArea;
		private ATM atm;
		public MyMouseListener(String value,String display,JTextArea textArea,ATM atm){
			this.value=value;
			this.display=display;
			this.textArea=textArea;
			this.atm=atm;
		}
		//点击事件
		@Override
		public void mouseClicked(MouseEvent e) {
			JButton bt=(JButton) e.getComponent();
			bt.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
			bt.setBackground(new Color(30, 144, 255));
			//获取点击的按钮的字面值
			String val=bt.getText();
			//正则匹配，如果是数字，则转化为数字
			Pattern pattern=Pattern.compile("\\d");
			Matcher m=pattern.matcher(val);
			if(m.find()){
				value=value+val;
				display=textArea.getText();
				textArea.setText(display+val);
			}
			if("←".equals(val)){
				display=textArea.getText();
				if(value.length()!=0){
					value=value.substring(0,value.length()-1);
					textArea.setText(display.substring(0, display.length()-1));
				}
			}
			if("Enter".equals(val)){
				atm.keypad.setInput(Integer.parseInt(value));
				atm.keypad.setEndInput(true);
				value="";
			}
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			JButton bt=(JButton) e.getComponent();
			bt.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
			bt.setBackground(new Color(60, 164, 255));
		}
		@Override
		public void mouseExited(MouseEvent e) {
			JButton bt=(JButton) e.getComponent();
			bt.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
			bt.setBackground(new Color(30, 144, 255));
		}
		@Override
		public void mousePressed(MouseEvent e) {
			JButton bt=(JButton) e.getComponent();
			bt.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
			bt.setBackground(new Color(30, 144, 255));
		}
		@Override
		public void mouseReleased(MouseEvent e) {
			JButton bt=(JButton) e.getComponent();
			bt.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
			bt.setBackground(new Color(30, 144, 255));
		}
	}

	//重定向的System.out
	public class RedirectPrintStream extends PrintStream{

		private JTextComponent text;									//重定向到的文本组件
		private StringBuffer sb = new StringBuffer();		//文本内容

		public RedirectPrintStream(OutputStream out) {
			super(out);
		}
		public RedirectPrintStream(OutputStream out, JTextComponent text){
			super(out);
			this.text = text;
		}

		//重写write()方法
		@Override
		public void write(byte[] buf, int off, int len) {
			String message = new String(buf, off, len); 
			SwingUtilities.invokeLater(new Runnable(){
				public void run(){
					sb.append(message);
					text.setText(sb.toString());
				}
			});
		}
	}

}
