package com.wangle.ATM; 


//修改一下下，以适应GUI的输入，hhhh
public class Keypad{
	private int input;
	private boolean endInput;
	/*
	private Scanner input;  

	public Keypad(){
		input = new Scanner( System.in );
	}

	public int getInput(){
		return input.nextInt();  
	}
	 */

	public boolean isEndInput() {
		return endInput;
	}

	public void setEndInput(boolean endInput) {
		this.endInput = endInput;
	}

	public int getInput() {
		this.setEndInput(false);
		while(!endInput){
			System.out.print("");
		}
		return input;
	}

	public void setInput(int input) {
		this.input = input;
	}

}