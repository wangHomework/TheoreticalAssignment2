package com.wangle.ATM;
public class DepositSlot{
	public boolean isEnvelopeReceived(){
		return true;  
	}
}