import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.awt.AWTException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.text.html.HTML;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.Console;
import java.io.InputStream;
import java.awt.Robot;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import java.awt.Font;

public class mainGUI {

	public static boolean enterState = false;
	public static String input = "";
	private JFrame frame;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainGUI window = new mainGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		runATM();
	}
	public static void runATM(){
		ATM newATM = new ATM();
		newATM.run();
	}
	
	static JLabel label = new JLabel();
	static JTextArea textArea = new JTextArea();
	/**
	 * Create the application.
	 * @throws AWTException 
	 */
	public mainGUI() throws AWTException {
		initialize();
	}
	/**
	 * Initialize the contents of the frame.
	 * @throws AWTException 
	 */
	private void initialize() throws AWTException {
		
		Robot newRobot = new Robot();
		frame = new JFrame();
		frame.setBounds(100, 100, 490, 343);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton button = new JButton("1");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newRobot.keyPress(KeyEvent.VK_1);
				input  = input + "1";
				appendJTAInput(input);
			}
		});
		button.setBounds(10, 172, 73, 23);
		frame.getContentPane().add(button);
		
		JButton btnNewButton = new JButton("2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newRobot.keyPress(KeyEvent.VK_2);
				input  = input + "2";
				appendJTAInput(input);
			}
		});
		btnNewButton.setBounds(93, 172, 73, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton button_1 = new JButton("3");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//con.flush();
				input  = input + "3";
				appendJTAInput(input);
			}
		});
		button_1.setBounds(176, 172, 73, 23);
		frame.getContentPane().add(button_1);
		
		JButton button_2 = new JButton("4");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newRobot.keyPress(KeyEvent.VK_4);
				input  = input + "4";
				appendJTAInput(input);
			}
		});
		button_2.setBounds(10, 205, 73, 23);
		frame.getContentPane().add(button_2);
		
		JButton button_3 = new JButton("5");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newRobot.keyPress(KeyEvent.VK_5);
				input  = input + "5";
				appendJTAInput(input);
			}
		});
		button_3.setBounds(93, 205, 73, 23);
		frame.getContentPane().add(button_3);
		
		JButton button_4 = new JButton("6");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newRobot.keyPress(KeyEvent.VK_6);
				input  = input + "6";
				appendJTAInput(input);
			}
		});
		button_4.setBounds(176, 205, 73, 23);
		frame.getContentPane().add(button_4);
		
		JButton button_5 = new JButton("7");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newRobot.keyPress(KeyEvent.VK_7);
				input  = input + "7";
				appendJTAInput(input);
			}
		});
		button_5.setBounds(10, 238, 73, 23);
		frame.getContentPane().add(button_5);
		
		JButton button_6 = new JButton("8");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newRobot.keyPress(KeyEvent.VK_8);
				input  = input + "8";
				appendJTAInput(input);
			}
		});
		button_6.setBounds(93, 238, 73, 23);
		frame.getContentPane().add(button_6);
		
		JButton button_7 = new JButton("9");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newRobot.keyPress(KeyEvent.VK_9);
				input  = input + "9";
				appendJTAInput(input);
			}
		});
		button_7.setBounds(176, 238, 73, 23);
		frame.getContentPane().add(button_7);
		
		JButton button_8 = new JButton("\u56DE\u9000");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newRobot.keyPress(KeyEvent.VK_BACK_SPACE);
				if(input.length()!=0){
					input  = input.substring(0, input.length()-1);
					appendJTAInput(input);
				}
			}
		});
		button_8.setBounds(10, 271, 73, 23);
		frame.getContentPane().add(button_8);
		
		JButton button_9 = new JButton("0");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newRobot.keyPress(KeyEvent.VK_0);
				input  = input + "0";
				appendJTAInput(input);
			}
		});
		button_9.setBounds(93, 271, 73, 23);
		frame.getContentPane().add(button_9);
		
		JButton button_10 = new JButton("\u786E\u8BA4");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(input.length()!=0){
				newRobot.keyPress(KeyEvent.VK_ENTER);
				enterState = true;
				System.out.print(input);
				}
			}
		});
		button_10.setBounds(176, 271, 73, 23);
		frame.getContentPane().add(button_10);


		ImageIcon image = new ImageIcon("money.jpg");
		image.setImage(image.getImage().getScaledInstance(150,70,Image.SCALE_DEFAULT)); 
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setVerticalAlignment(SwingConstants.BOTTOM);
		label.setIcon(image);
		label.addMouseListener(new MouseListener(){
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				label.setVisible(false);
			}

		});
		label.setBounds(259, 205, 205, 85);
		label.setVisible(false);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("\u53D6   \u949E   \u53E3");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setBounds(259, 176, 205, 15);
		frame.getContentPane().add(label_1);
		
		JLabel lblcslb = new JLabel("<html>\u4E2D<br>\u56FD<br>\u5929<br>\u5730<br>\u94F6<br>\u884C</html>");
		lblcslb.setHorizontalAlignment(SwingConstants.CENTER);
		lblcslb.setOpaque(false);
		lblcslb.setBackground(Color.BLACK);
		lblcslb.setForeground(Color.BLACK);
		lblcslb.setFont(new Font("����", Font.BOLD, 19));
		lblcslb.setBounds(443, 0, 31, 162);
		frame.getContentPane().add(lblcslb);
		
		textArea.setBounds(10, 0, 389, 162);
		frame.getContentPane().add(textArea);
		
		JLabel lblcslb_1 = new JLabel("<html>C<br>S<br>L<br>B</html>");
		lblcslb_1.setFont(new Font("����", Font.BOLD, 21));
		lblcslb_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblcslb.setOpaque(false);
		lblcslb.setBackground(Color.BLACK);
		lblcslb.setForeground(Color.BLACK);
		lblcslb.setFont(new Font("����", Font.BOLD, 19));
		lblcslb_1.setBounds(402, 10, 38, 129);
		frame.getContentPane().add(lblcslb_1);
	}
	
	public static void setJTAText(String text){
		textArea.setText(textArea.getText()+text);
		beforeAppendInput = textArea.getText();
	}
	private static String beforeAppendInput;
	public static void appendJTAInput(String text){
		if(beforeAppendInput=="\n\rEnter your PIN: "){
			textArea.setText(beforeAppendInput+"*");
		}else
		textArea.setText(beforeAppendInput+"\r\n"+text);
	}
}
