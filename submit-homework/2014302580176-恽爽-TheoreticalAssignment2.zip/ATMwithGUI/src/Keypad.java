import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad
{
	private int inputLast = 0;
	private Object object = new Object();
	private Scanner inputer; // reads data from the command line
// no-argument constructor initializes the Scanner
 public Keypad()
 {
	 //if(mainGUI.enterState){
	//	 input = new Scanner( System.in );
	 //}
 } // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 {
	 while(!mainGUI.enterState){
		 Thread.currentThread();
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
           mainGUI.enterState = false;
           String inputString = mainGUI.input;
           mainGUI.input = "";
           mainGUI.textArea.setText("");
           inputer = new Scanner(inputString);
           
     return inputer.nextInt(); // we assume that user enters an integer
	 
 } // end method getInput
 
 class MyThread extends Thread{
     @Override
     public void run() {
         synchronized (object) {
             try {
            	 while(!mainGUI.enterState){
            		 Thread.currentThread();
            		 Thread.sleep(10000);
				}
				
             } catch (InterruptedException e) {
                 // TODO: handle exception
             }
         }
     }
 }
 }