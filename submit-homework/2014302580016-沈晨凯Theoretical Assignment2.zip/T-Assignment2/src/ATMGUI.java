

//������л�ɾ������ϵͳ���������ȷ�ϵ�¼
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;



import javax.swing.JTextArea;
import javax.swing.JButton;

import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import java.awt.event.ActionEvent;




import javax.swing.JLabel;
import javax.swing.JTextField;

public class ATMGUI extends JFrame {

	private JPanel panel;
	private JTextField textField;
	private JTextField textField_1;
	public static PrintStream printstream;
	String confire;
	String str;
	ATM atm;
   public static JTextArea textArea;


	
	public static void main(String[] args) {

			
					ATMGUI frame =new ATMGUI();
					 frame.setVisible(true);
					frame.atm.run();
					
				
		
		}

	/**
	 * Create the frame.
	 */
	public ATMGUI(){
		
		atm=new ATM();
		confire="";
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setBounds(100, 100, 619, 418);
		panel = new JPanel();
		setContentPane(panel);
		panel.setLayout(null);
		setTitle("ATM");
		
		//Ϊ��ʹ��setCaretPosition��������JTextArea���ӵ�JScrollPane��
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 10, 480, 180);
		panel.add(scrollPane);

		 textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		
		

		
		//cash out 
		JLabel lblCashOut = new JLabel("Cash out");
		//lblCashOut.setFont(new Font("����", Font.PLAIN, 17));
		lblCashOut.setBounds(355, 197, 163, 26);
		panel.add(lblCashOut);
		
		
		//Cash in
		JLabel lblCashIn = new JLabel("Cash in");
		//lblCashIn.setFont(new Font("����", Font.PLAIN, 17));
		lblCashIn.setBounds(355, 288, 163, 15);
		panel.add(lblCashIn);

		
		
		

		      

		//��ť0-9 + enter+delete+clear
		      JButton btnNewButton = new JButton("1");
		  	btnNewButton.addActionListener(new ActionListener() {
		  		public void actionPerformed(ActionEvent e) {
		  			confire = confire +'1';
		  			textArea.append(e.getActionCommand());
		  		}
		  	});
		  	btnNewButton.setBounds(20, 200, 71, 23);
		  	panel.add(btnNewButton);
		
		  	JButton btnNewButton_1 = new JButton("2");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					confire = confire +'2';
					textArea.append(e.getActionCommand());
				}
			});
			btnNewButton_1.setBounds(115, 200, 62, 23);
			panel.add(btnNewButton_1);
		
			JButton btnNewButton_2 = new JButton("3");
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					confire = confire +'3';
					textArea.append(e.getActionCommand());
				}
			});
			btnNewButton_2.setBounds(201, 200, 71, 23);
			panel.add(btnNewButton_2);
		
			JButton btnNewButton_3 = new JButton("4");
			btnNewButton_3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					confire = confire +'4';
					textArea.append(e.getActionCommand());
				}
			});
			btnNewButton_3.setBounds(20, 255, 71, 23);
			panel.add(btnNewButton_3);
		
			JButton btnNewButton_4 = new JButton("5");
			btnNewButton_4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					confire = confire +'5';
					textArea.append(e.getActionCommand());
				}
			});
			btnNewButton_4.setBounds(115, 255, 62, 23);
			panel.add(btnNewButton_4);
		
			JButton btnNewButton_5 = new JButton("6");
			btnNewButton_5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					confire = confire +'6';
					textArea.append(e.getActionCommand());
				}
			});
			btnNewButton_5.setBounds(201, 255, 71, 23);
			panel.add(btnNewButton_5);
		
			JButton btnNewButton_6 = new JButton("7");
			btnNewButton_6.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					confire = confire +'7';
					textArea.append(e.getActionCommand());
				}
			});
			btnNewButton_6.setBounds(20, 300, 71, 23);
			panel.add(btnNewButton_6);
		
			JButton btnNewButton_7 = new JButton("8");
			btnNewButton_7.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					confire = confire +'8';
					textArea.append(e.getActionCommand());
				}
			});
			btnNewButton_7.setBounds(115, 300, 62, 23);
			panel.add(btnNewButton_7);
		
			JButton btnNewButton_8 = new JButton("9");
			btnNewButton_8.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					confire = confire +'9';
					textArea.append(e.getActionCommand());
				}
			});
			btnNewButton_8.setBounds(201, 300, 71, 23);
			panel.add(btnNewButton_8);
		
			JButton btnNewButton_9 = new JButton("0");
			btnNewButton_9.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					confire = confire +'0';
					textArea.append(e.getActionCommand());
				}
			});
			btnNewButton_9.setBounds(21, 347, 43, 23);
			panel.add(btnNewButton_9);

		

		
			JButton btnNewButton_10 = new JButton("Enter");
			btnNewButton_10.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					atm.keypad.i=Integer.parseInt(confire);
					atm.keypad.b=true;			//ȷ�ϰ���enter �����ж�
					confire="";
				}
			});
			btnNewButton_10.setBounds(80, 347, 72, 23);
			panel.add(btnNewButton_10);

			JButton btnNewButton_11 = new JButton("delete");
			btnNewButton_11.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					
					str = textArea.getText();
					textArea.setText(str.substring(0,str.length()-1));
					textArea.repaint();
				}
			});
			btnNewButton_11.setBounds(162, 347, 70, 23);
			panel.add(btnNewButton_11);

			JButton btnNewButton_12 = new JButton("clear");
			btnNewButton_12.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					textArea.setText("");
					textArea.repaint();

				}
			});
			btnNewButton_12.setBounds(240, 347, 70, 23);
			panel.add(btnNewButton_12);
		
		
		textField = new JTextField();
		textField.setBackground(SystemColor.textText);
		textField.setBounds(355, 239, 153, 6);
		panel.add(textField);
		textField.setColumns(10);
		
		
		
		textField_1 = new JTextField();
		textField_1.setBackground(SystemColor.textText);
		textField_1.setBounds(350, 313, 168, 6);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		//����GUI�����
		GUIPrintStream guiPrintStream = new GUIPrintStream(System.out, textArea);
		System.setErr(guiPrintStream);
		System.setOut(guiPrintStream);
		

	}
}
