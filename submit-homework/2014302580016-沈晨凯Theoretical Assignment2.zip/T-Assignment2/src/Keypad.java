//import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad
 {
	public int i;
	public boolean b=false;
// private Scanner input; // reads data from the command line
// no-argument constructor initializes the Scanner
 public Keypad()
 {
 //input = new Scanner( System.in );
 } // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 {
	 b=false;
	 while(!b){System.out.print("");}
 return i; // we assume that user enters an integer
 } // end method getInput
 }