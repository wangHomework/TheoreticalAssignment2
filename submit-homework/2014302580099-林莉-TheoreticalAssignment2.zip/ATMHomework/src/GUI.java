import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by LinLi on 2015/11/1.
 */
public class GUI extends JFrame{
    JButton[] jbs = new JButton[11];
    JTextArea screenarea;
    JTextField jt;
    String jtText="";

    ATM atm;

    public GUI()
    {
        JFrame jf = new JFrame();
        Container c = jf.getContentPane();
        c.setLayout(new GridLayout(2,1,10,10));
        jf.setSize(500,500);

        JPanel northJP = new JPanel();
        JPanel southJP = new JPanel();
        southJP.setLayout(new GridLayout(1,2,10,10));


        screenarea = new JTextArea();
        screenarea.setEditable(false);

        JScrollPane jsp = new JScrollPane();
        jsp.setPreferredSize(new Dimension(450,170));
        jsp.setViewportView(screenarea);

        jt = new JTextField();
        jt.setPreferredSize(new Dimension(450,50));
        jt.setEditable(false);

        northJP.add(jsp);
        northJP.add(jt);

        JPanel south_leftJP = new JPanel();
        south_leftJP.setLayout(new FlowLayout());

        JPanel south_rightJP = new JPanel();
        south_rightJP.setLayout(new GridLayout(2,1,20,20));


        JPanel south_left_upJP= new JPanel();
        south_left_upJP.setPreferredSize(new Dimension(220,150));
        south_left_upJP .setLayout(new GridLayout(3,3,10,10));


        for(int i=0;i<9;i++)
        {
            jbs[i] = new JButton(Integer.toString(i+1));
            south_left_upJP.add(jbs[i]);

            jbs[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    JButton temp =(JButton)e.getSource();
                    jtText += temp.getText();
                    jt.setText(jtText);
                }
            });
        }



        JPanel south_left_downJP= new JPanel();
        south_left_downJP.setSize(300,100);
        south_left_downJP.setLayout(new FlowLayout(0,10,5));

        jbs[9] = new JButton(Integer.toString(0));
        jbs[10] = new JButton("Enter");

        jbs[9].setPreferredSize(new Dimension(66,45));
        jbs[10].setPreferredSize(new Dimension(142,45));
        south_left_downJP.add(jbs[9]);
        south_left_downJP.add(jbs[10]);

        jbs[9].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton temp =(JButton)e.getSource();
                jtText += temp.getText();
                jt.setText(jtText);
            }
        });
        jbs[10].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atm.createNextPage(jt.getText());
            }
        });


        south_leftJP.add(south_left_upJP);
        south_leftJP.add(south_left_downJP);
        JTextField up = new JTextField();
        up.setEditable(false);
        JTextField down = new JTextField();
        down.setEditable(false);

        south_rightJP.add(up);
        south_rightJP.add(down);

        southJP.add(south_leftJP);
        southJP.add(south_rightJP);
        c.add(northJP);
        c.add(southJP);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        atm = new ATM(this);
    }
}
