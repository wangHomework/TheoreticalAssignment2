

/**
 * Created by LinLi on 2015/11/1.
 */
public class Account {
    final int accountNumber = 123456;
    final int pin = 654321;

    int myMoney = 200;

    public String ShowAccount()
    {
        return "money:"+myMoney;
    }

    public boolean CheckAccountNumber(String _accountNumber)
    {
        int intAccountNumber =Integer.parseInt(_accountNumber);
        if(intAccountNumber==accountNumber)
        {
            return true;
        }
        else{
            return false;
        }
    }

    public boolean CheckAccountPIN(String _pin)
    {
        int intPin = Integer.parseInt(_pin);
        if(intPin== pin)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void Deposit(String money)
    {
        int intMoney = Integer.parseInt(money);
        myMoney+=intMoney;
    }

    public boolean Withdraw(String money)
    {
        int intMoney = Integer.parseInt(money);
        if(intMoney<=myMoney)
        {
            myMoney-=intMoney;
            return true;
        }
        else{
            return false;
        }
    }
}
