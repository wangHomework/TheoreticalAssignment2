/**
 * Created by LinLi on 2015/11/1.
 */
public class ATM {
    Account account =new Account();
    Pages currentPage = Pages.LOGIN;
    String[] sentences;
    GUI gui;
    public ATM(GUI _gui)
    {
        createString();
        gui = _gui;
        setScreenText(sentences[0]);
    }
    public void createString()
    {
        sentences = new String[9];
        sentences[0] = new String("Welcome!\nPlease input your account number:");
        sentences[1] = new String("Account does not exist");
        sentences[2] = new String("Please input your password:");
        sentences[3] = new String("\nWrong password!");
        sentences[4] = new String("Please choose the options:\n1.Deposit\n2.Withdraw\n3.Watch my money\n4.Exit");
        sentences[5] = new String("Please input the amount of money you want to deposit:");
        sentences[6] = new String("Please input the amount of money you want to withdraw");
        sentences[7] = new String("Done!");
        sentences[8] = new String("Error");
    }

    public void createNextPage(String text) {

        switch (currentPage) {
            case LOGIN:
                if(account.CheckAccountNumber(text))
                {
                    currentPage = Pages.PIN;
                    setScreenText(sentences[2]);
                    break;}
                else {break;}

            case PIN:
                if(account.CheckAccountPIN(text)) {
                    currentPage = Pages.OPTIONS;
                    setScreenText(sentences[4]);
                    break;}
                else {break;}

            case OPTIONS:
                if(text.isEmpty()){
                    setScreenText(sentences[4]);
                    break;
                }
                int jtText = Integer.parseInt(text);
                getJTText(jtText);
                break;
            case DEPOSITION:
                account.Deposit(text);
                setScreenText(sentences[7]);
                currentPage =Pages.DONE;
                break;
            case WITHDRAWAL:
                account.Withdraw(text);
                setScreenText(sentences[7]);
                currentPage = Pages.DONE;
                break;
            case DONE:
                setScreenText(sentences[4]);
                currentPage = Pages.OPTIONS;
                break;
            case ERROR:
                setScreenText(sentences[8]);
                break;
            case EXIT:
                setScreenText(sentences[0]);
                currentPage =Pages.LOGIN;
                break;
            default:
                setScreenText("");
                break;
        }
    }

    private void getJTText(int i)
    {
        switch (i)
        {
            case 1:
                setScreenText(sentences[5]);
                currentPage = Pages.DEPOSITION;
                break;
            case 2:
                setScreenText(sentences[6]);
                currentPage = Pages.WITHDRAWAL;
                break;
            case 3:
                setScreenText(account.ShowAccount());
                break;
            case 4:
                setScreenText("Exit successfully");
                currentPage = Pages.EXIT;
                break;
        }
    }

    public void setScreenText(String s)
    {
        gui.screenarea.setText(s);
        gui.jtText = "";
        gui.jt.setText(gui.jtText);
    }

    enum Pages
    {
        LOGIN,
        PIN,
        OPTIONS,
        DEPOSITION,
        WITHDRAWAL,
        ERROR,
        DONE,
        EXIT
    }
}
