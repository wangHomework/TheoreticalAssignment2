import java.awt.*;

/**
 * Created by LinLi on 2015/11/1.
 */
public class Main {
    public static void main(String[] args)
    {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                GUI gui = new GUI();
            }
        });
    }
}
