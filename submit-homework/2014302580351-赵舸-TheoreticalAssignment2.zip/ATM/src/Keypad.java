
public class Keypad
 {
 
private static int num;
public int getNum(){
	ATM.flag=true;
	return num;
 }
public static  void setNum(int Num){
	Keypad.num=Num;
}
 

 }
