import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class GUI {
      private String xs;
      public static JTextArea splace;
	  private JPanel p;
     
	
	
	public static void main (String args[]){
	ATM myatm=new ATM();
	myatm.run();
	
				
	}

	public void buildGui(){
		JFrame  fr=new JFrame();
		fr.setTitle("ATM");
		fr.setLocation(450,200);
		fr.setSize(500, 500);
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container ct= fr.getContentPane();
        ct.setLayout(null);
    	

        
        
        
        
        splace=new JTextArea();
        splace.setLineWrap(true);
        splace.setBounds(0,0,500,160);
        JScrollPane p1  =new JScrollPane(splace);
//        p1.setViewportView(splace);
        
        
//        JTable table=new JTable();
//        int rowCount=table.getRowCount();
//        table.getSelectionModel().setSelectionInterval(1, rowCount-1);
//        Rectangle rect =table.getCellRect(rowCount-1, 0, true);
//        table.scrollRectToVisible(rect);
//      p1.add(table);
        
        p=new JPanel();
        p.setLayout(null);
        p.setBounds(100,160 , 500, 240);
        p1.setBounds(0, 0, 500, 160);
        
        
        
        JButton b0=new JButton("0");
        p.add(b0);
        b0.setSize(200, 60);
        b0.setLocation(0, 180);
        b0.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if (xs==null ){
					xs="0";
				    Keypad.setNum(0);
				}else  
					xs=xs+"0";
				splace.append("0");
			}	
        });
        
        JButton b1=new JButton("1");
        p.add(b1);
        b1.setSize(100, 60);
        b1.setLocation(0, 0);
        b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if (xs==null ){
					xs="1";
					Keypad.setNum(1);
				}else  
					xs=xs+"1";
				splace.append("1");
			}	
        });
        JButton b2=new JButton("2");
        p.add(b2);
        b2.setSize(100, 60);
        b2.setLocation(100, 0);
        b2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if (xs==null ){
					xs="2";
				}else  
					xs=xs+"2";
				splace.append("2");
			}	
        });
        JButton b3=new JButton("3");
        p.add(b3);
        b3.setSize(100, 60);
        b3.setLocation(200, 0);
        b3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if (xs==null ){
					xs="3";
				}else  
					xs=xs+"3";
				splace.append("3");
			}	
        });
        JButton b4=new JButton("4");
        p.add(b4);
        b4.setSize(100, 60);
        b4.setLocation(0, 60);
        b4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if (xs==null ){
					xs="4";
				}else  
					xs=xs+"4";
				splace.append("4");
			}	
        });
        JButton b5=new JButton("5");
        p.add(b5);
        b5.setSize(100, 60);
        b5.setLocation(100, 60);
        b5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if (xs==null ){
					xs="5";
				}else  
					xs=xs+"5";
				splace.append("5");
			}	
        });
        JButton b6=new JButton("6");
        p.add(b6);
        b6.setSize(100, 60);
        b6.setLocation(200, 60);
        b6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if (xs==null ){
					xs="6";
				}else  
					xs=xs+"6";
				splace.append("6");
			}	
        });
        JButton b7=new JButton("7");
        p.add(b7);
        b7.setSize(100, 60);
        b7.setLocation(0, 120);
        b7.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if (xs==null ){
					xs="7";
				}else  
					xs=xs+"7";
				splace.append("7");
			}	
        });
        JButton b8=new JButton("8");
        p.add(b8);
        b8.setSize(100, 60);
        b8.setLocation(100, 120);
        b8.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if (xs==null ){
					xs="8";
				}else  
					xs=xs+"8";
				splace.append("8");
			}	
        });
        JButton b9=new JButton("9");
        p.add(b9);
        b9.setSize(100, 60);
        b9.setLocation(200, 120);
        b9.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if (xs==null ){
					xs="9";
				}else  
					xs=xs+"9";
				splace.append("9");
			}	
        });
        JButton be=new JButton("enter");
        p.add(be);
        be.setSize(100, 60);
        be.setLocation(200, 180);
        be.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
                Keypad.setNum(Integer.valueOf(xs));
                xs="";
                ATM.flag=false;
			}	
        });
        


        

        ct.add(p1);
        ct.add(p);
    	fr.setVisible(true);
}
	   
		
		
		
		
		
		
		
		
	}
		 
		 

		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
	 