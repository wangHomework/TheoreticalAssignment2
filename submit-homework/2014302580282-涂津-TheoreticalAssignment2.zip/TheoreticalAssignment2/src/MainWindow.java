import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainWindow extends JFrame {
    public static void main(String[] args) {
        MainWindow app = new MainWindow();
        app.display();
        app.run();
    }

    private void display(){
        //基本视图
        this.setTitle("ATM");
        this.setSize(800, 700);
        this.setResizable(false);
        this.getContentPane().setLayout(null);

        JPanel screen = new JPanel();
        screen.setLayout(null);
        screen.setBounds(20, 10, 760, 290);
        screen.setBorder(BorderFactory.createEtchedBorder());
        this.add(screen);

        JPanel keyboard = new JPanel();
        keyboard.setLayout(null);
        keyboard.setBounds(20, 320, 300, 360);
        keyboard.setBorder(BorderFactory.createEtchedBorder());
        this.add(keyboard);

        JPanel deposit = new JPanel();
        deposit.setBounds(360, 320, 420, 160);
        deposit.setBorder(BorderFactory.createEtchedBorder());
        JLabel depositText = new JLabel("Insert deposit envelope here");
        deposit.add(depositText);
        this.add(deposit);

        JPanel withdraw = new JPanel();
        withdraw.setBounds(360, 520, 420, 160);
        withdraw.setBorder(BorderFactory.createEtchedBorder());
        JLabel withdrawText = new JLabel("Take cash here");
        withdraw.add(withdrawText);
        this.add(withdraw);

        JButton number1 = new JButton("1");
        number1.setBounds(10, 10, 86, 77);
        number1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionNum1();
            }
        });
        JButton number2 = new JButton("2");
        number2.setBounds(106, 10, 86, 77);
        number2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionNum2();
            }
        });
        JButton number3 = new JButton("3");
        number3.setBounds(202, 10, 86, 77);
        number3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionNum3();
            }
        });
        JButton number4 = new JButton("4");
        number4.setBounds(10, 97, 86, 77);
        number4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionNum4();
            }
        });
        JButton number5 = new JButton("5");
        number5.setBounds(106, 97, 86, 77);
        number5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionNum5();
            }
        });
        JButton number6 = new JButton("6");
        number6.setBounds(202, 97, 86, 77);
        number6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionNum6();
            }
        });
        JButton number7 = new JButton("7");
        number7.setBounds(10, 184, 86, 77);
        number7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionNum7();
            }
        });
        JButton number8 = new JButton("8");
        number8.setBounds(106, 184, 86, 77);
        number8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionNum8();
            }
        });
        JButton number9 = new JButton("9");
        number9.setBounds(202, 184, 86, 77);
        number9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionNum9();
            }
        });
        JButton number0 = new JButton("0");
        number0.setBounds(10, 271, 86, 77);
        number0.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionNum0();
            }
        });
        JButton buttonOk = new JButton("Enter");
        buttonOk.setBounds(106, 271, 182, 77);
        buttonOk.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionOK();
            }
        });
        keyboard.add(number1);
        keyboard.add(number2);
        keyboard.add(number3);
        keyboard.add(number4);
        keyboard.add(number5);
        keyboard.add(number6);
        keyboard.add(number7);
        keyboard.add(number8);
        keyboard.add(number9);
        keyboard.add(number0);
        keyboard.add(buttonOk);

        //屏幕显示内容
        label1.setBounds(350,20,100,50);
        //label1.setBorder(BorderFactory.createEtchedBorder());
        label2.setBounds(250,80,250,50);
        //label2.setBorder(BorderFactory.createEtchedBorder());
        label3.setBounds(250, 140, 110, 50);
        //label3.setBorder(BorderFactory.createEtchedBorder());
        label3.setVisible(false);
        screen.add(label1);
        screen.add(label2);
        screen.add(label3);

        accountArea.setBounds(480, 80, 100, 50);
        //accountArea.setBorder(BorderFactory.createEtchedBorder());
        screen.add(accountArea);

        passwordArea.setBounds(360, 140, 100, 50);
        //passwordArea.setBorder(BorderFactory.createEtchedBorder());
        passwordArea.setVisible(false);
        screen.add(passwordArea);

        mainMenu.setEnabled(false);
        mainMenu.setBounds(220, 20, 300, 200);
        mainMenu.setFont(new Font(Font.DIALOG_INPUT,Font.BOLD,18));
        mainMenu.setText("\n  Main menu:\n  1 - View my balance\n  " +
                "2 - Withdraw cash\n  3 - Deposit funds\n  4 - Exit\n\n  Enter a choice:");
        mainMenu.setVisible(false);
        screen.add(mainMenu);
    }

    public static void actionNum1(){
        if (accountNumber.length() < 6 && inputState == 1){
            accountNumber += "1";
            inputState = 1;
            accountArea.setText(accountNumber);
        }
        else if(pin.length() < 6 && inputState == 2){
            pin += "1";
            inputState = 2;
            passwordArea.setText(pin);
        }
        else if (inputState == 3){
            choice = 1;
            mainMenu.setText("\n  Main menu:\n  1 - View my balance\n  " +
                    "2 - Withdraw cash\n  3 - Deposit funds\n  4 - Exit\n\n  Enter a choice: 1");
            inputState = 4;
        }
    }
    public static void actionNum2(){
        if (accountNumber.length() < 6 && inputState == 1){
            accountNumber += "2";
            inputState = 1;
            accountArea.setText(accountNumber);
        }
        else if(pin.length() < 6 && inputState == 2){
            pin += "2";
            inputState = 2;
            passwordArea.setText(pin);
        }
        else if (inputState == 3){
            choice = 2;
            mainMenu.setText("\n  Main menu:\n  1 - View my balance\n  " +
                    "2 - Withdraw cash\n  3 - Deposit funds\n  4 - Exit\n\n  Enter a choice: 2");
            inputState = 4;
        }
    }
    public static void actionNum3(){
        if (accountNumber.length() < 6 && inputState == 1){
            accountNumber += "3";
            inputState = 1;
            accountArea.setText(accountNumber);
        }
        else if(pin.length() < 6 && inputState == 2){
            pin += "3";
            inputState = 2;
            passwordArea.setText(pin);
        }
        else if (inputState == 3){
            choice = 3;
            mainMenu.setText("\n  Main menu:\n  1 - View my balance\n  " +
                    "2 - Withdraw cash\n  3 - Deposit funds\n  4 - Exit\n\n  Enter a choice: 3");
            inputState = 4;
        }
    }
    public static void actionNum4(){
        if (accountNumber.length() < 6 && inputState == 1){
            accountNumber += "4";
            inputState = 1;
            accountArea.setText(accountNumber);
        }
        else if(pin.length() < 6 && inputState == 2){
            pin += "4";
            inputState = 2;
            passwordArea.setText(pin);
        }
        else if (inputState == 3){
            choice = 4;
            mainMenu.setText("\n  Main menu:\n  1 - View my balance\n  " +
                    "2 - Withdraw cash\n  3 - Deposit funds\n  4 - Exit\n\n  Enter a choice: 4");
            inputState = 4;
        }
    }
    public static void actionNum5(){
        if (accountNumber.length() < 6 && inputState == 1){
            accountNumber += "5";
            inputState = 1;
            accountArea.setText(accountNumber);
        }
        else if(pin.length() < 6 && inputState == 2){
            pin += "5";
            inputState = 2;
            passwordArea.setText(pin);
        }
    }
    public static void actionNum6(){
        if (accountNumber.length() < 6 && inputState == 1){
            accountNumber += "6";
            inputState = 1;
            accountArea.setText(accountNumber);
        }
        else if(pin.length() < 6 && inputState == 2){
            pin += "6";
            inputState = 2;
            passwordArea.setText(pin);
        }
    }
    public static void actionNum7(){
        if (accountNumber.length() < 6 && inputState == 1){
            accountNumber += "7";
            inputState = 1;
            accountArea.setText(accountNumber);
        }
        else if(pin.length() < 6 && inputState == 2){
            pin += "7";
            inputState = 2;
            passwordArea.setText(pin);
        }
    }
    public static void actionNum8(){
        if (accountNumber.length() < 6 && inputState == 1){
            accountNumber += "8";
            inputState = 1;
            accountArea.setText(accountNumber);
        }
        else if(pin.length() < 6 && inputState == 2){
            pin += "8";
            inputState = 2;
            passwordArea.setText(pin);
        }
    }
    public static void actionNum9(){
        if (accountNumber.length() < 6 && inputState == 1){
            accountNumber += "9";
            inputState = 1;
            accountArea.setText(accountNumber);
        }
        else if(pin.length() < 6 && inputState == 2){
            pin += "9";
            inputState = 2;
            passwordArea.setText(pin);
        }
    }
    public static void actionNum0(){
        if (accountNumber.length() < 6 && inputState == 1){
            accountNumber += "0";
            inputState = 1;
            accountArea.setText(accountNumber);
        }
        else if(pin.length() < 6 && inputState == 2){
            pin += "0";
            inputState = 2;
            passwordArea.setText(pin);
        }
    }
    public static void actionOK(){
        if (inputState == 1){
            inputState = 2;
            passwordArea.setVisible(true);
            label3.setVisible(true);
        }
        else if(inputState == 2){
            int accountNum = Integer.valueOf(accountNumber);
            int pass = Integer.valueOf(pin);
            boolean loginSuccessed = bankDB.authenticateUser(accountNum, pass);
            if (loginSuccessed){
                label1.setVisible(false);
                label2.setVisible(false);
                label3.setVisible(false);
                accountArea.setVisible(false);
                passwordArea.setVisible(false);
                mainMenu.setVisible(true);
                inputState = 3;
            }
            else{
                accountNumber = "";
                pin = "";
                label1.setBounds(220, 20, 350, 50);
                label1.setText("Invalid account number or PIN. Please try again.");
                label3.setVisible(false);
                accountArea.setText(accountNumber);
                passwordArea.setText(pin);
                inputState = 1;
            }
        }
        else if(inputState == 4 && choice != 0){
            if (choice == 4){
                accountNumber = "";
                pin = "";
                accountArea.setVisible(true);
                accountArea.setText(accountNumber);
                passwordArea.setText(pin);
                label1.setVisible(true);
                label2.setVisible(true);
                label3.setVisible(false);
                inputState = 1;
                mainMenu.setVisible(false);
                choice = 0;
                mainMenu.setText("\n  Main menu:\n  1 - View my balance\n  " +
                        "2 - Withdraw cash\n  3 - Deposit funds\n  4 - Exit\n\n  Enter a choice:");
            }
        }
    }

    private void run(){
        this.setVisible(true);
    }

    private static void menu(){
        mainMenu.setVisible(true);
    }


    private static BankDatabase bankDB = new BankDatabase();
    private static String accountNumber = "";
    private static String pin = "";
    private static JLabel accountArea = new JLabel();
    private static JLabel passwordArea = new JLabel("");
    private static JLabel label1 = new JLabel("Welcome");
    private static JLabel label2 = new JLabel("Please enter your account number: ");
    private static JLabel label3 = new JLabel("Enter your PIN: ");
    private static JTextArea mainMenu = new JTextArea();
    private static int inputState = 1;
    private static int choice = 0;
}
