import javax.swing.*;

public class BalanceInquiry extends Transaction
{
	// BalanceInquiry constructor
	public BalanceInquiry( int userAccountNumber, Screen atmScreen,
						   BankDatabase atmBankDatabase )
	{
		super( userAccountNumber, atmScreen, atmBankDatabase );
	} // end BalanceInquiry constructor

	// performs the transaction
	@Override
	public void execute(JTextArea textArea)
	{
		// get references to bank database and screen
		BankDatabase bankDatabase = getBankDatabase();
		Screen screen = getScreen();

		// get the available balance for the account involved
		double availableBalance =
				bankDatabase.getAvailableBalance( getAccountNumber() );

		// get the total balance for the account involved
		double totalBalance =
				bankDatabase.getTotalBalance( getAccountNumber() );

		// display the balance information on the screen
		screen.displayMessageLine( "\nBalance Information:", textArea );
		screen.displayMessage( " - Available balance: ", textArea );
		screen.displayDollarAmount( availableBalance, textArea );
		screen.displayMessage( "\n - Total balance: ", textArea );
		screen.displayDollarAmount( totalBalance, textArea );
		screen.displayMessageLine( "", textArea );
	} // end method execute
}
 