import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame
{
    public static JTextArea textArea;
    public static Keypad keypad;
    public static String res = "";

    public static void main(String[] args)
    {
        Main app = new Main();
        app.mainWindows();
        ATM atm = new ATM();
        atm.run(textArea);
    }

    private void mainWindows()
    {
        this.setTitle("ATM");
        this.setSize(800, 700);
        this.setVisible(true);
        this.setResizable(false);
        this.getContentPane().setLayout(null);

        JScrollPane sp = new JScrollPane();
        sp.setBounds(20, 10, 760, 290);
        this.add(sp);

        textArea = new JTextArea();
        textArea.setBounds(0, 0, 760, 290);
        textArea.setBorder(BorderFactory.createEtchedBorder());
        sp.add(textArea);

        JPanel keyboard = new JPanel();
        keyboard.setBounds(20, 310, 300, 360);
        keyboard.setBorder(BorderFactory.createEtchedBorder());

        JButton number1 = new JButton("1");
        number1.setBounds(10, 10, 86, 77);
        number1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionNum1();
            }
        });
        JButton number2 = new JButton("2");
        number2.setBounds(106, 10, 86, 77);
        JButton number3 = new JButton("3");
        number3.setBounds(202, 10, 86, 77);
        JButton number4 = new JButton("4");
        number4.setBounds(10, 97, 86, 77);
        JButton number5 = new JButton("5");
        number5.setBounds(106, 97, 86, 77);
        JButton number6 = new JButton("6");
        number6.setBounds(202, 97, 86, 77);
        JButton number7 = new JButton("7");
        number7.setBounds(10, 184, 86, 77);
        JButton number8 = new JButton("8");
        number8.setBounds(106, 184, 86, 77);
        JButton number9 = new JButton("9");
        number9.setBounds(202, 184, 86, 77);
        JButton number0 = new JButton("0");
        number0.setBounds(10, 271, 86, 77);
        JButton buttonOk = new JButton("Enter");
        buttonOk.setBounds(106, 271, 182, 77);
        buttonOk.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                actionOk();
            }
        });

        keyboard.add(number1);
        keyboard.add(number2);
        keyboard.add(number3);
        keyboard.add(number4);
        keyboard.add(number5);
        keyboard.add(number6);
        keyboard.add(number7);
        keyboard.add(number8);
        keyboard.add(number9);
        keyboard.add(number0);
        keyboard.add(buttonOk);

        this.add(keyboard);
    }

    private void actionNum1(){
        res += 1;
        textArea.append("1");
    }

    private void actionOk(){
        textArea.append("\n");
    }
}
