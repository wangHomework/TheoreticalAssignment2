// Represents the screen of the ATM

import javax.swing.*;

public class Screen
{
    // display a message without a carriage return
    public void displayMessage( String message, JTextArea textArea)
    {
        textArea.append(message);
        System.out.print( message );
    } // end method displayMessage

    // display a message with a carriage return
    public void displayMessageLine( String message, JTextArea textArea)
    {
        textArea.append(message);
        System.out.println( message );
    } // end method displayMessageLine

    // displays a dollar amount
    public void displayDollarAmount( double amount, JTextArea textArea )
    {
        String message = String.format("$%,.2f", amount);
        textArea.append(message);
        System.out.printf( "$%,.2f", amount );
    } // end method displayDollarAmount
 } // end class Screen