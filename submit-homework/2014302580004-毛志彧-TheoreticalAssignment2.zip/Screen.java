import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.*;
import java.awt.AWTException; 
import java.awt.Robot; 
import java.awt.Toolkit; 
import java.awt.datatransfer.Clipboard; 
import java.awt.datatransfer.StringSelection; 
import java.awt.datatransfer.Transferable; 
import java.awt.event.KeyEvent; 

// Screen.java
// Represents the screen of the ATM

public class Screen 
{
/*
// display a message without a carriage return
public void displayMessage( String message )
{
System.out.print( message );
} // end method displayMessage

// display a message with a carriage return
public void displayMessageLine( String message )
{
System.out.println( message );
} // end method displayMessageLine

// displays a dollar amount
public void displayDollarAmount( double amount )
{
System.out.printf( "$%,.2f", amount );

} // end method displayDollarAmount
*/
	private JFrame index=new JFrame("ATM-GUI");
	private JTextArea atmscreen=new JTextArea();
	private JScrollPane scroller=new JScrollPane(atmscreen);
	private JButton btn1=new JButton("1");
	private JButton btn2=new JButton("2");
	private JButton btn3=new JButton("3");
	private JButton btn4=new JButton("4");
	private JButton btn5=new JButton("5");
	private JButton btn6=new JButton("6");
	private JButton btn7=new JButton("7");
	private JButton btn8=new JButton("8");
	private JButton btn9=new JButton("9");
	private JButton btn0=new JButton("0");
	private JButton btnenter=new JButton("Enter");
	private String  buffer=null;
	private String number=null;
	private String getinput=null;
	
public Screen() 
{
	
	index.setLayout(null);
    index.setSize(540, 444);
    index.setResizable(false);
    index.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    index.setLocationRelativeTo(null);
    scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
    scroller.setBounds(0, 0, 534, 210);
    index.add(scroller);
    
    index.add(btn1);
    btn1.setSize(168, 40);
    btn1.setLocation(10, 220);
    btn1.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			buffer=atmscreen.getText();
			buffer=buffer+"1";
			atmscreen.setText(buffer);
			number=number+"1";
			
		}
	});
    
    index.add(btn2);
    btn2.setSize(168, 40);
    btn2.setLocation(184, 220);
    btn2.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			buffer=atmscreen.getText();
			buffer=buffer+"2";
			atmscreen.setText(buffer);
			number=number+"2";
			
		}
	});
    
    index.add(btn3);
    btn3.setSize(168, 40);
    btn3.setLocation(358, 220);
    btn3.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			buffer=atmscreen.getText();
			buffer=buffer+"3";
			atmscreen.setText(buffer);
			number=number+"3";
			
		}
	});
    
    index.add(btn4);
    btn4.setSize(168, 40);
    btn4.setLocation(10, 266);
    btn4.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			buffer=atmscreen.getText();
			buffer=buffer+"4";
			atmscreen.setText(buffer);
			number=number+"4";
			
		}
	});
    
    index.add(btn5);
    btn5.setSize(168, 40);
    btn5.setLocation(184, 266);
    btn5.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			buffer=atmscreen.getText();
			buffer=buffer+"5";
			atmscreen.setText(buffer);
			number=number+"5";
			
		}
	});
    
    index.add(btn6);
    btn6.setSize(168, 40);
    btn6.setLocation(358, 266);
    btn6.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			buffer=atmscreen.getText();
			buffer=buffer+"6";
			atmscreen.setText(buffer);
			number=number+"6";
			
		}
	});
    
    index.add(btn7);
    btn7.setSize(168, 40);
    btn7.setLocation(10, 312);
    btn7.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			buffer=atmscreen.getText();
			buffer=buffer+"7";
			atmscreen.setText(buffer);
			number=number+"7";
			
		}
	});
    
    index.add(btn8);
    btn8.setSize(168, 40);
    btn8.setLocation(184, 312);
    btn8.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			buffer=atmscreen.getText();
			buffer=buffer+"8";
			atmscreen.setText(buffer);
			number=number+"8";
			
		
		}
	});
    
    index.add(btn9);
    btn9.setSize(168, 40);
    btn9.setLocation(358, 312);
    btn9.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			buffer=atmscreen.getText();
			buffer=buffer+"9";
			atmscreen.setText(buffer);
			number=number+"9";
			
		
		}
	});
    
    index.add(btn0);
    btn0.setSize(168, 40);
    btn0.setLocation(10, 358);
    btn0.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			buffer=atmscreen.getText();
			buffer=buffer+"0";
			atmscreen.setText(buffer);
			number=number+"0";
			
		}
	});
    
    index.add(btnenter);
    btnenter.setSize(342, 40);
    btnenter.setLocation(184, 358);
    btnenter.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
		number=number+"\n";
		//�޷�ʵ��Enter���Ĺ���
		//����Scanner��˵����ɨ�����̨���룬ֱ���û�Enter��Ϊֹ
		number=null;
		}
	});
    
    index.setVisible(true);
}


public void displayMessage(String message)
{
	System.out.print( message );
	atmscreen.append(message);
}

public void displayMessageLine( String message )
{
	System.out.println( message );
	atmscreen.append("\n"+message);
}

public void displayDollarAmount( double amount )
{
	System.out.printf( "$%,.2f", amount );
	atmscreen.append("$"+amount);
}
} // end class Screen