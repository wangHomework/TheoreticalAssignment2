
public class ATMCaseStudy
{
	
	// main method creates and runs the ATM
	public static void main( String[] args )
	{
		MainGUI mg = new MainGUI();
		Screen screen = new Screen(mg);
		Keypad keypad = new Keypad(mg);
		ATM theATM = new ATM(keypad,screen);
		theATM.run();
	} // end main
} // end class ATMCaseStudy