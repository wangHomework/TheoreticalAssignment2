import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class MainGUI extends JFrame{
	boolean b = false;
	JTextArea jt;
	String str = "";
	int n = 0;
	JFrame jf; 
	JButton []jbutton = new JButton[12];
	JPanel jp;
	public MainGUI(){
		jf = new JFrame();
		jf.setSize(500,400);
		jf.setTitle("ATM");
		jf.setLayout(null);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		Container c = jf.getContentPane();
		jt = new JTextArea();
		JScrollPane jsp = new JScrollPane(jt);
		c.add(jsp);
		jsp.setBounds(0,0,500,100);
		jp = new JPanel(new GridLayout(4,3,5,5));
		jbutton[9] = new JButton("Enter");
		jbutton[10] = new JButton("0");
		jbutton[10].addActionListener(new ButtonListener());
		jbutton[11] = new JButton("Delete");
		for(int i = 0;i < jbutton.length;i++){
			if(i < 9){
				jbutton[i] = new JButton("" + (i+1));
				jbutton[i].addActionListener(new ButtonListener());
			}
			jp.add(jbutton[i]);		
		}
		jbutton[9].addActionListener(new ActionListener() {
            
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        b = true;
		    }
		});
		jbutton[11].addActionListener(new ActionListener() {
            
		    @Override
		    public void actionPerformed(ActionEvent e) {
		    	String s=jt.getText();
            	if(s.charAt(s.length()-1)!=':')
            	{
					s=s.substring(0,s.length()-1);
					jt.setText(s);
            	}
		    }
		});
		
		c.add(jp);
		jp.setBounds(0,100,300,200);
		jf.setResizable(false);
		jf.setVisible(true);	
	}
	public int Input() {
		while(false == b)//���ڵȴ�����
			System.out.print("");
		b = false;
		int t=n;
		n=0;
		return t;
	}
	public void appendTextLine(String s)
	{
		jt.append(s+"\n");
		jt.setCaretPosition(jt.getText().length());
		
	}
	public void appendText(String s)
	{
		jt.append(s);
		jt.setCaretPosition(jt.getText().length());
	}
	public void appendNumber(double amount)
	{
		jt.append(String.valueOf(amount));
		jt.setCaretPosition(jt.getText().length());
	}
	class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JButton button = (JButton) e.getSource();
			String message = button.getText();
			jt.append(message);
		}
	}
}