public class Keypad
{
	MainGUI mg; // reads data from the command line
	// no-argument constructor initializes the Scanner
	public Keypad(MainGUI mg)
	{
		this.mg = mg;
	} // end no-argument Keypad constructor

	// return an integer value entered by user
	public int getInput()
	{
		return mg.Input(); // we assume that user enters an integer
		
	} // end method getInput
}