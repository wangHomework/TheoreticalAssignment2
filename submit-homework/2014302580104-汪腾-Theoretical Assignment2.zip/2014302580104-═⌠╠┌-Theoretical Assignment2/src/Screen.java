
//import javax.xml.soap.Text;

// Represents the screen of the ATM
public class Screen{
	MainGUI mg;
	public Screen(MainGUI mg){
		this.mg = mg;
	}
	// display a message without a carriage return
	public void displayMessage( String message )
	{
		mg.appendText(message);
	} // end method displayMessage

	// display a message with a carriage return
	public void displayMessageLine( String message )
	{
		mg.appendTextLine(message);
	} // end method displayMessageLine

	// displays a dollar amount
	public void displayDollarAmount( double amount )
	{
		mg.appendNumber(amount);
	} // end method displayDollarAmount
} // end class Screen

