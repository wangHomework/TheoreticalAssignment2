import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

class KeyBoard extends JPanel
{
	public KeyBoard()
	{
		setLayout(new GridLayout(5,3));
		for(int i=0;i<9;i++)
		{
			JButton tmp = new JButton(Integer.toString(i+1));
			tmp.addActionListener(new KeyBoardController(i+1));
			add(tmp);
		}
		JButton tmp1 = new JButton("Back");
		tmp1.addActionListener(new KeyBoardController(-2));
		add(tmp1);
		JButton tmp2 = new JButton(Integer.toString(0));
		tmp2.addActionListener(new KeyBoardController(0));
		add(tmp2);
		JButton tmp3 = new JButton("Enter");
		tmp3.addActionListener(new KeyBoardController(-1));
		add(tmp3);
		JButton tmp4 = new JButton("Regist");
		tmp4.addActionListener(new KeyBoardController(-3));
		add(tmp4);
	}
}

class Withdrawal extends JPanel
{
	public Withdrawal()
	{
		Icon pic = new ImageIcon("C:\\Users\\SilverCrux\\Desktop\\123.jpg");
		setLayout(new GridLayout(2,1));
		JLabel out = new JLabel();
		out.setSize(300, 100);
		out.setText("Withdrawal");
		out.setIcon(pic);
		out.setVerticalTextPosition(SwingConstants.TOP);
		out.setHorizontalTextPosition(SwingConstants.CENTER);
		out.setHorizontalAlignment(SwingConstants.CENTER);
		add(out);
		JLabel in = new JLabel();
		in.setSize(300, 100);
		in.setText("Deposit");
		in.setIcon(pic);
		in.setVerticalTextPosition(SwingConstants.TOP);
		in.setHorizontalTextPosition(SwingConstants.CENTER);
		in.setHorizontalAlignment(SwingConstants.CENTER);
		add(in);
	}
}

class TextBox extends JTextArea
{
	public TextBox()
	{
		setEditable(false);
		setRows(10);
	}
}
