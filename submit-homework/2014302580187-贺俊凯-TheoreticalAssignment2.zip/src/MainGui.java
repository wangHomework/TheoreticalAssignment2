import javax.swing.*;
import java.awt.*;
import java.lang.*;
public class MainGui{
//Parameters 
	public static KeyBoard keyboard = new KeyBoard();
	public static Withdrawal withdrawal = new Withdrawal();
	public static TextBox textbox = new TextBox();
	public static String buffer = new String("");
	public static enum State{REGIST,SUCCESS,FALSE,REREGIST,WELCOME,LOGIN,PASSWORD,CHECK,WITHDRAWAL,DEPOSITE,INQUIRE};
	public static State currentState = State.LOGIN;
	public static UserAccount user;
//Methods
	public static void CreateFrame()
	{
		JFrame frame = new JFrame("ATM");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new BorderLayout());
		frame.add(keyboard,BorderLayout.WEST);
		frame.add(withdrawal,BorderLayout.EAST);	
		frame.add(textbox,BorderLayout.NORTH);
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void Run() throws Exception
	{
		switch(currentState)
		{
		case FALSE:		
			FSM.Regist();
			break;
		case REGIST:
			FSM.Regist();
			break;
		case LOGIN:
			FSM.Login();
			break;
		case PASSWORD:
			FSM.Password();
			buffer = "";
			break;
		case CHECK:
			FSM.Check(buffer);
			buffer ="";
			break;
		case WITHDRAWAL:
			FSM.Withdrawal(buffer);
			buffer = "";
			break;
		case DEPOSITE:
			FSM.Deposite(buffer);
			buffer = "";
			break;
		case INQUIRE:
			FSM.Inquire(buffer);
			buffer = "";
			break;
		case WELCOME:
			FSM.Welcome(buffer);
			break;
		}
	}
	
	public static void main(String args[]) throws Exception
	{
		user = new UserAccount();
		CreateFrame();
		String login = "��ӭʹ�ñ�ATM\r\n�����������˻�����";
		MainGui.textbox.setText(login);
	}	
}
