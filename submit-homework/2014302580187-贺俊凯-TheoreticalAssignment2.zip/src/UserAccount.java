import java.awt.TextField;
import javax.swing.JFrame;
import org.sqlite.JDBC;
import java.sql.*;

public class UserAccount {
	int account;
	static double password;
	static double money = 0;
	static Connection connection;
	static Statement statement;
	static int id;
	
	public UserAccount() throws Exception
	{
		String sql = "jdbc:sqlite:resource/atm.db";
		Class.forName("org.sqlite.JDBC");
		connection = DriverManager.getConnection(sql);
		System.out.println(connection.isValid(1));;
		statement = connection.createStatement();
	}
	
	public void SetAccountInfo(String n,String m) throws Exception
	{
		ResultSet rs1 = statement.executeQuery("select * from UserAccount where account="+n);
		if(rs1.getInt(1)==Integer.parseInt(n))
		{	
			MainGui.textbox.setText("���û��Ѵ��ڣ�\n������ע���û�����");
			MainGui.currentState = MainGui.State.FALSE;
			MainGui.buffer ="";
			rs1.close();
			return;
		}
		rs1.close();
	    PreparedStatement prep = connection.prepareStatement("insert into UserAccount values(?,?,?,?);");
	    prep.setInt(1,Integer.parseInt(n));
	    prep.setDouble(2, Double.parseDouble(m));
	    prep.setDouble(3, 0);
	    prep.addBatch();
	    
	    connection.setAutoCommit(false);
	    prep.executeBatch();
	    connection.setAutoCommit(true); 
	    
	    ResultSet rs = statement.executeQuery("select * from UserAccount where account="+n);
	    money = rs.getInt(3);
	    id = rs.getInt(4);	
	    rs.close();
	}
	
	public Boolean Login(String n,String m) throws Exception
	{
		
		ResultSet rs = statement.executeQuery("select * from UserAccount where account="+n);
		System.out.println(m);
		System.out.println(m.length());
		if(Double.valueOf(m) == rs.getDouble(2))
		{
			id=rs.getInt(4);
			System.out.println(rs.getInt(4));
			System.out.println(id);
			money=rs.getDouble(3);
			rs.close();
			return true;
		}
		else 
		{
			rs.close();
			return false;
		}
	}
	
	public void Deposite(int n) throws Exception
	{
		if(Double.MAX_VALUE-money<n*100)
		{
			JFrame error = new JFrame();
			//error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			error.add(new TextField("�������ѱ�����"));
			error.pack();
			error.setVisible(true);
			return;
		}
		money += n*100;
		statement.executeUpdate("update UserAccount set money = "+ String.valueOf(money)+" where id="+id);
	}
	
	public void Withdrawal(int n) throws Exception
	{
		if(money-n*100<0)
		{
			JFrame error = new JFrame();
			//error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			error.add(new TextField("����"));
			error.pack();
			error.setVisible(true);
		}
		money -= n*100;
		statement.executeUpdate("update UserAccount set money = "+ String.valueOf(money)+" where id="+id);
	}
	
	public void Inquire() throws Exception
	{
		System.out.println(id);
		ResultSet tmp = statement.executeQuery("select * from UserAccount where id="+id);
		MainGui.textbox.append(String.valueOf(tmp.getDouble(3)));
		//System.out.println(tmp.getDouble(3));
		tmp.close();	
	}
}
