import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.util.*;

 class KeyBoardController implements ActionListener {
	private int n;
	public KeyBoardController(int x)
	{
		n = x;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		switch(n)
		{
		case 0:
			MainGui.textbox.append("0");
			MainGui.buffer += "0";
			break;
		case 1:
			MainGui.textbox.append("1");
			MainGui.buffer += "1";
			break;
		case 2:
			MainGui.textbox.append("2");
			MainGui.buffer += "2";
			break;
		case 3:
			MainGui.textbox.append("3");
			MainGui.buffer += "3";
			break;
		case 4:
			MainGui.textbox.append("4");
			MainGui.buffer += "4";
			break;
		case 5:
			MainGui.textbox.append("5");
			MainGui.buffer += "5";
			break;
		case 6:
			MainGui.textbox.append("6");
			MainGui.buffer += "6";
			break;
		case 7:
			MainGui.textbox.append("7");
			MainGui.buffer += "7";
			break;
		case 8:
			MainGui.textbox.append("8");
			MainGui.buffer += "8";
			break;
		case 9:
			MainGui.textbox.append("9");
			MainGui.buffer += "9";
			break;
		case -1:
			if(MainGui.currentState==MainGui.State.SUCCESS)
			{
				String info[] = MainGui.buffer.split("\n");
				MainGui.buffer ="";
				//System.out.println(info[1]);
				if(info[0].length()>5)
					return;
				if(info[1].length()>6)
					return;
			    try {
					MainGui.user.SetAccountInfo(info[0], info[1]);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    if(MainGui.currentState == MainGui.State.FALSE)
			    	break;
			    MainGui.currentState = MainGui.State.WELCOME;
			    MainGui.textbox.setText("��ӭʹ�ã����ѵ�¼,��ѡ�����\n��ѯ��� --1\nȡ�� --2\n���--3\n������Ӧ���֣�");
			    break;
			}
			if(MainGui.currentState==MainGui.State.LOGIN)
			{
				MainGui.buffer += "\r\n";
				try {
					MainGui.Run();
					MainGui.currentState = MainGui.State.PASSWORD;
					break;
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			if(MainGui.currentState==MainGui.State.FALSE)
			{
				try {
					MainGui.Run();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			}
			if(MainGui.currentState==MainGui.State.PASSWORD)
			{
				MainGui.currentState = MainGui.State.CHECK;
				try {
			     	MainGui.Run();	
					break;
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();		
				}
			}
			try {
				MainGui.Run();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		case -2:
			if(MainGui.currentState == MainGui.State.LOGIN||MainGui.currentState == MainGui.State.PASSWORD)
			{
				MainGui.buffer = "";
				MainGui.textbox.setText("��ӭʹ�ñ�ATM\r\n�����������˻�����");
				MainGui.currentState = MainGui.State.LOGIN;
				break;
			}
			if(MainGui.currentState == MainGui.State.REGIST)
			{
				MainGui.textbox.setText("������ע���û�������������ַ�����");
				MainGui.buffer = "";
				break;
			}
			if(MainGui.currentState == MainGui.State.FALSE)
			{
				MainGui.textbox.setText("���û��Ѵ��ڣ�\n������ע���û�������������ַ�����"); 
				MainGui.buffer ="";
			    break;
			}
			MainGui.currentState = MainGui.State.WELCOME;
			MainGui.textbox.setText("��ӭʹ�ã����ѵ�¼,��ѡ�����\n��ѯ��� --1\nȡ�� --2\n���--3\n������Ӧ���֣�");
			MainGui.buffer = "";
			break;
		case -3:
			if(MainGui.currentState == MainGui.State.REGIST)
			{
				break;
			}
			MainGui.buffer = "";
			MainGui.currentState = MainGui.State.REGIST;
			MainGui.textbox.setText("������ע���û�������������ַ�����");
			break;
		}
	}

}
