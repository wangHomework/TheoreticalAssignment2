package guo_TheoreticalAssignment2;

public class Loggin{
    private String cardID="12345"; //�ʺš�����
	private String pwd="12345";
	private double money=1000; 
	public Loggin(){}
	public Loggin(String id,String p){
		cardID=id;
		pwd=p;
	}
	public String getCardID(){
		return cardID;
	}
	public String getPwd(){
		return pwd;
	}
	public double getMoney(){
		return money;
	}
	public void setMoney(double m){
		money=m;
	}
	public void setPwd(String s){
		pwd=s;
    }
}
