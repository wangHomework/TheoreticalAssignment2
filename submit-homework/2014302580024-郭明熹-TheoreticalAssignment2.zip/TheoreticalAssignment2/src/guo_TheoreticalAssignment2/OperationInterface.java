package guo_TheoreticalAssignment2;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.regex.Pattern;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class OperationInterface {
	Loggin lo=new Loggin();
	int flag=0;
	boolean huanSuan=false;
	String qian="�����";
	int k=0; 
	JButton b1;
	JButton b2;
	JButton b3;
	JButton b4;
	//JButton b5;
	JButton b6;
	JButton b7;
	JButton b8;
	JLabel la1; 
	JTextField t1;
	JPanel p1,p2,p3,p4,p5,p6,p7,p8; 
	class GetInformation {
		public int year,month,day,hour,m,s; 
		public String hh;
		public double lm; 
	}
	public GetInformation GeI[];
	public OperationInterface(){
		GeI=new GetInformation[100];
		 int b=GeI.length;
		for(int i=0;i<b;i++)
			GeI[i]=new GetInformation();
		b1=new JButton("ȡ��");
		b2=new JButton("���");
		b3=new JButton("�˳�ϵͳ");
		b4=new JButton("��ѯ���");
		//b5=new JButton("");
		b6=new JButton("ȷ��");
		b7=new JButton("��������");
		b8=new JButton("��ѯ��ϸ");
		la1=new JLabel(); 
		t1=new JTextField(10);
		t1.setVisible(false); 
		
		p1=new JPanel(new FlowLayout());
		p2=new JPanel(new FlowLayout());
		p3=new JPanel(new FlowLayout());
		p4=new JPanel(new FlowLayout());
		p5=new JPanel(new FlowLayout());
		p6=new JPanel(new GridLayout(5,1));
		p1.add(b1);
		p1.add(b7);  
		p1.add(b2); 
		p1.add(b3);
		p2.add(b4); 
		p2.add(b8);
		//p2.add(b5);
		p2.add(b6);
		p3.setVisible(false); 
		p4.setVisible(false); 
		p5.add(la1);
		p5.add(t1);
		p6.add(p1);
		p6.add(p2);
		p6.add(p3);
		p6.add(p4);
		p6.add(p5);
		JFrame f=new JFrame("�й�����"); 
		f.getContentPane().add(p6);
		f.pack();
		f.setResizable(false);
		f.setVisible(true);
		
		f.addWindowListener(new Wadapater()); 
		b1.addActionListener(new QuActionListener());
		b2.addActionListener(new CunActionListener());
		b3.addActionListener(new TuiActionListener()); 
		b4.addActionListener(new ChaActionListener()); 
		b6.addActionListener(new QueActionListener());
		b8.addActionListener(new QuMActionListener());
		b7.addActionListener(new UpPwdActionListener());
	}
	class QuActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			la1.setText("������ȡ���");
			t1.setVisible(true); 
			t1.setText(""); 
			flag=1;
		}
	}
	class CunActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e){
			la1.setText("������ȡ���");
			t1.setVisible(true); 
			t1.setText(""); 
			flag=2;
		}	
	}
	class TuiActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			System.exit(0); 
		}
	}
	class ChaActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			la1.setText("�����е����Ϊ��");
			t1.setVisible(true); 
			t1.setText(""); 
			flag=3;
		}
	}
	class QueActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			double m=0;
			Calendar now=Calendar.getInstance();
			DecimalFormat my=new DecimalFormat();
			my.applyPattern("0.00");
			switch(flag){
			case 1:
				if(!t1.getText().equals("")){
					if(Pattern.matches("[0-9]*",t1.getText())) {
						m=lo.getMoney()-Double.parseDouble(t1.getText());
						if(m<0) {
							t1.setText("���㡣");
						}else{
							lo.setMoney(m); 
							GeI[k].year=now.get(Calendar.YEAR); 
							GeI[k].month=now.get(Calendar.MONTH);
							GeI[k].day=now.get(Calendar.DAY_OF_MONTH);
							GeI[k].hour=now.get(Calendar.HOUR_OF_DAY); 
							GeI[k].m=now.get(Calendar.MINUTE); 
							GeI[k].s=now.get(Calendar.SECOND);
							GeI[k].hh="ȡ��"+t1.getText()+qian;
							GeI[k].lm=lo.getMoney();
							k++; 
							t1.setText("");
						}
					}else{t1.setText("");}
				}
				break;
			case 2:
				if(!t1.getText().equals("")) {
					if(Pattern.matches("[0-9]*",t1.getText())){
						m=Double.parseDouble(t1.getText());
					if(m<0) {
						t1.setText("�����������֤�����䣡");
						
					}else{
						
					lo.setMoney(lo.getMoney()+m); 
					GeI[k].year=now.get(Calendar.YEAR); 
					GeI[k].month=now.get(Calendar.MONTH);
					GeI[k].day=now.get(Calendar.DAY_OF_MONTH);
					GeI[k].hour=now.get(Calendar.HOUR_OF_DAY); 
					GeI[k].m=now.get(Calendar.MINUTE); 
					GeI[k].s=now.get(Calendar.SECOND);
					GeI[k].hh="���"+t1.getText()+qian;
					GeI[k].lm=lo.getMoney();
					k++; 
					t1.setText("");
					}
				}else{t1.setText("");}
				}
			break;
			 default:
             t1.setText(my.format(lo.getMoney()));
		
		}
	}
	}
	class Wadapater extends WindowAdapter{
		public void windowClosing(WindowEvent e){
			System.exit(0);
		}
	}
	class QuMActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			QuMingXi qm=new QuMingXi(); 
		}
	}
	class UpPwdActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e){
			 UpdatePassword up=new UpdatePassword(); 
		}
	}
	class QuMingXi {
		JFrame f; 
		JTextArea textArea;
		JScrollPane jS; 
		JLabel lab; 
		JButton button1,button2;
		public QuMingXi (){
			textArea=new JTextArea(5,8);
			jS=new JScrollPane(textArea);
			button1=new JButton("ȷ��");
			button2=new JButton("��ӡ��ϸ"); 
			textArea.setEditable(false); 
			lab=new JLabel("������Ĵ�ȡ����ϸ���£�"); 
			JPanel p1=new JPanel();
			GridBagLayout gridBag=new GridBagLayout(); 
			p1.setLayout(gridBag);
			GridBagConstraints c=new GridBagConstraints(); 
			c.gridwidth=GridBagConstraints.REMAINDER ;
			c.fill=GridBagConstraints.HORIZONTAL;
			gridBag.setConstraints(lab,c);
			p1.add(lab);
			c.fill=GridBagConstraints.BOTH;
			c.weightx=1.0;
			c.weighty=1.0; 
			gridBag.setConstraints(jS,c);
			p1.add(jS);
			c.gridwidth=2;
			c.fill=GridBagConstraints.HORIZONTAL;
			gridBag.setConstraints(button2,c);
			gridBag.setConstraints(button1,c);
			p1.add(button2);
			p1.add(button1);
			
			f=new JFrame("�й�����");
			f.getContentPane().add(p1); 
			f.setSize(400,200);
			f.setResizable(false); 
			f.setVisible(true);
			button1.addActionListener(new QActionListener());
			button2.addActionListener(new PrintDetails());
			queryMXi();
		}
		public void queryMXi(){
			DecimalFormat my=new DecimalFormat();
			my.applyPattern("0.00");
			textArea.setText("ʱ��"+""+"��ȡ���"+""+"���"+"\n"); 
			int b=GeI.length;
			for(int i=0;i< b;i++){
				if(GeI[i].year!=0)
					textArea.append(GeI[i].year+"-"+GeI[i].month+"-"+GeI[i].day+"-"+GeI[i].hour+"-"+GeI[i].m+"-"+GeI[i].s+" "+GeI[i].hh+" "+my.format(GeI[i].lm)+"Ԫ�����"+"\n"); 
				}
			}
		class QActionListener implements ActionListener{
			public void actionPerformed(ActionEvent e){
				f.setVisible(false);
			}
		}
		class PrintDetails implements ActionListener{
			public void actionPerformed(ActionEvent e){
				PrintDetail pd=new PrintDetail();
			}
		}
	}
	class UpdatePassword{
		JFrame f;
		JLabel lab1;
		JLabel lab2; 
		JLabel lab3;
		JLabel lab4;
		JLabel lab5;
		JPasswordField t1;
		JPasswordField t2;
		JButton b1,b2,b3;
		JPanel p1,p2,p3,p4,p5,p6,p7; 
		public UpdatePassword(){
			lab1=new JLabel("�й�����");
			lab2=new JLabel("������������");
			lab3=new JLabel("����");
			lab4=new JLabel("����ȷ��");
			lab5=new JLabel("");
			t1=new JPasswordField(8); 
			t2=new JPasswordField(8); 
			t1.setEchoChar('*');
			t2.setEchoChar('*');
			b1=new JButton("����");
			b2=new JButton("ȡ��");
			b3=new JButton("ȷ��");
			p1=new JPanel(new FlowLayout(FlowLayout.CENTER));
			p2=new JPanel(new FlowLayout(FlowLayout.LEFT));
			p3=new JPanel(new FlowLayout(FlowLayout.CENTER)); 
			p4=new JPanel(new FlowLayout(FlowLayout.CENTER)); 
			p5=new JPanel(new FlowLayout(FlowLayout.CENTER));
			p6=new JPanel(new FlowLayout()); 
			p7=new JPanel(new GridLayout(6,1));
			p1.add(lab1);
			p2.add(lab2); 
			p3.add(lab3);
			p3.add(t1);
			p4.add(lab4);
			p4.add(t2); p5.add(lab5);p6.add(b1);p6.add(b2);p6.add(b3);p7.add(p1);p7.add(p2); p7.add(p3);p7.add(p4);p7.add(p5);p7.add(p6);
			f=new JFrame("�й�����"); 
			f.getContentPane().add(p7); 
			f.setSize(400,200);
			f.setResizable(false);
			f.setVisible(true);
			b1.addActionListener(new BackActionListener()); 
			b2.addActionListener(new CancelActionListener()); 
			b3.addActionListener(new OKActionListener());
		}
		class BackActionListener implements ActionListener{
			public void actionPerformed(ActionEvent e){
				f.setVisible(false); 
			}
		}
		class CancelActionListener implements ActionListener{
			public void actionPerformed(ActionEvent e){
				t1.setText("");
				t2.setText("");
			} 
		}
		class OKActionListener implements ActionListener{
			public void actionPerformed(ActionEvent e){
				Loggin lo=new Loggin(); 
				if(!t1.getText().equals("")&&!t2.getText().equals("")) {
					if(t1.getText().trim().equals(t2.getText().trim())){
						lo.setPwd(t1.getText().trim());
						lab5.setText("������ĳɹ���");
					}else{lab5.setText("�������벻һ�£����������룡"); t1.setText(""); t2.setText("");}
				}else{lab5.setText("���벻��Ϊ�գ�");}
			}
		}
	}
	class PrintDetail{
		JFrame f;
		JLabel lab1; 
		public PrintDetail(){
		lab1=new JLabel("�����պô�ӡ����лл���ʹ�ã�");
		f.getContentPane().add(p3); 
		f.setSize(400,200);
		f.setResizable(false); 
		f.setVisible(true);
		}
	}
}