package guo_TheoreticalAssignment2;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class SafetyFrame implements ActionListener {
	 
		Loggin lo=new Loggin();//������Ϣ����󣬽��е�¼��Ϣ��½
		int i=0;//��¼�Ƿ���½�Ĵ���
		JPanel p1,p2,p3,p4,p5;
	    JLabel lab1,lab2,lab3,lab4;
	    JTextField t1; 
	    JPasswordField t2;
	    JButton button;
	    JFrame f;
	    public SafetyFrame(){
	    	lab1=new JLabel("�й�����ϵͳ");
	    	lab1.setHorizontalAlignment(JLabel.CENTER);
	    	lab2=new JLabel("���ţ�");
	        lab3=new JLabel("���룺");
	        lab4=new JLabel();
	        button=new JButton("ȷ��");
	    	t1=new JTextField(8);
	    	t2=new JPasswordField(8);
	    	t2.setEchoChar('*');
	    	p1=new JPanel(new FlowLayout());
	    	p2=new JPanel(new FlowLayout());
	    	p3=new JPanel(new GridLayout(0,1));
	    	p4=new JPanel(); 
	    	p5=new JPanel(new BorderLayout()); 
	    	p1.add(lab2);
	    	p1.add(t1);
	    	p2.add(lab3);
	    	p2.add(t2);
	    	p3.add(p1); 
	    	p3.add(p2); 
	    	
	    	GridBagLayout gridBag=new GridBagLayout();
	    	p4.setLayout(gridBag);
	    	GridBagConstraints c=new GridBagConstraints(); 
	    	c.gridwidth=GridBagConstraints.REMAINDER;
	    	c.fill=GridBagConstraints.CENTER;
	    	gridBag.setConstraints(lab4,c);
	    	p4.add(lab4);
	    	c.fill=GridBagConstraints.EAST;
	    	gridBag.setConstraints(button,c); 
	    	p4.add(button);
	    	
	    	p5.add(lab1,BorderLayout.NORTH);
	    	p5.add(p3,BorderLayout.CENTER);
	    	p5.add(p4,BorderLayout.SOUTH); 
	    	
	    	f=new JFrame("ATM�Զ�ȡ���");
	    	f.getContentPane().add(p5);
	    	f.setSize(300,200); 
	    	f.setResizable(false);
	    	f.setVisible(true);
	    	button.addActionListener(this);
	    }
	    

	    public void actionPerformed(ActionEvent e){
	    	if(t1.getText().equals(lo.getCardID())&&t2.getText().equals(lo.getPwd())){
	    		f.setVisible(false); 
	    		OperationInterface dr=new OperationInterface(); 
	    	}
	    	else{
	    		lab4.setText("���Ż�����������֤������!");
	    		i++;
	    		if(i==3)
	    			lab4.setText("���Ѿ���������"+i+"�Σ�������1�λ���!"); 
	    		if(i==4)
	    			System.exit(0);
	    	}
	    }
	}


