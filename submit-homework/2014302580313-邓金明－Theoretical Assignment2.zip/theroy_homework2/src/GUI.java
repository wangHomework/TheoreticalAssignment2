
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class GUI {
	private int state = 0;
	// 用户状态
	public static final int CANNOT_INPUT = 0;
	public static final int INPUT_ACCOUNT_NUMBER = 1;	//等待输入账号
	public static final int INPUT_ACCOUNT_PIN = 2;		//等待输入密码
	public static final int WAITING_CHOOSE = 3;		//等待选择事务
	public static final int LOOKING_INFO = 4;			//正在显示信息

	private JFrame mWindow;
	private Container mPanel;
	private static JTextArea screen;
	private StringBuilder clickeNum = new StringBuilder();
	private boolean entered = false;
	private String[] key = { "1", "2", "3", "取消", "4", "5", "6", "删除", "7", "8", "9", " ", "00", "0", ".", "确认" };
	JScrollPane jsp;
	public GUI() {
		init();
	}

	// 初始化gui布局
	public void init() {
		clickeNum = new StringBuilder();
		setState(INPUT_ACCOUNT_NUMBER);
		mWindow = new JFrame("ATM");
		mPanel = mWindow.getContentPane();
		mPanel.setLayout(null);

		mWindow.setSize(600, 600);
		mWindow.setLocationRelativeTo(null);

		// 显示屏
		screen = new JTextArea();
//		screen.setBounds(0, 0, 600, 300);
		screen.setSize(600, 350);
		screen.setEditable(false);
		jsp = new JScrollPane(screen);
		jsp.setBounds(0, 0, 600, 300);
		
		mPanel.add(jsp);

		// 密码盘
		JPanel keys = new JPanel();
		keys.setBounds(0, 350, 200, 200);
		keys.setLayout(new GridLayout(4, 4));
		for (int i = 0; i < 16; i++) {
			MButton button = new MButton(i, key[i]);
			button.addActionListener(new MListener(button));
			keys.add(button);
		}
		mPanel.add(keys);

		

		mWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mWindow.setVisible(true);
	}

	// 重写jbutton类，添加id属性
	public class MButton extends JButton {
		private int id;

		public MButton(int id, String text) {
			super(text);
			this.id = id;
		}

		public int getId() {
			return this.id;
		}
	}

	// 重写监听器，识别jbutton的id
	public class MListener implements ActionListener {
		MButton button;

		public MListener(MButton button) {
			super();
			this.button = button;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			switch (button.id) {
			case 0:
			case 1:
			case 2:
			case 4:
			case 5:
			case 6:
			case 8:
			case 9:
			case 10:
			case 12:
			case 13:
				clickeNum.append(button.getText());
				if (getState() == INPUT_ACCOUNT_NUMBER||getState() == WAITING_CHOOSE)
					addText(String.valueOf(button.getText()));

				else if (getState() == INPUT_ACCOUNT_PIN)
					addText("*");

				break;
			// 取消 清除当前输入
			case 3:
				screen.setText(screen.getText().substring(0, screen.getText().length() - clickeNum.length()));
				clickeNum.setLength(0);
				break;
			// 删除 回删一个输入
			case 7:
				clickeNum.setLength(clickeNum.length() - 1);
				screen.setText(screen.getText().substring(0, screen.getText().length() - 1));
				break;
			// 确认
			case 15:
				entered = true;
				break;
			}
			// 等待密码输入

		}
	}

	public void setText(String text) {
		screen.setText(text);
	}

	public int getInput(){
		int i = 0;
		while (!entered) {
			System.out.println(i);
		}
		i = Integer.valueOf(clickeNum.toString());
		clickeNum.setLength(0);
		entered = false;
		return i;
	}
	
	public void addText(String text) {
	
		screen.setText(screen.getText() + text);
			
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}
}
