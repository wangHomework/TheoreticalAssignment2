
// Represents the screen of the ATM

public class Screen {
	private GUI gui;
	public Screen(GUI gui) {
		this.gui = gui;
	}
	// display a message without a carriage return
	public void displayMessage(String message) {
		gui.addText(message);
		gui.jsp.getVerticalScrollBar().setValue(gui.jsp.getVerticalScrollBar().getMaximum());  //默认最下方
	} // end method displayMessage

	// display a message with a carriage return
	public void displayMessageLine(String message) {
		gui.addText("\r\n"+message);
		gui.jsp.getVerticalScrollBar().setValue(gui.jsp.getVerticalScrollBar().getMaximum());  //默认最下方
	} // end method displayMessageLine

	// displays a dollar amount
	public void displayDollarAmount(double amount) {
		String aString = String.format("$%,.2f", amount);
		gui.addText(aString);
		gui.jsp.getVerticalScrollBar().setValue(gui.jsp.getVerticalScrollBar().getMaximum());  //默认最下方
	} // end method displayDollarAmount
} // end class Screen