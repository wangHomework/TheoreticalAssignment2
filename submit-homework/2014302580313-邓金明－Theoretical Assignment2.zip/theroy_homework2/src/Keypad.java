import java.util.Scanner; // program uses Scanner to obtain user input

public class Keypad {
	private Scanner input; // reads data from the command line
	// no-argument constructor initializes the Scanner
	private GUI gui;
	public Keypad(GUI gui) {
		this.gui = gui;
	} // end no-argument Keypad constructor

	// return an integer value entered by user
	public int getInput() {
		return gui.getInput();
	} // end method getInput
}