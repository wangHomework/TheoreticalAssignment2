import java.awt.*;
import java.awt.event.ActionEvent;

import javax.swing.*;

public class GUI
{

	public static void main(String[] args)
	{
		EventQueue.invokeLater(
				new Runnable()
				{
					public void run()
					{
						JFrame a=new ATMFrame();
						a.setTitle("ATMʾ��");
						a.setVisible(true);
						a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					}
				});
	}
}
class ATMFrame extends JFrame
{
	private static final long serialVersionUID = 1L;
	private ATM atm;
	private static final int WIDTH=800;
	private static final int HEIGHT=800;
	
	//����
	private AccountInterface accountInterface;
	private SelectInterface selectInterface;
	
	private DepositInterface depositInterface;
	public ATMFrame()
	{
		setSize(WIDTH,HEIGHT);
		setLocation(100,100);
		
		atm=new ATM();
		accountInterface=new AccountInterface(this.atm);	
		selectInterface=new SelectInterface(this.atm);
		depositInterface=new DepositInterface(this.atm);
		accountInterface.setInterface(selectInterface);
		selectInterface.setDeposit(depositInterface);
		depositInterface.setSelect(selectInterface);
		
		add(accountInterface);
		add(selectInterface);
		add(depositInterface);
		
		accountInterface.setVisible(true);
		selectInterface.setVisible(false);
		depositInterface.setVisible(false);
		Image img=new ImageIcon("java.jpg").getImage();
		setIconImage(img);
		
		
	}
}

//
class AccountInterface extends JPanel
{
	private SelectInterface selectInterface;
	
	private ATM atm;
	private static final int WIDTH=800;
	private static final int HEIGHT=800;
	
	//ȷ��
	public JButton ensure; 
	public JTextField accountNumber;
	public JPasswordField accountPassword;
	public void setInterface(SelectInterface selectInterface)
	{
		this.selectInterface=selectInterface;
	}
	private class EnsureAction extends AbstractAction
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			String account=accountNumber.getText().trim();
			String password=new String(accountPassword.getPassword());
			atm.run1(account, password);
			if(atm.getUser()==true)
			{
				AccountInterface.this.setVisible(false);
				selectInterface.setVisible(true);
			}
		}		
	}
	public AccountInterface(ATM atm)
	{
		this.atm=atm;
		this.setLayout(null);
		setSize(WIDTH,HEIGHT);
		//��ʼ��
		ensure=new JButton("OK");
		accountNumber=new JTextField(10);
		accountPassword=new JPasswordField(10);	
		JLabel welcome=new JLabel("��ӭʹ��");
		JLabel accountLabel=new JLabel("�˻�:");
		JLabel passwordLabel=new JLabel("����:");
		
		//�������
		add(welcome);
		welcome.setBounds(WIDTH/2-30,50,100,200);
		add(accountLabel);
		accountLabel.setBounds(150,200,80,40);
		add(accountNumber);
		accountNumber.setBounds(250,200,300,40);
		add(passwordLabel);
		passwordLabel.setBounds(150,300,80,40);
		add(accountPassword);
		accountPassword.setBounds(250,300,300,40);
		ensure.addActionListener(new EnsureAction());
		add(ensure);
		ensure.setBounds(340,400,120,40);
		this.atm=atm;
	}
}

//ѡ�������
class SelectInterface extends JPanel
{
	private ATM atm;
	//private ViewInterface viewInterface;
	//private WithdrawInterface withdrawInterface;
	private DepositInterface depositInterface;
	private static final int WIDTH=200;
	private static final int HEIGHT=200;
	private JButton viewButton;
	private JButton	withdrawButton;
	private JButton	depositButton;
	private JButton exitButton;
	public void setDeposit(DepositInterface depositInterface){this.depositInterface=depositInterface;}
	public SelectInterface(ATM atm)
	{
		this.atm=atm;
		this.setLayout(null);
		setSize(WIDTH,HEIGHT);
		JLabel prompt=new JLabel("��ѡ����Ҫ���еĲ���");
		
		viewButton=new JButton("���");
		withdrawButton=new JButton("ȡ��");
		depositButton=new JButton("���");
		exitButton=new JButton("�뿪");
		
		add(prompt);
		add(viewButton);
		add(withdrawButton);
		add(depositButton);
		add(exitButton);
		
		//���ð�ť��λ��
		prompt.setBounds(30,0,160,20);
		viewButton.setBounds(20, 40, 60, 20);
		withdrawButton.setBounds(100,40,60,20);
		depositButton.setBounds(20, 80, 60, 20);
		exitButton.setBounds(100,80,60,20);
	}

	//�뿪��ť��Ӧ����
	private class ExitAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			//SelectInterface.this.setVisible(false);
			System.exit(0);
		}
			
	}
}


class DepositInterface extends JPanel
{
	private ATM atm;
	private static final int WIDTH=200;
	private static final int HEIGHT=200;
	private JButton back;
	private JButton deposit20;
	private JButton deposit40;
	private JButton deposit60;
	private JButton deposit100;
	
	private SelectInterface selectInterface;
	public void setSelect(SelectInterface selectInterface){this.selectInterface=selectInterface;}
	
	
	
	private class DepositAction extends AbstractAction
	{
		private int amount;
		public DepositAction(int amount){this.amount=amount;};

		public void actionPerformed(ActionEvent e)
		{
		}
		
	}
	private class BackAction extends AbstractAction
	{
		public void actionPerformed(ActionEvent e)
		{
			DepositInterface.this.setVisible(false);
			selectInterface.setVisible(true);
		}
		
	}
	public DepositInterface(ATM atm)
	{	
		this.setLayout(null);
		setSize(WIDTH,HEIGHT);
		this.atm=atm;
		back=new JButton("BACK");
		deposit20=new JButton("20");
		deposit40=new JButton("40");
		deposit60=new JButton("60");
		deposit100=new JButton("100");
		JLabel prompt=new JLabel("���");
		
		back.addActionListener(new BackAction());
		deposit20.addActionListener(new DepositAction(20));
		deposit40.addActionListener(new DepositAction(40));
		deposit60.addActionListener(new DepositAction(60));
		deposit100.addActionListener(new DepositAction(100));
		
		add(back);
		add(deposit20);
		add(deposit40);
		add(deposit60);
		add(deposit100);
		add(prompt);
		
		prompt.setBounds(80,0,50,20);
		deposit20.setBounds(20, 40, 60, 20);
		deposit40.setBounds(100,40,60,20);
		deposit60.setBounds(20, 80, 60, 20);
		deposit100.setBounds(100,80,60,20);
		back.setBounds(40,110,100,20);
		
	}
}
