public class BalanceInquiry extends Transaction {

	public BalanceInquiry(int userAccountNumber, Screen atmScreen,
			BankDatabase atmBankDatabase) {
		// TODO Auto-generated constructor stub
		super(userAccountNumber, atmScreen, atmBankDatabase);
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		BankDatabase bankDatabase = getBankDatabase();
		Screen screen = getScreen();

		double availableBalance = bankDatabase
				.getAvailaleBalance(getAccountNumber());
		double totalBalance = bankDatabase.getTotalBalance(getAccountNumber());
		
		
		screen.displayMessageLine( "\nBalance Information:" );
		screen.displayMessage( " - Available balance: " );
		screen.displayDollarAmount( availableBalance );
		screen.displayMessage( "\n - Total balance: " );
		screen.displayDollarAmount( totalBalance );
		screen.displayMessageLine( "" );
		
	}

}
