import java.text.DecimalFormat;


public class Screen {

	
	public void displayMessage(String message) {
		// TODO Auto-generated method stub
		//System.out.print(message);
		//ATMFrame.textArea.insert(message, message.length());
		//ATMFrame.textArea.append(message);
		ATMFrame.showTextString+=message;
		ATMFrame.textArea.setText(ATMFrame.showTextString);
		
		int length_1 = ATMFrame.textArea.getText().length(); 
		ATMFrame.textArea.setCaretPosition(length_1);
	}
	public void displayMessageLine(String message) {
		// TODO Auto-generated method stub
		//System.out.println(message);
		//ATMFrame.textArea.insert(message+"\n", message.length());
//		ATMFrame.textArea.append(message+"\n");
//		int length_1 = ATMFrame.textArea.getText().length(); 
//		ATMFrame.textArea.setCaretPosition(length_1);
		ATMFrame.showTextString+=(message+"\n");
		ATMFrame.textArea.setText(ATMFrame.showTextString);
		
		int length_1 = ATMFrame.textArea.getText().length(); 
		ATMFrame.textArea.setCaretPosition(length_1);
	}
	public void displayDollarAmount(double amount) {
		//System.out.printf("$%,.2f",amount);
		//ATMFrame.textArea.insert("$"+amount+",.2f",Double.toString(amount).length());
		//ATMFrame.textArea.append("$"+amount+",.2f");
		
		DecimalFormat df = new DecimalFormat("######0.00");
		df.format(amount);
		ATMFrame.showTextString+=("$"+Double.toString(amount));
		ATMFrame.textArea.setText(ATMFrame.showTextString);
		
		int length_1 = ATMFrame.textArea.getText().length(); 
		ATMFrame.textArea.setCaretPosition(length_1);
		
		
	}

	

	
}
