//import java.util.Scanner;


public class Keypad {

	//private Scanner input;
	public int num;
	public boolean f=false;
	public int getInput() {
		
		f=false;
		//String str = "";
		
		 
		while(!f)
		{
			//if(ATMFrame.flag)
			System.out.print("");
				//ATMFrame.flag=false;
		}
		//str=ATMFrame.text;
		
		//num= Integer.parseInt(str);
		//ATMFrame.text = "";
		return num;
	
		
		// TODO Auto-generated method stub
		//return input.nextInt();
	}

}
