import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.awt.Font;

import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class ATMFrame extends JFrame {
	//
	private JPanel imagePanel;// ����JPanel���ñ���ͼƬ
	private ImageIcon background;// ����ͼƬ

	public static JTextArea textArea;
	public static String text = "";
	public static String showTextString="";

	//public static boolean flag = false;
	
	public ATM atm;

	int curWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
	int curHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

	public ATMFrame() {
		
		atm=new ATM();
		
		this.setResizable(false);
		this.setTitle("ATMȡ���");
		this.setSize(800, 600);
		this.setLocation((curWidth - 800) / 2, (curHeight - 600) / 2);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		background = new ImageIcon("background.png");// ����ͼƬ
		JLabel label = new JLabel(background);// �ѱ���ͼƬ��ʾ��һ����ǩ����
		// �ѱ�ǩ�Ĵ�Сλ������ΪͼƬ�պ�����������
		label.setBounds(0, 0, background.getIconWidth(),
				background.getIconHeight());
		// �����ݴ���ת��ΪJPanel���������÷���setOpaque()��ʹ���ݴ���͸��
		imagePanel = (JPanel) this.getContentPane();
		imagePanel.setOpaque(false);
		// ���ݴ���Ĭ�ϵĲ��ֹ�����ΪBorderLayout
		imagePanel.setLayout(null);
		// textArea.append("adadasdasdasd");
		
		
		JButton button_Num1 = new JButton("1");
		button_Num1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text = text + "1";
				showTextString+="1";
				textArea.setText(showTextString);
				//textArea.append("1");
			}
		});
		button_Num1.setFont(new Font("����", Font.PLAIN, 14));
		button_Num1.setBounds(52, 312, 50, 50);

		getContentPane().add(button_Num1);

		JButton button_Num2 = new JButton("2");
		button_Num2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text = text + "2";
				showTextString+="2";
				textArea.setText(showTextString);
				//textArea.append("2");
			}
		});
		button_Num2.setFont(new Font("����", Font.PLAIN, 14));
		button_Num2.setBounds(128, 312, 50, 50);
		getContentPane().add(button_Num2);

		JButton button_Num3 = new JButton("3");
		button_Num3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text = text + "3";
				showTextString+="3";
				textArea.setText(showTextString);
				//textArea.append("3");
			}
		});
		button_Num3.setFont(new Font("����", Font.PLAIN, 14));
		button_Num3.setBounds(201, 312, 50, 50);
		getContentPane().add(button_Num3);

		JButton button_Num4 = new JButton("4");
		button_Num4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text = text + "4";
				showTextString+="4";
				textArea.setText(showTextString);
				//textArea.append("4");
			}
		});
		button_Num4.setFont(new Font("����", Font.PLAIN, 14));
		button_Num4.setBounds(52, 376, 50, 50);
		getContentPane().add(button_Num4);

		JButton button_Num5 = new JButton("5");
		button_Num5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text = text + "5";
				showTextString+="5";
				textArea.setText(showTextString);
				//textArea.append("5");
			}
		});
		button_Num5.setFont(new Font("����", Font.PLAIN, 14));
		button_Num5.setBounds(128, 376, 50, 50);
		getContentPane().add(button_Num5);

		JButton button_Num6 = new JButton("6");
		button_Num6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text = text + "6";
				showTextString+="6";
				textArea.setText(showTextString);
				//textArea.append("6");
			}
		});
		button_Num6.setFont(new Font("����", Font.PLAIN, 14));
		button_Num6.setBounds(201, 376, 50, 50);
		getContentPane().add(button_Num6);

		JButton button_Num7 = new JButton("7");
		button_Num7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text = text + "7";
				showTextString+="7";
				textArea.setText(showTextString);
				//textArea.append("7");
			}
		});
		button_Num7.setFont(new Font("����", Font.PLAIN, 14));
		button_Num7.setBounds(52, 436, 50, 50);
		getContentPane().add(button_Num7);

		JButton button_Num8 = new JButton("8");
		button_Num8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text = text + "8";
				showTextString+="8";
				textArea.setText(showTextString);
				//textArea.append("8");
			}
		});
		button_Num8.setFont(new Font("����", Font.PLAIN, 14));
		button_Num8.setBounds(128, 436, 50, 50);
		getContentPane().add(button_Num8);

		JButton button_Num9 = new JButton("9");
		button_Num9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text = text + "9";
				showTextString+="9";
				textArea.setText(showTextString);
				//textArea.append("9");
			}
		});
		button_Num9.setFont(new Font("����", Font.PLAIN, 14));
		button_Num9.setBounds(201, 436, 50, 50);
		getContentPane().add(button_Num9);

		JButton button_Num0 = new JButton("0");
		button_Num0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				text = text + "0";
				showTextString+="0";
				textArea.setText(showTextString);
				//textArea.append("0");
			}
		});
		button_Num0.setFont(new Font("����", Font.PLAIN, 14));
		button_Num0.setBounds(52, 496, 50, 50);
		getContentPane().add(button_Num0);

		JButton button_Enter = new JButton("Enter");
		button_Enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//flag=true;
				atm.keypad.num=Integer.parseInt(text);
				atm.keypad.f=true;
				text="";
				
				//JOptionPane.showMessageDialog(button_Enter, text);
			}
		});
		button_Enter.setFont(new Font("����", Font.PLAIN, 14));
		button_Enter.setBounds(128, 496, 124, 25);
		getContentPane().add(button_Enter);

		JButton btnBackspace = new JButton("Backspace");// �˸�
		btnBackspace.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (text.length() == 0) {
					JOptionPane.showMessageDialog(btnBackspace, "�޷��˸�");
				} else {
					text = text.substring(0, text.length() - 1);
					showTextString = showTextString.substring(0, showTextString.length() - 1);
					textArea.setText(showTextString);
				}
			}
		});
		btnBackspace.setFont(new Font("����", Font.PLAIN, 14));
		btnBackspace.setBounds(128, 521, 124, 25);
		getContentPane().add(btnBackspace);
		
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setEditable(false);
				textArea.setLineWrap(true);
				textArea.setBounds(40, 10, 500, 151);
				getContentPane().add(textArea);
				textArea.setBorder(new EmptyBorder(0, 0, 0, 0));
				
				JScrollPane scroll= new JScrollPane(textArea);
				scroll.setBounds(173, 112, 504, 160);
				getContentPane().add(scroll);
				scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
				scroll.setVerticalScrollBarPolicy( 
						JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
				scroll.setBorder(new EmptyBorder(0, 0, 0, 0));

		JLabel label_textArea = new JLabel(new ImageIcon("bg3.png"));
		label_textArea.setBounds(107, 94, 604, 195);
		getContentPane().add(label_textArea);

		JLabel label_buttonSet = new JLabel(new ImageIcon("bg2.jpg"));
		label_buttonSet.setBounds(32, 299, 235, 261);
		getContentPane().add(label_buttonSet);

		JLabel label_TakeCash = new JLabel(new ImageIcon("1.png"));
		label_TakeCash.setBounds(313, 310, 423, 106);
		getContentPane().add(label_TakeCash);

		JLabel label_InsertEnvelope = new JLabel(new ImageIcon("2.jpg"));
		label_InsertEnvelope.setBounds(313, 435, 427, 106);
		getContentPane().add(label_InsertEnvelope);

		this.getLayeredPane().setLayout(null);
		// �ѱ���ͼƬ���ӵ��ֲ㴰�����ײ���Ϊ����
		this.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));
		this.setVisible(true);
	}

	//
	
	public static void main(String[] args) {
		//ATM theATM=new ATM();
		//theATM.run();
		ATMFrame theAtmFrame=new ATMFrame();
		theAtmFrame.atm.run();
	}

}
