/*
 * @2014302580304-JiangChenZhi-TheoreticalAssignment2
 */

import java.awt.*;


import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;


import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

import javax.swing.Icon;
import javax.swing.ImageIcon;


public class ATMGUI extends JFrame {
	
	
	
	public static JTextArea sp=new JTextArea();
	public static int i_con=0;

	public  ATMGUI(){
		setTitle("Automatic Teller Machine");
		Container container=getContentPane();
		container.setLayout(null);

		//��ʾ��
		sp.setLineWrap(true);
		JScrollPane panel1 = new JScrollPane(sp);
		panel1.setBounds(0, 0, 1000, 320);
		sp.setBounds(0, 0, 1000, 320);
		
		JPanel panel2=new JPanel();
		JPanel panel3=new JPanel();
		panel2.setLayout(null);
		panel2.setBounds(0, 320, 420, 480);
		
		//��������button
		JButton bt1=new JButton("1");
		JButton bt2=new JButton("2");
		JButton bt3=new JButton("3");
		JButton bt4=new JButton("4");
		JButton bt5=new JButton("5");
		JButton bt6=new JButton("6");
		JButton bt7=new JButton("7");
		JButton bt8=new JButton("8");
		JButton bt9=new JButton("9");
		JButton bt0=new JButton("0");
		JButton bte=new JButton("ENTER");
		
		
        //����buttonλ��
		bt7.setBounds(0, 0, 125, 100);
		bt8.setBounds(125, 0, 125, 100);
		bt9.setBounds(250, 0, 125, 100);
		bt4.setBounds(0, 100, 125, 100);
		bt5.setBounds(125, 100, 125, 100);
		bt6.setBounds(250, 100, 125, 100);
		bt1.setBounds(0, 200, 125, 100);
		bt2.setBounds(125, 200, 125, 100);
		bt3.setBounds(250, 200, 125, 100);
		bt0.setBounds(0, 300, 125, 100);
		bte.setBounds(125, 300, 250, 100);
		
		//��panel2����button
		panel2.add(bt7);
		panel2.add(bt8);
		panel2.add(bt9);
		panel2.add(bt4);
		panel2.add(bt5);
		panel2.add(bt6);
		panel2.add(bt1);
		panel2.add(bt2);
		panel2.add(bt3);
		panel2.add(bt0);
		panel2.add(bte);
		
		
		//ȡ����&�忨��
		panel3.setLayout(null);
		panel3.setBounds(375, 320, 625, 480);
		JButton button1=new JButton("Take cash here");
		button1.setBounds(0, 0, 625, 200);
		JButton button2=new JButton("Insert deposit envelope here");
		button2.setBounds(0, 200, 625, 200);
		panel3.add(button1);
		panel3.add(button2);
    	
		
		//�������������������panel���
		container.add(panel1);
		container.add(panel2);
		container.add(panel3);
		
		setBounds(0, 0, 1000, 750);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}

	public static void main(String[] args){
		new ATMGUI();
		ATM atm=new ATM();
		atm.run();
	}

}

