import java.io.File;

import com.github.kevinsawicki.http.HttpRequest;


public class GradeGet {

	public static void main(String[] args) {
				String Gradeurl = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Fri%20Oct%2016%202015%2016:38:26%20GMT+0800%20(%E4%B8%AD%E5%9B%BD%E6%A0%87%E5%87%86%E6%97%B6%E9%97%B4)";
				//��ȡ�ɼ�ҳ���url
				HttpRequest response = HttpRequest.get(Gradeurl);
				//��ȡ�ɼ�ҳ����Ϣ
				response.header("Cookie","JSESSIONID=E10FFA4812B3DA79A0BC45E28199BA3D.tomcat2");
			    //��ȡĳ�ε�¼���õ�cookieֵ
				String fName = "myGrade.html";
		        response.receive(new File(fName));
		        //ȷ���ļ���������
								
			
	}

}
