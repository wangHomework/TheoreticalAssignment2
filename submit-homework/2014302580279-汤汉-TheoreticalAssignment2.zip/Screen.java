
// Represents the screen of the ATM

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Screen extends JFrame implements ActionListener
{
    public final Keypad keypad = new Keypad();
    private final Container con = getContentPane();
    private final JPanel keyscreen = new JPanel();
    private final JTextArea showChoice = new JTextArea();
    private ArrayList<JButton> buts = new ArrayList<JButton>(12);
    private JScrollPane sp = new JScrollPane();
    private String input = "";
    public boolean pre = false;
    public Screen(){
        //create a window
        super("ATM");
        getContentPane().setLayout(null);
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setAutoRequestFocus(true);


        //key GUI
        keyscreen.setBounds(10,200,200,150);
        keyscreen.setBorder(BorderFactory.createRaisedBevelBorder());
        //create key screen pane
        ArrayList<String> size = new ArrayList<String>();
        size.add("60");
        size.add("30");
        for(int i=0; i!=12; i++){
            JButton b = new JButton();
            buts.add(b);
            b.setPreferredSize(new Dimension(Integer.parseInt(size.get(0)), Integer.parseInt(size.get(1))));
            b.addActionListener(this);
            b.setFocusable(false);
            if(i < 9){
                b.setText(String.valueOf(i + 1));
            }else{
                if(i == 9){
                    b.setText("取消");
                }else if(i == 10){
                    b.setText("0");
                }else{
                    b.setText("确定");
                }
            }
            keyscreen.add(b);
        }

        showChoice.setBounds(0,0,480,180);
        showChoice.setBackground(Color.white);
        showChoice.setBorder(BorderFactory.createRaisedBevelBorder());
        showChoice.setFont(new Font("Dialog", 0, 10));
        String str = "Welcome to ATM";
        showChoice.setText(str);

        sp.setViewportView(showChoice);
        con.add(sp);
        con.add(showChoice);
        con.add(keyscreen);
    }

    public void actionPerformed(ActionEvent actionEvent){
        switch (actionEvent.getActionCommand()){
            case "取消":
                String temp = showChoice.getText();
                temp  = temp.replaceFirst(input,"");
                input = "";
                showChoice.setText(temp);
                break;
            case "确定":
                pre = true;
                keypad.setInput(input);
                System.out.print(input+"\n");
                input = "";
                break;
            default:
                showChoice.setText(showChoice.getText()+actionEvent.getActionCommand());
                input += actionEvent.getActionCommand();
                break;
        }
    }


    // display a message without a carriage return
    public void displayMessage( String message )
    {
        showChoice.append(message);
    } // end method displayMessage

    // display a message with a carriage return
    public void displayMessageLine( String message )
    {
        showChoice.append( message);
    } // end method displayMessageLine

    // displays a dollar amount
    public void displayDollarAmount( double amount )
    {
        showChoice.append(String.valueOf(amount));
    } // end method displayDollarAmount

    public boolean getpre(){
        return pre;
    }
} // end class Screen