
public class Keypad
{
    private String input = ""; // reads data from the command line
    // no-argument constructor initializes the Scanner
    public void setInput(String s){
        input = s;
    }

    // return an integer value entered by user
    public int getInput()
    {
        if(input == ""){ return -1;}
        return Integer.parseInt(input);
        // we assume that user enters an integer
    } // end method getInput
}