
public class Deposit extends Transaction
 {
 private double amount; // amount to deposit 
 private DepositSlot depositSlot; // reference to deposit slot
 private final static int CANCELED = 0; // constant for cancel option

 // Deposit constructor
 public Deposit( int userAccountNumber, gui2014302580200 gui,
 BankDatabase atmBankDatabase,
 DepositSlot atmDepositSlot )
 {
 // initialize superclass variables
 super( userAccountNumber, gui , atmBankDatabase );

 // initialize references to keypad and deposit slot
 depositSlot = atmDepositSlot;
 } // end Deposit constructor

 // perform transaction
 @Override
 public void execute(gui2014302580200 gui)
 {
 BankDatabase bankDatabase = getBankDatabase(); // get reference

 amount = promptForDepositAmount(gui); // get deposit amount from user

 // check whether user entered a deposit amount or canceled
 if ( amount != CANCELED )
 {
 // request deposit envelope containing specified amount
 gui.displayMessage(
 "\nPlease insert a deposit envelope containing " );
 gui.displayDollarAmount( amount );
 gui.displayMessage( "." );

 // receive deposit envelope
 boolean envelopeReceived = depositSlot.isEnvelopeReceived();

 // check whether deposit envelope was received
 if ( envelopeReceived )
 {
 gui.displayMessage( "\nYour envelope has been " +
 "received.\nNOTE: The money just deposited will not " +
 "be available until we verify the amount of any " +
 "enclosed cash and your checks clear." );
//credit account to reflect the deposit
 bankDatabase.credit( getAccountNumber(), amount );
 } // end if
 else // deposit envelope not received
 {
 gui.displayMessage( "\nYou did not insert an " +
 "envelope, so the ATM has canceled your transaction." );
 } // end else
 } // end if
 else // user canceled instead of entering amount
 {
 gui.displayMessage( "\nCanceling transaction..." );
 } // end else
 } // end method execute

 // prompt user to enter a deposit amount in cents
 private double promptForDepositAmount(gui2014302580200 gui)
 {
 // display the prompt
 gui.displayMessage( "\nPlease enter a deposit amount in " +
 "CENTS (or 0 to cancel): " );
 int input = gui.getMessage();// receive input of deposit amount

 // check whether the user canceled or entered a valid amount
 if ( input == CANCELED )
 return CANCELED;
 else
 {
 return ( double ) input / 100; // return dollar amount
 } // end else
 } // end method promptForDepositAmount
 } // end class Deposit
