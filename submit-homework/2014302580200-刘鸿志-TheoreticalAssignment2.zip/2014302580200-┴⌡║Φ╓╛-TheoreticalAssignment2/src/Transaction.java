
public abstract class Transaction
 {
 private int accountNumber; // indicates account involved 
 private BankDatabase bankDatabase; // account info database

 // Transaction constructor invoked by subclasses using super()
 public Transaction( int userAccountNumber,gui2014302580200 gui, BankDatabase atmBankDatabase )
 {
 accountNumber = userAccountNumber;
 bankDatabase = atmBankDatabase;
 } // end Transaction constructor

 // return account number
 public int getAccountNumber()
 {
	 return accountNumber;
 }
  // end method getAccountNumber
 // return reference to screen
 
//return reference to bank database
 public BankDatabase getBankDatabase()
 {
 return bankDatabase;
 } // end method getBankDatabase

 abstract public void execute(gui2014302580200 gui);
 } // end class Transaction