import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;



public class gui2014302580200 extends JFrame {
private TextArea Screen;
private TextArea Message;
private int message ;
private boolean outputall;
public gui2014302580200() 
{
		message = 0;
		JFrame j = new JFrame("My ATM");
		j.setLayout(null);
		j.setVisible(true);
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		j.setBounds(100, 100, 530, 380);
		this.getKeypad(j);		//���ü���
		this.addScreen(j);		//������Ļ
		this.addMessage(j);
		this.getCashDispenser(j);
		this.getdepositslot(j);
}

public void displayMessage(String words)
{
	Screen.setText(Screen.getText()+"\n" + words + "\n");
} 

public void displayDollarAmount( Double amount )
{
	Screen.setText(Screen.getText()+"\n" + amount.toString());
}

public int getMessage()
{
	outputall = false;
	while(!outputall)
	{	
		System.out.print("");
	}
	int outMessage = message;
	message = 0;
	return outMessage;
}

private Button addButton(int x , int y , int width , int height , String text , Frame f)
{
	f.setLayout(null);
	Button bt = new Button(text);
	bt.setBounds(x, y, width, height);
	bt.setBackground(Color.lightGray);
	f.add(bt);
	return bt;
}

private void getKeypad(Frame f)
{
	Button bt_1 =  addButton(30 ,130,60,40,"1",f);
	Button bt_2 =  addButton(100,130,60,40,"2",f);
	Button bt_3 =  addButton(170,130,60,40,"3",f);
		 
	Button bt_4 =  addButton(30 ,180,60,40,"4",f);
	Button bt_5 =  addButton(100,180,60,40,"5",f);
	Button bt_6 =  addButton(170,180,60,40,"6",f);
		 
	Button bt_7 =  addButton(30 ,230,60,40,"7",f);
	Button bt_8 =  addButton(100,230,60,40,"8",f);
	Button bt_9 =  addButton(170,230,60,40,"9",f);
		 
	Button bt_0 =  addButton(30 ,280,60,40,"0",f);
	Button bt_Enter =  addButton(100,280,130,40,"Enter",f);	 
	
	bt_1.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			Message.setText(Message.getText()+"1");
			message = message * 10 + 1;
			// TODO �Զ����ɵķ������
		}
		
	});
	bt_2.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			Message.setText(Message.getText()+"2");
			
			message = message * 10 + 2;
			// TODO �Զ����ɵķ������
		}
		
	});
	bt_3.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			Message.setText(Message.getText()+"3");
			message = message * 10 + 3;
			// TODO �Զ����ɵķ������
		}
		
	});
	bt_4.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			Message.setText(Message.getText()+"4");
			message = message * 10 + 4;
			// TODO �Զ����ɵķ������
		}
		
	});
	bt_5.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			Message.setText(Message.getText()+"5");
			message = message * 10 + 5;
			// TODO �Զ����ɵķ������
		}
		
	});
	bt_6.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			Message.setText(Message.getText()+"6");
			message = message * 10 + 6;
			// TODO �Զ����ɵķ������
		}
		
	});
	bt_7.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			Message.setText(Message.getText()+"7");
			message = message * 10 + 7;
			// TODO �Զ����ɵķ������
		}
		
	});
	bt_8.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			Message.setText(Message.getText()+"8");
			message = message * 10 + 8;
			// TODO �Զ����ɵķ������
		}
		
	});
	bt_9.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			Message.setText(Message.getText()+"9");
			message = message * 10 + 9;
			// TODO �Զ����ɵķ������
		}
		
	});
	bt_0.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			Message.setText(Message.getText()+"0");
			message = message * 10 + 0;
			// TODO �Զ����ɵķ������
		}
		
	});
	bt_Enter.addActionListener(new ActionListener()
	{
		public void actionPerformed(ActionEvent e)
		{
			message = Integer.parseInt( Message.getText());
			outputall = true;
			Message.setText(null);
			
			
			// TODO �Զ����ɵķ������
		}
		
	});
	
}



private void addScreen(Frame f)
{
	f.setLayout(null);
	Screen = new TextArea();
	Screen.setBounds(30, 10, 300, 100);
	f.add(Screen);
}

private void addMessage(Frame f)
{
	f.setLayout(null);
	Message = new TextArea();
	Message.setBounds(350, 10, 150, 100);
	f.add(Message);
}

private void getCashDispenser(Frame f)
{
	f.setLayout(null);
	Label CashDispenser = new Label();
	CashDispenser.setText("Take cash here");
	CashDispenser.setBounds(310, 130, 230, 50);
	f.add(CashDispenser);
}

private void getdepositslot(Frame f)
{
	f.setLayout(null);
	Label Depositslot = new Label();
	Depositslot.setText("Insert deposit envolope here");
	Depositslot.setBounds(280, 240, 260, 30);
	f.add(Depositslot);
}
	
	
}
