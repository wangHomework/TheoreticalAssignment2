public class BalanceInquiry extends Transaction
 {
 // BalanceInquiry constructor
 public BalanceInquiry( int userAccountNumber, gui2014302580200 gui,
 BankDatabase atmBankDatabase )
 {
 super( userAccountNumber, gui , atmBankDatabase );
 } // end BalanceInquiry constructor

 // performs the transaction
 @Override
 public void execute(gui2014302580200 gui)
 {
	// get references to bank database and screen
	  BankDatabase bankDatabase = getBankDatabase();
	 
	  // get the available balance for the account involved
	  double availableBalance =
	  bankDatabase.getAvailableBalance( getAccountNumber() );
	 
	  // get the total balance for the account involved
	  double totalBalance =
	  bankDatabase.getTotalBalance( getAccountNumber() );
	 
	  // display the balance information on the screen
	  gui.displayMessage( "\nBalance Information:" );
	  gui.displayMessage( " - Available balance: " );
	  gui.displayDollarAmount( availableBalance );
	  gui.displayMessage( "\n - Total balance: " );
	  gui.displayDollarAmount( totalBalance );
	  gui.displayMessage( "" );
	  } // end method execute


}
 