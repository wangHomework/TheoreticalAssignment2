package bank;

public class Bank {
	@SuppressWarnings("unused")
	private float balance=0;//���
	private String accountNumber;//�˺�
	private String password;//����
	public Bank(String a,String b,float c)
	{
		accountNumber=a;
		password=b;
		balance=c;
	}
	//��ȡ�˺�
	public String getAccountNumber()
	{
		return accountNumber;
	}
	//��������
	public void setPwd(String s)
	{
		password=s;
	}
	//�ж��˺��Ƿ����
	public boolean getAccountNuber(String accountNuber)
	{
		if(accountNumber.equals(accountNuber))
		{
			return true;
		}
		else {
			return false;
		}
	}
	//�ж������Ƿ���ȷ
	public boolean checkPassword(String pwd)
	{
		if(password.equals(pwd))
			return true;
		return false;
	}
	//��ȡ���
	public float getBalance()
	{
		return balance;
	}
	//���
	public void  deposit(float number)
	{
		balance=balance+number;
	}
	//ȡ��
	public boolean withdraw(float number)
	{
		if(balance<number)
			return false;
		balance-=number;
		return true;
	}
	
}
