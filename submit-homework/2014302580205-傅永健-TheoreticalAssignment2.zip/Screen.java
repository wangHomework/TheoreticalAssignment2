import java.awt.Font;

public class Screen
{
	private GUI gui;
	public Screen(GUI theGUI){
		gui=theGUI;
	}
 // display a message without a carriage return
 public void displayMessage( String message )
 {
 System.out.print( message );
 gui.getOutTextArea().setFont(new Font("",1,20));
 gui.getOutTextArea().append(message+"\n");
 } // end method displayMessage

 // display a message with a carriage return
 public void displayMessageLine( String message )
 {
 System.out.println( message );
 gui.getOutTextArea().append(message+"\n");
 } // end method displayMessageLine

 // displays a dollar amount
 public void displayDollarAmount( double amount )
 {
 System.out.printf( "$%,.2f", amount );
 gui.getOutTextArea().append((String.valueOf(amount))+"\n");
 } // end method displayDollarAmount
} // end class Screen