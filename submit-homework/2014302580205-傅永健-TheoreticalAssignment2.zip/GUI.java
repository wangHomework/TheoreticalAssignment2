import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.CyclicBarrier;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
public class GUI {
	private JFrame frame=new JFrame();
	private JPanel out=new JPanel();
	private JPanel in=new JPanel();
	private JPanel decorate=new JPanel();
	private JLabel inLabel=new JLabel();
	private JButton inButton[]=new JButton[11];
	private Keypad keypad;
	private JTextArea outText=new JTextArea();
	private JScrollPane scrollPane = new JScrollPane(outText);
	private int current=0;
	public GUI() {
		for(int i=9;i>=0;i--){
			inButton[i]=new JButton(String.valueOf(i));
			frame.add(inButton[i]);
			inButton[i].setVisible(true);
			
		}
		inButton[10]=new JButton("enter");
		frame.add(inButton[10]);
		
		//frame.add(out);
		//frame.add(in);
		//frame.add(decorate);
		
		GridBagLayout  layout=new GridBagLayout();
		//GridBagLayout layout2=new GridBagLayout();
		//layout.maximumLayoutSize(out);
		//layout2.maximumLayoutSize(in);
		GridBagConstraints c[]=new GridBagConstraints[13];
		for(int i=0;i<13;i++){
			c[i]=new GridBagConstraints();
			c[i].fill=GridBagConstraints.BOTH;
			c[i].weightx=1;
			//c[i].weighty=1;
		}
		
		c[11].weighty=5;
		c[0].gridx=0;
		c[0].gridy=3+5;
		for(int i=1;i<10;i++){
			c[i].gridx=(i-1)%3;
			c[i].gridy=2-(int) (i/3.5)+5;
		}
		c[10].gridwidth=2;
		c[10].gridx=1;
		c[10].gridy=3+5;
		for(int i=0;i<=10;i++){
			layout.addLayoutComponent(inButton[i], c[i]);
		}
		c[11].gridheight=3;
		c[11].gridwidth=3;
		c[11].gridy=0;
		c[11].gridx=0;
		c[12].gridheight=2;
		c[12].gridwidth=3;
		c[12].gridy=3;
		c[12].gridx=0;
		//outText.setBackground(Color.gray);
		outText.setLineWrap(true);
		outText.setWrapStyleWord(true);
		//scrollPane.setSize(600,400);
		layout.addLayoutComponent(scrollPane, c[11]);
		layout.addLayoutComponent(inLabel, c[12]);
		//JScrollPane scrollPane = new JScrollPane(outText);
		scrollPane.setVisible(true);
		//scrollPane.setSize(100, 300);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		//out.add(scrollPane);
		
		/*in.setVisible(true);
		in.setLayout(layout);
		in.add(inButton[10]);
		in.setBackground(Color.black);
		in.setSize(800,300);
		in.setLocation(0, 300);*/
		attchListener();
		
		
		/*out.add(outText);
		out.add(inLabel);
		out.setLayout(layout2);
		out.setVisible(false);
		//out.setBackground(Color.GRAY);
		out.setSize(800,300);
		out.setLocation(0, 0);*/
		frame.add(scrollPane);
		frame.add(inLabel);
		frame.setSize(800, 600);
		frame.setLayout(layout);
		
		
		frame.setVisible(true);
		
		//frame.add(outText);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public JTextArea getOutTextArea(){
		return outText;
	}
	public void attchListener(){
		inButton[1].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					current=current*10+1;
					inLabel.setText(String.valueOf(current));
				}
			});
		inButton[2].addActionListener(new ActionListener() {
			@Override
					public void actionPerformed(ActionEvent e) {
					current=current*10+2;
					inLabel.setText(String.valueOf(current));
				}
			});
		inButton[3].addActionListener(new ActionListener() {
			@Override
					public void actionPerformed(ActionEvent e) {
					current=current*10+3;
					inLabel.setText(String.valueOf(current));
				}
			});
		inButton[0].addActionListener(new ActionListener() {
			@Override
					public void actionPerformed(ActionEvent e) {
					current=current*10+0;
					inLabel.setText(String.valueOf(current));
				}
			});
		inButton[4].addActionListener(new ActionListener() {
			@Override
					public void actionPerformed(ActionEvent e) {
					current=current*10+4;
					inLabel.setText(String.valueOf(current));
				}
			});
		inButton[5].addActionListener(new ActionListener() {
			@Override
					public void actionPerformed(ActionEvent e) {
					current=current*10+5;
					inLabel.setText(String.valueOf(current));
				}
			});
		inButton[9].addActionListener(new ActionListener() {
			@Override
					public void actionPerformed(ActionEvent e) {
					current=current*10+9;
					inLabel.setText(String.valueOf(current));
				}
			});
		inButton[6].addActionListener(new ActionListener() {
			@Override
					public void actionPerformed(ActionEvent e) {
					current=current*10+6;
					inLabel.setText(String.valueOf(current));
				}
			});
		inButton[7].addActionListener(new ActionListener() {
			@Override
					public void actionPerformed(ActionEvent e) {
					current=current*10+7;
					inLabel.setText(String.valueOf(current));
				}
			});
		inButton[8].addActionListener(new ActionListener() {
			@Override
					public void actionPerformed(ActionEvent e) {
					current=current*10+8;
					inLabel.setText(String.valueOf(current));
				}
			});
		inButton[10].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				keypad.setCurrent(current);
				current=0;
				//try {
				//	fos.write(current);
				//} catch (IOException e1) {
				//	// TODO �Զ����ɵ� catch ��
				//	e1.printStackTrace();
				//}
				//outLabel.setText("ok");
			}	
		});
		}
	public void setKeypad(Keypad theKeypad){
		keypad=theKeypad;
	}

	
}
