import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad
{	
	private int current=-1;
	private InputStream in;
	private Scanner input; // reads data from the command line
	// no-argument constructor initializes the Scanner
	public Keypad()
	 {
		in=System.in;
		input = new Scanner( in );
		
	 } // end no-argument Keypad constructor
	
 	// return an integer value entered by user
 	public int getInput() //throws FileNotFoundException
 	{
 		//FileInputStream ins=new FileInputStream("temp");
 		//input=new Scanner(ins);
 	//	return input.nextInt(); // we assume that user enters an integer
 		int temp=current;
 		//current=-1;
 		return temp;
 	} // end method getInput
 	
 	public void setCurrent(int num){
 		current=num;
 	}
 	public void setStream(InputStream input){
 		in=input;
 	}
 	public int getCurrent(){
 		return current;
 	}
 	public InputStream getStream(){
 		return in;
 	}
} // end class Keypad