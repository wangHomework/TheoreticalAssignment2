import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class ATMFrame extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ATM atm=new ATM();
	//������ť0~9��enter
	private JButton jbtnumber0=new JButton(""+0);
	private JButton jbtnumber1=new JButton(""+1);
	private JButton jbtnumber2=new JButton(""+2);
	private JButton jbtnumber3=new JButton(""+3);
	private JButton jbtnumber4=new JButton(""+4);
	private JButton jbtnumber5=new JButton(""+5);
	private JButton jbtnumber6=new JButton(""+6);
	private JButton jbtnumber7=new JButton(""+7);
	private JButton jbtnumber8=new JButton(""+8);
	private JButton jbtnumber9=new JButton(""+9);
	private JButton jbtenter=new JButton("Enter");
	private JButton jbtdelete=new JButton("Delete");
	private JTextArea jpTextArea=new JTextArea(10,10);
	public int number=0;
	public String currentcontent="";
	public ATMFrame(){
		jpTextArea.setFont(new Font("Serif",Font.BOLD,16));//�����ı�����
		jpTextArea.setLineWrap(true);//�����Զ����й���
		jpTextArea.setWrapStyleWord(true);//������в����ֹ���
		jpTextArea.setEditable(false);//��t1��Ϊ���ɱ༭
		//�ض��嵽ͨ���ı��������������������
		System.setOut(new StreamToTextArea(System.out,jpTextArea));	
		//�Ѱ�ť�ӵ�panel1
		JPanel panel1=new JPanel();
		panel1.setLayout(new GridLayout(4,3));
		panel1.add(jbtnumber1);
		panel1.add(jbtnumber2);
		panel1.add(jbtnumber3);
		panel1.add(jbtnumber4);
		panel1.add(jbtnumber5);
		panel1.add(jbtnumber6);
		panel1.add(jbtnumber7);
		panel1.add(jbtnumber8);
		panel1.add(jbtnumber9);
		panel1.add(jbtnumber0);
		panel1.add(jbtenter);
		panel1.add(jbtdelete);
		//��ȡ��ǩ�ӵ�panel2
		JPanel panel2=new JPanel();
		panel2.setLayout(new GridLayout(2,1,0,10));
		JPanel panel21=new JPanel(new GridLayout(2,1,0,0));
		JPanel panel22=new JPanel(new GridLayout(2,1,0,0));
		panel21.setBorder(new LineBorder(Color.GRAY,5));
		panel22.setBorder(new LineBorder(Color.GRAY,5));
		JLabel l1=new JLabel();
		JLabel l2=new JLabel();
		Border lineBorder=new LineBorder(Color.BLACK,2);
		l1.setBorder(lineBorder);
		l2.setBorder(lineBorder);
		l2.setBorder(lineBorder);
		JLabel jlbltakecash =new JLabel("Take cash here",SwingConstants.CENTER);
		JLabel jlblinsertcard =new JLabel("Insert deposit envelope here",SwingConstants.CENTER);
		panel21.add(jlbltakecash);		
		panel21.add(l1);
		panel22.add(jlblinsertcard);
		panel22.add(l2);
		panel2.add(panel21);
		panel2.add(panel22);
		//�ı���ӵ�panel3
		JPanel panel3 =new JPanel();
		jpTextArea.setSize(200,100 );
		panel3.add(jpTextArea);
		//�������ּ��ʹ�ȡ��panel4
		JPanel panel4=new JPanel();
		panel4.add(panel1,BorderLayout.EAST);
		panel4.add(panel2, BorderLayout.WEST);
		add(new JScrollPane(jpTextArea),BorderLayout.NORTH);
		//�����������ӵ�frame
		add(panel3,BorderLayout.CENTER);
		add(panel4,BorderLayout.SOUTH);
		//���Ӽ�����
		ButtonListener listener=new ButtonListener();
		jbtnumber1.addActionListener(listener);
		jbtnumber2.addActionListener(listener);
		jbtnumber3.addActionListener(listener);
		jbtnumber4.addActionListener(listener);
		jbtnumber5.addActionListener(listener);
		jbtnumber6.addActionListener(listener);
		jbtnumber7.addActionListener(listener);
		jbtnumber8.addActionListener(listener);
		jbtnumber9.addActionListener(listener);
		jbtnumber0.addActionListener(listener);
		jbtenter.addActionListener(listener);
		jbtdelete.addActionListener(listener);
	}//���캯��
	class ButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			
			if(e.getSource()==jbtnumber0){ number=number*10;jpTextArea.append("0");}
			else if(e.getSource()==jbtnumber1){ number=number*10+1;jpTextArea.append("1");}
			else if(e.getSource()==jbtnumber2){ number=number*10+2;jpTextArea.append("2");}
			else if(e.getSource()==jbtnumber3){ number=number*10+3;jpTextArea.append("3");}
			else if(e.getSource()==jbtnumber4){ number=number*10+4;jpTextArea.append("4");}
			else if(e.getSource()==jbtnumber5){ number=number*10+5;jpTextArea.append("5");}
			else if(e.getSource()==jbtnumber6){ number=number*10+6;jpTextArea.append("6");}
			else if(e.getSource()==jbtnumber7){ number=number*10+7;jpTextArea.append("7");}
			else if(e.getSource()==jbtnumber8){ number=number*10+8;jpTextArea.append("8");}
			else if(e.getSource()==jbtnumber9){ number=number*10+9;jpTextArea.append("9");}
			else if(e.getSource()==jbtenter){
				
				atm.keypad.input=number;	
				atm.keypad.run=1;
				number=0;
				//System.out.print(""+number);
				}
			else if(e.getSource()==jbtdelete){
				currentcontent=jpTextArea.getText();
				currentcontent=currentcontent.substring(0,currentcontent.length()-1);
				jpTextArea.setText(currentcontent);
				number=number/10;
				
			}
		}
	}//class ButtonListener end
	public static void main( String[] args ){
		ATMFrame MyATMFrame=new ATMFrame();
		//��ʾ���
		MyATMFrame.setTitle("ATM");
		MyATMFrame.pack();
		MyATMFrame.setLocationRelativeTo(null);
		MyATMFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MyATMFrame.setVisible(true);
		MyATMFrame.atm.run();
	}//end the main
}//end class ATMFrame