package view;

import java.awt.Color;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import model.ATM;


public class ATMWithGUI {
	private PrintStream outputStream;
	public ATM atm;
	private boolean inputOrNot;
	private String input;
	private JFrame ATM;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
			
					ATMWithGUI window = new ATMWithGUI();
					window.ATM.setVisible(true);
					window.atm.run();
				
		
	}

	/**
	 * Create the application.
	 */
	public ATMWithGUI() {
		
		initialize();
		
		atm = new ATM();
		
		
	}

	/**
	 * Initialize the contents of the frame.
	 */

	private void initialize() {
		ATM = new JFrame();
		ATM.setTitle("ATM");
		ATM.setAlwaysOnTop(true);
		ATM.setBounds(100, 100, 489, 462);
		ATM.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ATM.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(118, 37, 238, 168);
		ATM.getContentPane().add(scrollPane);
		JTextArea Screen = new JTextArea();
		scrollPane.setViewportView(Screen);
		Screen.setLineWrap(true);
		Screen.setWrapStyleWord(true);
		outputStream = new PrintStream(System.out){
		      public void println(String message) {
		        Screen.append(message + "\n");
		        Screen.setCaretPosition(Screen.getText().length());
		      }
		      public void print(String message){
		    	  Screen.append(message);
		      Screen.setCaretPosition(Screen.getText().length());}
		      
		      public void print(double num){
		    	  Screen.append(String.valueOf(num));
		      Screen.setCaretPosition(Screen.getText().length());}
		      
		      };
		      
		      System.setOut(outputStream);
		
		JButton btn_num1 = new JButton("1");
		btn_num1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(inputOrNot==false){
					input="1";
					inputOrNot=true;
					 Screen.append("1");
					return;
				}
				if(inputOrNot==true){
					input=input+"1";
				}
				
				Screen.append("1");
			}
		});
		btn_num1.setBounds(126, 230, 54, 53);
		ATM.getContentPane().add(btn_num1);
		
		JButton btn_num2 = new JButton("2");
		btn_num2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(inputOrNot==false){
					input="2";
					inputOrNot=true;
					 Screen.append("2");
					return;
				}
				if(inputOrNot==true){
					input=input+"2";
				}
				
				 Screen.append("2");
			}
		});
		btn_num2.setBounds(181, 230, 54, 53);
		ATM.getContentPane().add(btn_num2);
		
		JButton btn_num3 = new JButton("3");
		btn_num3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(inputOrNot==false){
					input="3";
					inputOrNot=true;
					 Screen.append("3");
					return;
				}
				if(inputOrNot==true){
					input=input+"3";
				}
				
				Screen.append("3");
			}
		});
		btn_num3.setBounds(236, 230, 54, 53);
		ATM.getContentPane().add(btn_num3);
		
		JButton btn_num4 = new JButton("4");
		btn_num4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(inputOrNot==false){
					input="4";
					inputOrNot=true;
					 Screen.append("4");
					return;
				}
				if(inputOrNot==true){
					input=input+"4";
				}
				
				 Screen.append("4");
			}
		});
		btn_num4.setBounds(126, 288, 54, 53);
		ATM.getContentPane().add(btn_num4);
		
		JButton btn_num5 = new JButton("5");
		btn_num5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(inputOrNot==false){
					input="5";
					inputOrNot=true;
					 Screen.append("5");
					return;
				}
				if(inputOrNot==true){
					input=input+"5";
				}
				
				Screen.append("5");
			}
		});
		btn_num5.setBounds(181, 288, 54, 53);
		ATM.getContentPane().add(btn_num5);
		
		JButton btn_num6 = new JButton("6");
		btn_num6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(inputOrNot==false){
					input="6";
					inputOrNot=true;
					 Screen.append("6");
					return;
				}
				if(inputOrNot==true){
					input=input+"6";
				}
				
				Screen.append("6");
			}
		});
		
		btn_num6.setBounds(236, 288, 54, 53);
		ATM.getContentPane().add(btn_num6);
		
		JButton btn_num7 = new JButton("7");
		btn_num7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(inputOrNot==false){
					input="7";
					inputOrNot=true;
					 Screen.append("7");
					return;
				}
				if(inputOrNot==true){
					input=input+"7";
				}
				 
				Screen.append("7");
			}
		});
		btn_num7.setBounds(126, 346, 54, 53);
		ATM.getContentPane().add(btn_num7);
		
		JButton btn_num8 = new JButton("8");
		btn_num8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(inputOrNot==false){
					input="8";
					inputOrNot=true;
					 Screen.append("8");
					return;
				}
				if(inputOrNot==true){
					input=input+"8";
				}
				
				Screen.append("8");
			}
		});
		btn_num8.setBounds(181, 346, 54, 53);
		ATM.getContentPane().add(btn_num8);
		
		JButton btn_num9 = new JButton("9");
		btn_num9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(inputOrNot==false){
					input="9";
					inputOrNot=true;
					 Screen.append("9");
					return;
				}
				if(inputOrNot==true){
					input=input+"9";
				}
				
				 Screen.append("9");
			}
		});
		btn_num9.setBounds(236, 346, 54, 53);
		ATM.getContentPane().add(btn_num9);
		
		JButton btn_num0 = new JButton("0");
		btn_num0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(inputOrNot==false){
					input="0";
					inputOrNot=true;
					 Screen.append("0");
					return;
				}
				if(inputOrNot==true){
					input=input+"0";
				}
				
				
				 Screen.append("0");
			}
		});
		btn_num0.setBounds(291, 230, 54, 53);
		ATM.getContentPane().add(btn_num0);
		
		JButton btn_confirm = new JButton("确认");
		btn_confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					atm.keypad.num=Integer.parseInt(input);
					atm.keypad.input=true;
					input="";
					//Screen.setText("");
				
			}
		});
		
		btn_confirm.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		btn_confirm.setForeground(Color.RED);
		btn_confirm.setBounds(291, 295, 54, 104);
		ATM.getContentPane().add(btn_confirm);
		
		JButton btn_balance = new JButton("Balance ");
		btn_balance.setToolTipText("");
		btn_balance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(inputOrNot==false){
					input="1";
					inputOrNot=true;
					
					return;
				}
				if(inputOrNot==true){
					input=input+"1";
					btn_confirm.doClick();
				}
				
			}
		});

		btn_balance.setBounds(6, 28, 78, 68);
		ATM.getContentPane().add(btn_balance);
		
		JButton btn_deposit = new JButton("Deposit");
		btn_deposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(inputOrNot==false){
					input="3";
					inputOrNot=true;
					
					return;
				}
				if(inputOrNot==true){
					input=input+"3";
					btn_confirm.doClick();
				}
				
			}
		});
		btn_deposit.setBounds(6, 137, 85, 68);
		ATM.getContentPane().add(btn_deposit);
		
		JButton btn_withdrawl = new JButton("Withdrawl");
		btn_withdrawl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(inputOrNot==false){
					input="2";
					inputOrNot=true;
					
					return;
				}
				if(inputOrNot==true){
					input=input+"2";
					btn_confirm.doClick();
				}
				
			}
		});
		btn_withdrawl.setBounds(394, 28, 85, 68);
		ATM.getContentPane().add(btn_withdrawl);
		
		JButton btn_exit = new JButton("Exit");
		btn_exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(inputOrNot==false){
					input="4";
					inputOrNot=true;
					
					return;
				}
				if(inputOrNot==true){
					input=input+"4";
					btn_confirm.doClick();
				}
			
			}
		});
		btn_exit.setBounds(394, 137, 85, 68);
		ATM.getContentPane().add(btn_exit);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(9, 230, 82, 169);
		ATM.getContentPane().add(scrollPane_1);
		
		JTextArea txtrTakeCashHere = new JTextArea();
		txtrTakeCashHere.setBackground(Color.CYAN);
		txtrTakeCashHere.setWrapStyleWord(true);
		txtrTakeCashHere.setEditable(false);
		txtrTakeCashHere.setLineWrap(true);
		scrollPane_1.setViewportView(txtrTakeCashHere);
		txtrTakeCashHere.setText("take           cash           here");
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(397, 230, 82, 169);
		ATM.getContentPane().add(scrollPane_2);
		
		JTextArea txtrInsertDepositEnvelope = new JTextArea();
		txtrInsertDepositEnvelope.setBackground(Color.CYAN);
		txtrInsertDepositEnvelope.setText("insert           deposit        envelope      here");
		txtrInsertDepositEnvelope.setWrapStyleWord(true);
		txtrInsertDepositEnvelope.setLineWrap(true);
		txtrInsertDepositEnvelope.setEditable(false);
		scrollPane_2.setViewportView(txtrInsertDepositEnvelope);

		
		
	}
}
