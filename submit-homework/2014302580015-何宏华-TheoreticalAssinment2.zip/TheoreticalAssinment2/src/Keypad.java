//��������

public class Keypad {
	private static int intputNumber;
	private Screen screen;
	// no-argument constructor initializes the Scanner

	public Keypad(Screen theScreen){
		screen = theScreen;
		intputNumber = 0;
	} // end no-argument Keypad constructor

	public void numberPressed(int i){
		intputNumber = intputNumber * 10 + i;
		screen.displayMessage(""+i);
	}
	
	public void cmdClear(){
		intputNumber = 0;
		String temp = screen.getScreen().getText();
		while(Character.isDigit( temp.charAt(temp.length()-1))) 
			temp = temp.substring(0, temp.length()-2);
		
		screen.getScreen().setText(temp);	
		
	}
	
	public void cmdDelete(){
		
		String temp = screen.getScreen().getText();
		if(!Character.isDigit( temp.charAt(temp.length()-1))) //�ж����һ���ַ��Ƿ�Ϊ����
			return;
		
		intputNumber /= 10;	
		temp = temp.substring(0, temp.length()-1);
		screen.getScreen().setText(temp);
	}
	
	public void cmdOk(){
		synchronized (this) {
			System.out.println("������"+intputNumber);
			this.notifyAll();
		}
	}
	
	// return an integer value entered by user
	public int getInput() {
		intputNumber = 0;
		
		synchronized(this){
			try {
				this.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return intputNumber;//input.nextInt(); // we assume that user enters an integer
	} // end method getInput
}