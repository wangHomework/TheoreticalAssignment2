import java.awt.Color;
import java.awt.Font;
import java.awt.KeyEventPostProcessor;
import java.awt.KeyboardFocusManager;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Panel;

public class MainGUI {

	private JFrame frmAtm;
	private static JTextArea taScreen;
	private static Keypad keypad;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		MainGUI window = new MainGUI();
		window.frmAtm.setVisible(true);
		/*keypad = theATM.getKeyPad();
		theATM.run();*/
	}

	/**
	 * Create the application.
	 */
	public MainGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAtm = new JFrame();
		frmAtm.setTitle("ATM");

		
		KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
		manager.addKeyEventPostProcessor((KeyEventPostProcessor) new KeyEventPostProcessor(){
			@Override
			public boolean postProcessKeyEvent(KeyEvent e) {
				// TODO Auto-generated method stub
				if(e.getID() == KeyEvent.KEY_PRESSED){
					int keyCode = e.getKeyCode();
					if((keyCode >= KeyEvent.VK_0 && keyCode <= KeyEvent.VK_9)
					|| keyCode >= KeyEvent.VK_NUMPAD0 && keyCode <= KeyEvent.VK_NUMPAD9)
					{
						keypad.numberPressed((keyCode - KeyEvent.VK_NUMPAD0) < 0 ? 
								(keyCode - KeyEvent.VK_0) : (keyCode - KeyEvent.VK_NUMPAD0));
					}
					else if(keyCode == KeyEvent.VK_ENTER)
						keypad.cmdOk();
					else if(keyCode == KeyEvent.VK_DELETE || keyCode == KeyEvent.VK_BACK_SPACE)
						keypad.cmdDelete();
					
					return true;
				}
				return false;
			}
			
		});
		
		
		
		frmAtm.setResizable(false);
		frmAtm.setAutoRequestFocus(true);
		frmAtm.setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\workspace\\ATM\\pic\\ATM.jpg"));
		frmAtm.getContentPane().setBackground(Color.LIGHT_GRAY);

		
		frmAtm.setBounds(100, 100, 1001, 646);
		frmAtm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAtm.getContentPane().setLayout(null);
		
		JLabel lblȡ��� = new JLabel("1");
		lblȡ���.setForeground(Color.BLACK);
		lblȡ���.setBackground(Color.BLUE);
		lblȡ���.setBounds(516, 413, 397, 99);
		lblȡ���.setIcon(new ImageIcon("D:\\workspace\\ATM\\pic\\\u53D6\u6B3E\u53E3.png"));
		frmAtm.getContentPane().add(lblȡ���);
		
		JLabel lbl���� = new JLabel("");
		lbl����.setIcon(new ImageIcon("D:\\workspace\\ATM\\pic\\\u5B58\u6B3E\u53E3.png"));
		lbl����.setBounds(516, 587, 397, 99);
		//label.
		frmAtm.getContentPane().add(lbl����);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(121, 58, 878, 474);
		frmAtm.getContentPane().add(scrollPane);
		
		taScreen = new JTextArea("The ATM is loading...");
		scrollPane.setViewportView(taScreen);
		taScreen.setForeground(Color.BLACK);
		taScreen.setBackground(Color.GRAY);
		taScreen.setVisible(true);
		//taScreen.setOpaque(true);
		taScreen.setFont(new Font("Consolas", Font.PLAIN, 24));
		taScreen.setLineWrap(true);
		taScreen.setEditable(false);
		
			//Thread.currentThread().wait(1000);
			ATM theATM = new ATM(taScreen);
					
					JButton btn9 = new JButton("9");
					btn9.setBounds(835, 553, 56, 44);
					frmAtm.getContentPane().add(btn9);
					btn9.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.numberPressed(9);
						}
					});
					btn9.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
					
					JButton btn8 = new JButton("8");
					btn8.setBounds(735, 553, 56, 44);
					frmAtm.getContentPane().add(btn8);
					btn8.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.numberPressed(8);
						}
					});
					btn8.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
					
					JButton btn7 = new JButton("7");
					btn7.setBounds(632, 553, 56, 44);
					frmAtm.getContentPane().add(btn7);
					btn7.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.numberPressed(7);
						}
					});
					btn7.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
					
					JButton btn6 = new JButton("6");
					btn6.setBounds(528, 553, 56, 44);
					frmAtm.getContentPane().add(btn6);
					btn6.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.numberPressed(6);
						}
					});
					btn6.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
					
					JButton btn5 = new JButton("5");
					btn5.setBounds(427, 553, 56, 44);
					frmAtm.getContentPane().add(btn5);
					btn5.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.numberPressed(5);
						}
					});
					btn5.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
					
					JButton btn4 = new JButton("4");
					btn4.setBounds(326, 553, 56, 44);
					frmAtm.getContentPane().add(btn4);
					btn4.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.numberPressed(4);
						}
					});
					btn4.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
					
					JButton btn3 = new JButton("3");
					btn3.setBounds(221, 553, 56, 44);
					frmAtm.getContentPane().add(btn3);
					btn3.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.numberPressed(3);
						}
					});
					btn3.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
					
					JButton btn2 = new JButton("2");
					btn2.setBounds(121, 553, 56, 44);
					frmAtm.getContentPane().add(btn2);
					btn2.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.numberPressed(2);
						}
					});
					btn2.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
					
					JButton btn0 = new JButton("0");
					btn0.setBounds(933, 553, 56, 44);
					frmAtm.getContentPane().add(btn0);
					btn0.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.numberPressed(0);
						}
					});
					btn0.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
					
					JButton btn00 = new JButton("00");
					btn00.setBounds(26, 488, 56, 44);
					frmAtm.getContentPane().add(btn00);
					btn00.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.numberPressed(0);
							keypad.numberPressed(0);
						}
					});
					btn00.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
					
					JButton btn1 = new JButton("1");
					btn1.setBounds(26, 553, 56, 44);
					frmAtm.getContentPane().add(btn1);
					btn1.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.numberPressed(1);
						}
					});
					btn1.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
					
					Panel numPanel = new Panel();
					numPanel.setBounds(10, 56, 105, 58);
					frmAtm.getContentPane().add(numPanel);
					
					JButton btnDelete = new JButton("\u5220\u9664");
					numPanel.add(btnDelete);
					btnDelete.setFont(new Font("����", Font.PLAIN, 32));
					btnDelete.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.cmdDelete();
						}
					});
					
					Panel panel = new Panel();
					panel.setBounds(10, 166, 105, 58);
					frmAtm.getContentPane().add(panel);
					
					JButton btnClear = new JButton("\u6E05\u5C4F");
					panel.add(btnClear);
					btnClear.setFont(new Font("����", Font.PLAIN, 32));
					btnClear.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
						}
					});
					btnClear.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							String temp = taScreen.getText();
							int lastIndex = temp.lastIndexOf('\n');
							if(lastIndex > 0)
								temp = temp.substring(lastIndex + 1, temp.length());
							
							System.out.println(lastIndex);
							taScreen.setText(temp);
						}
					});
					
					Panel panel_1 = new Panel();
					panel_1.setBounds(10, 279, 105, 55);
					frmAtm.getContentPane().add(panel_1);
					
					JButton btnOK = new JButton("\u786E\u8BA4");
					panel_1.add(btnOK);
					btnOK.setFont(new Font("����", Font.PLAIN, 32));
					btnOK.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							keypad.cmdOk();
						}
					});
					
					Panel panel_2 = new Panel();
					panel_2.setBounds(10, 387, 105, 55);
					frmAtm.getContentPane().add(panel_2);
					
					JButton btnClearNum = new JButton("\u6E05\u9664");
					panel_2.add(btnClearNum);
					btnClearNum.setFont(new Font("����", Font.PLAIN, 32));
				btnClearNum.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						keypad.cmdClear();
					}
				});
		
		
	}
}
