import javax.swing.JFrame;
import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.TextArea;
import javax.swing.JButton;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

public class ATMUI extends javax.swing.JFrame implements ActionListener{
	public String input = "";
	public static  ATM theATM;
	TextArea textArea;
	private static final String PrintStream = null;
	private JFrame frame;
	
	PrintStream orignalOut;
	OutputStream jtextOut;

	/**
	 * Launch the application.
	 */
	//Main����
	public static void main(String[] args) {
		ATMUI window = new ATMUI();
		window.frame.setVisible(true);
		theATM = new ATM();
	    theATM.run();	
	}

	/**
	 * Create the application.
	 */
	//�ض������
	public ATMUI() {
		initialize();
		orignalOut = System.out;
		jtextOut = new OutputStream()
		    {
		       final int BUFFER_LENGTH = 2048;
		       byte buf[] = new byte[BUFFER_LENGTH];
		       int pos = 0;
		       public void write(int b) throws IOException
		       {
		         buf[pos ++] = (byte)b;
		         if (pos >= BUFFER_LENGTH)
		         flush();
		       }
		       public void flush() throws IOException
		       {
		         if (pos >= BUFFER_LENGTH)
		          textArea.append(new String(buf));
		         else
		          textArea.append(new String(buf, 0, pos));
		         pos = 0;
		       }
		    };
		    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		    
		    try  {
		      initialize();
		    }
		    catch(Exception e) {
		      e.printStackTrace();
		    }
		    System.setOut(new PrintStream(jtextOut, true));
		    
	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings("deprecation")
	private void initialize() {
		//��ʾȡ���UI
		frame = new JFrame();
		frame.setBounds(100, 100, 824, 522);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Button button = new Button("1");
		button.setBounds(28, 201, 63, 53);
		button.setBackground(Color.WHITE);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.print(button.getActionCommand());
				input +="1";
			}
		});
		frame.getContentPane().setLayout(null);
		button.setActionCommand("1");
		frame.getContentPane().add(button);
		
		Button button_1 = new Button("2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.print(button_1.getActionCommand());
				input +="2";
			}
		});
		button_1.setBackground(Color.WHITE);
		button_1.setActionCommand("2");
		button_1.setBounds(120, 201, 63, 53);
		frame.getContentPane().add(button_1);
		
		Button button_2 = new Button("3");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.print(button_2.getActionCommand());
				input +="3";
			}
		});
		button_2.setBackground(Color.WHITE);
		button_2.setActionCommand("3");
		button_2.setBounds(213, 201, 63, 53);
		frame.getContentPane().add(button_2);
		
		Button button_3 = new Button("4");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.print(button_3.getActionCommand());
				input +="4";
			}
		});
		button_3.setBackground(Color.WHITE);
		button_3.setActionCommand("4");
		button_3.setBounds(28, 273, 63, 53);
		frame.getContentPane().add(button_3);
		
		Button button_4 = new Button("5");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.print(button_4.getActionCommand());
				input +="5";
			}
		});
		button_4.setBackground(Color.WHITE);
		button_4.setActionCommand("5");
		button_4.setBounds(120, 273, 63, 53);
		frame.getContentPane().add(button_4);
		
		Button button_5 = new Button("6");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.print(button_5.getActionCommand());
				input +="6";
			}
		});
		button_5.setBackground(Color.WHITE);
		button_5.setActionCommand("6");
		button_5.setBounds(213, 273, 63, 53);
		frame.getContentPane().add(button_5);
		
		Button button_6 = new Button("7");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.print(button_6.getActionCommand());
				input +="7";
			}
		});
		button_6.setBackground(Color.WHITE);
		button_6.setActionCommand("7");
		button_6.setBounds(28, 343, 63, 53);
		frame.getContentPane().add(button_6);
		
		Button button_7 = new Button("8");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.print(button_7.getActionCommand());
				input +="8";
			}
		});
		button_7.setBackground(Color.WHITE);
		button_7.setActionCommand("8");
		button_7.setBounds(120, 343, 63, 53);
		frame.getContentPane().add(button_7);
		
		Button button_8 = new Button("9");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.print(button_8.getActionCommand());
				input +="9";
			}
		});
		button_8.setBackground(Color.WHITE);
		button_8.setActionCommand("9");
		button_8.setBounds(213, 343, 63, 53);
		frame.getContentPane().add(button_8);
		
		Button button_9 = new Button("0");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.print(button_9.getActionCommand());
				input +="0";
			}
		});
		button_9.setBackground(Color.WHITE);
		button_9.setActionCommand("0");
		button_9.setBounds(28, 412, 155, 53);
		frame.getContentPane().add(button_9);
		
		Button button_10 = new Button("Enter");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theATM.getKeypad().n=Integer.parseInt(input);
				theATM.getKeypad().am=true;
				input="";
				
			}
		});
		button_10.setBackground(Color.WHITE);
		button_10.setActionCommand("Enter");
		button_10.setBounds(213, 412, 63, 53);
		frame.getContentPane().add(button_10);
		
		JButton button_11 = new JButton("\u53D6\u6B3E\u53E3");
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button_11.setBounds(298, 218, 487, 148);
		frame.getContentPane().add(button_11);
		
		JButton button_12 = new JButton("\u63D2\u5361\u5904");
		button_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button_12.setBounds(412, 384, 269, 63);
		frame.getContentPane().add(button_12);
		
		textArea = new TextArea();
		textArea.setBackground(Color.WHITE);
		textArea.setBounds(69, 29, 612, 141);
		frame.getContentPane().add(textArea);
		
	}
	
	protected void processWindowEvent(WindowEvent e) {
	    super.processWindowEvent(e);
	    if(e.getID() == WindowEvent.WINDOW_CLOSING) {
	      System.exit(0);
	    }
	  }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		
	}

}
