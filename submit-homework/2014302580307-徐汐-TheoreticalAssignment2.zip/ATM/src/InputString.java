
public class InputString {
	public static String input ="";
}
