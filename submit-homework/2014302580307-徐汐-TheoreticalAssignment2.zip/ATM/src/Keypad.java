
public class Keypad
 {

    int n;
	boolean am =false;


 // return an integer value entered by user
 public int getInput()
 {
	 am = false;
 
	 while(!am){
		System.out.print(""); 
	 }
	 return n;
 }	
}
	 
	 
	 
	 
 