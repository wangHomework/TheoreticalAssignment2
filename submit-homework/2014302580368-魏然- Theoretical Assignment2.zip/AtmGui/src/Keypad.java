import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad
 {
	private static int num;
	public int getNum() {
		ATM.flag=true;
		return num;
		
	}

	public static void setNum(int num) {
		Keypad.num = num;
		
	}
// no-argument constructor initializes the Scanner
 public Keypad()
 {
 //input = new Scanner( System.in );
 } // end no-argument Keypad constructor

}