import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class MyGui{
	
	private String acc;
	public static JTextArea area;
	private JButton [] button=new JButton[10];
	private JPanel p2;
	public static void main(String []args){
		ATM theATM = new ATM();
		theATM.run();
		//new MyGui();
		
	}
	
	public  void createButton(int i,final String j,int x,int y,int w,int h){
		button[i]=new JButton(j);
		button[i].addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(acc==null){
					acc=j;
					Keypad.setNum(Integer.valueOf(acc));
				}else
					acc=acc+j;
				area.append(j);			
			}
		});

		p2.add(button[i]);
		button[i].setBounds(x, y, w, h);
		
	}
	public void initGui(){
		JFrame frame=new JFrame();
		frame.setBounds(0, 0, 800, 627);
		frame.setTitle("ATMȡ���");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container container=frame.getContentPane();
		container.setLayout(null);

		p2=new JPanel();
		JPanel p3=new JPanel();

		area=new JTextArea();
		area.setLineWrap(true);
		JScrollPane p1 = new JScrollPane(area);
		p1.setBounds(0, 0, 800, 220);
		area.setBounds(0, 0, 800, 220);
		
		p2.setLayout(null);
		p2.setBounds(0, 220, 300, 360);
		
		
		createButton(1,"1",0,180,100,90);
		createButton(2,"2",100, 180, 100, 90);
		createButton(3,"3",200, 180, 100, 90);
		createButton(4,"4",0, 90, 100, 90);
		createButton(5,"5",100, 90, 100, 90);
		createButton(6,"6",200, 90, 100, 90);
		createButton(7,"7",0, 0, 100, 90);
		createButton(8,"8",100, 0, 100, 90);
		createButton(9,"9",200, 0, 100, 90);
		createButton(0,"0",0, 270, 100, 90);
		
		
		JButton button=new JButton("Enter");
		button.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Keypad.setNum(Integer.parseInt(acc));
				acc="";
				ATM.flag=false;
			}
		});

		p2.add(button);
		button.setBounds(100, 270, 200, 90);
				
		p3.setLayout(null);//p3ʹ�þ��Բ����������ְ�ť
		p3.setBounds(300, 220, 500, 380);
		JLabel j11=new JLabel("Take cash here");
		j11.setBounds(0, 0, 500, 180);
		JLabel j22=new JLabel("Insert deposit envelope here");
		j22.setBounds(0, 180, 500, 180);
		p3.add(j11);
		p3.add(j22);
		
		
		container.add(p1);
		container.add(p2);
		container.add(p3);
		frame.setVisible(true);
	}
}