
// Represents the screen of the ATM

public class Screen
 {
	//MyGui mg=new MyGui();
	//public MyGui mg=new MyGui();
// display a message without a carriage return
	 public void displayMessage( String message )
	 {
	 //System.out.print( message );
		 MyGui.area.append(message);
	 } // end method displayMessage

 // display a message with a carriage return
	 public void displayMessageLine( String message )
	 {
		 MyGui.area.append(message+"\n" );
	 } // end method displayMessageLine

 // displays a dollar amount
 	public void displayDollarAmount( double amount )
 	{
	 MyGui.area.append(String.format( "$%,.2f", amount ));
 	} // end method displayDollarAmount
 } // end class Screen