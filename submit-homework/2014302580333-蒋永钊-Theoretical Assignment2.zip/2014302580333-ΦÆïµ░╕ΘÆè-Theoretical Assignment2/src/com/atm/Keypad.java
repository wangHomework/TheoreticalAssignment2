package com.atm;

//import java.util.Scanner;

public class Keypad 
 {
	String input2;
 //private Scanner input; // reads data from the command line
// no-argument constructor initializes the Scanner
// public Keypad()
// {
//// input = new Scanner( System.in );
// } // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 {
	 Gui.input1=Gui.ta.getText();
	 input2=Gui.input1.substring(Gui.input1.length()-5);
	 int i=Integer.parseInt(input2);
	 System.out.println(input2);
	 Gui.i_con--;
	 return i;
	 
// return input.nextInt(); // we assume that user enters an integer
 } // end method getInput
 public int getInput2(){
	 Gui.input1=Gui.ta.getText();
	 input2=Gui.input1.substring(Gui.input1.length()-1);
	 int i=Integer.parseInt(input2);
	 System.out.println(input2);
	 Gui.i_con--;
	 return i;
 }
 }