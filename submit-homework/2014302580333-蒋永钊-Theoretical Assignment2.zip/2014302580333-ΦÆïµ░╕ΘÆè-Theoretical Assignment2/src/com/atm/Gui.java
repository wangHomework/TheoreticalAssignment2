package com.atm;

import java.awt.Container;
import java.awt.Image;
import java.awt.event.ActionEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

import org.omg.CORBA.PRIVATE_MEMBER;


public class Gui extends JFrame {
	
	
	
	public static JTextArea ta=new JTextArea();
	public static String input1="2014302580333";
	public static int i_con=0;

	public  Gui(){
		setTitle("ATM");
		Container c=getContentPane();
		c.setLayout(null);
		//创建面板
		JPanel p2=new JPanel();
		JPanel p3=new JPanel();
		
		
		ta.setLineWrap(true);
		JScrollPane p1 = new JScrollPane(ta);
		p1.setBounds(0, 0, 800, 220);
		ta.setBounds(0, 0, 800, 220);
		
		p2.setLayout(null);//p2使用绝对布局添加数字按钮
		p2.setBounds(0, 220, 300, 360);
		JButton b1=new JButton("1");
		JButton b2=new JButton("2");
		JButton b3=new JButton("3");
		JButton b4=new JButton("4");
		JButton b5=new JButton("5");
		JButton b6=new JButton("6");
		JButton b7=new JButton("7");
		JButton b8=new JButton("8");
		JButton b9=new JButton("9");
		JButton b0=new JButton("0");
		JButton bcon=new JButton("确认");
		
		b1.addActionListener(
				new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ta.append("1");
						}
					});
		b2.addActionListener(
				new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ta.append("2");
						}
					});
		b3.addActionListener(
				new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ta.append("3");
						}
					});
		b4.addActionListener(
				new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ta.append("4");
						}
					});
		b5.addActionListener(
				new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ta.append("5");
						}
					});
		b6.addActionListener(
				new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ta.append("6");
						}
					});
		b7.addActionListener(
				new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ta.append("7");
						}
					});
		b8.addActionListener(
				new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ta.append("8");
						}
					});
		b9.addActionListener(
				new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ta.append("9");
						}
					});
		b0.addActionListener(
				new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ta.append("0");
						}
					});
		bcon.addActionListener(
				new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						i_con++;
						}
					});

		b7.setBounds(0, 0, 100, 90);
		b8.setBounds(100, 0, 100, 90);
		b9.setBounds(200, 0, 100, 90);
		b4.setBounds(0, 90, 100, 90);
		b5.setBounds(100, 90, 100, 90);
		b6.setBounds(200, 90, 100, 90);
		b1.setBounds(0, 180, 100, 90);
		b2.setBounds(100, 180, 100, 90);
		b3.setBounds(200, 180, 100, 90);
		b0.setBounds(0, 270, 100, 90);
		bcon.setBounds(100, 270, 200, 90);
		
		p2.add(b7);
		p2.add(b8);
		p2.add(b9);
		p2.add(b4);
		p2.add(b5);
		p2.add(b6);
		p2.add(b1);
		p2.add(b2);
		p2.add(b3);
		p2.add(b0);
		p2.add(bcon);
		
		p3.setLayout(null);//p3使用绝对布局添加数字按钮
		p3.setBounds(300, 220, 500, 380);
		JButton b11=new JButton("Take cash here");
		b11.setBounds(0, 0, 500, 180);
		JButton b22=new JButton("Insert deposit envelope here");
		b22.setBounds(0, 180, 500, 180);
		p3.add(b11);
		p3.add(b22);
    	
		
		
		c.add(p1);
		c.add(p2);
		c.add(p3);
		
		setBounds(0, 0, 800, 600);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}

	public static void main(String[] args){
		new Gui();
		ATM atm=new ATM();
		atm.run();
	}

}
