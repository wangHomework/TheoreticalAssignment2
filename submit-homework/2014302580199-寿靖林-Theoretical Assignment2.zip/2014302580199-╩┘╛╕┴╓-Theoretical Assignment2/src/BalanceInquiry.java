public class BalanceInquiry extends Transaction
 {
 // BalanceInquiry constructor
 public BalanceInquiry( int userAccountNumber, Screen atmScreen,
 BankDatabase atmBankDatabase )
 {
 super( userAccountNumber, atmScreen, atmBankDatabase );
 } // end BalanceInquiry constructor

 // performs the transaction
 @Override
 public String execute()
 {
	 String screenOut = "";
	// get references to bank database and screen
	  BankDatabase bankDatabase = getBankDatabase();
	  Screen screen = getScreen();
	 
	  // get the available balance for the account involved
	  double availableBalance =
	  bankDatabase.getAvailableBalance( getAccountNumber() );
	 
	  // get the total balance for the account involved
	  double totalBalance =
	  bankDatabase.getTotalBalance( getAccountNumber() );
	 
	  // display the balance information on the screen
	  screenOut += screen.displayMessageLine( "\nBalance Information:" );
	  screenOut += screen.displayMessage( "\n - Available balance: " );
	  screenOut += screen.displayDollarAmount( availableBalance );
	  screenOut += screen.displayMessage( "\n - Total balance: " );
	  screenOut += screen.displayDollarAmount( totalBalance );
	  screenOut += screen.displayMessageLine( "" );
	  return screenOut;
	  
	  } // end method execute
	  }
 