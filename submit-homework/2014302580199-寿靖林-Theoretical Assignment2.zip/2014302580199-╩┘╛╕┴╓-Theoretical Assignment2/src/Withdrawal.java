
public class Withdrawal extends Transaction
 {
 private int amount; // amount to withdraw
 private Keypad keypad; // reference to keypad
 private CashDispenser cashDispenser; // reference to cash dispenser
 // constant corresponding to menu option to cancel
 private final static int CANCELED = 6;

 // Withdrawal constructor
 public Withdrawal( int userAccountNumber, Screen atmScreen,
 BankDatabase atmBankDatabase, Keypad atmKeypad,
 CashDispenser atmCashDispenser ,int displayMenuOfAmounts)
 {
 // initialize superclass variables
 super( userAccountNumber, atmScreen, atmBankDatabase );

 // initialize references to keypad and cash dispenser
 keypad = atmKeypad;
 cashDispenser = atmCashDispenser;
 amount = displayMenuOfAmounts;
 } // end Withdrawal constructor

 // perform transaction
 @Override
 public String execute()
 {
	 String screenOut = "";
 boolean cashDispensed = false; // cash was not dispensed yet
 double availableBalance; // amount available for withdrawal

 // get references to bank database and screen
 BankDatabase bankDatabase = getBankDatabase();
 Screen screen = getScreen();

 // loop until cash is dispensed or the user cancels

 // obtain a chosen withdrawal amount from the user

 // check whether user chose a withdrawal amount or canceled
 if ( amount != CANCELED )
 {
 // get available balance of account involved
 availableBalance =
 bankDatabase.getAvailableBalance( getAccountNumber() );

 // check whether the user has enough money in the account
 	if ( amount <= availableBalance )
 	{
	// check whether the cash dispenser has enough money
	  if ( cashDispenser.isSufficientCashAvailable( amount ) )
	  {
	  // update the account involved to reflect the withdrawal
	  bankDatabase.debit( getAccountNumber(), amount );
	 
	  cashDispenser.dispenseCash( amount ); // dispense cash
	  cashDispensed = true; // cash was dispensed
	  // instruct user to take cash
	  screenOut += screen.displayMessageLine( "\nYour cash has been" +
	  " dispensed. Please take your cash now.\n" );
	  } // end if
	  else // cash dispenser does not have enough cash
		  screenOut += screen.displayMessageLine(
	  "\nInsufficient cash available in the ATM." +
	  "\n\nPlease choose a smaller amount.\n" );
	} // end if
 else // not enough money available in user's account
  {
		  screenOut += screen.displayMessageLine(
	  "\nInsufficient funds in your account." +
	  "\n\nPlease choose a smaller amount.\n" );
  } // end else
  } // end if
 else // user chose cancel menu option
	  {
		  screenOut +=  screen.displayMessageLine( "\nCanceling transaction...\n" );
		  
	   // return to main menu because user canceled
	  } // end else
	
 return screenOut;
	  } // end method execute
	 
	  // display a menu of withdrawal amounts and the option to cancel;
	  // return the chosen amount or 0 if the user chooses to cancel
	   }