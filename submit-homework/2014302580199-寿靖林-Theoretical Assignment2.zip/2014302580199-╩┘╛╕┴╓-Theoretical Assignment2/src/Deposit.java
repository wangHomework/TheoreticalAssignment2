public class Deposit extends Transaction
 {
 private double amount; // amount to deposit
 private Keypad keypad; // reference to keypad
 private DepositSlot depositSlot; // reference to deposit slot
 private final static int CANCELED = 0; // constant for cancel option

 // Deposit constructor
 public Deposit( int userAccountNumber, Screen atmScreen,
 BankDatabase atmBankDatabase, Keypad atmKeypad,
 DepositSlot atmDepositSlot ,double promptForDepositAmount )
 {
 // initialize superclass variables
 super( userAccountNumber, atmScreen, atmBankDatabase );

 // initialize references to keypad and deposit slot
 keypad = atmKeypad;
 depositSlot = atmDepositSlot;
 amount = promptForDepositAmount; // get deposit amount from user
 } // end Deposit constructor

 // perform transaction
 @Override
 public String execute()
 {
 BankDatabase bankDatabase = getBankDatabase(); // get reference
 Screen screen = getScreen(); // get reference

String screenOut = "";

 // check whether user entered a deposit amount or canceled
 if ( amount != CANCELED )
 {
 // request deposit envelope containing specified amount
 screenOut += screen.displayMessage(
 "Please insert a deposit envelope containing " );
 screenOut += screen.displayDollarAmount( amount );
 screenOut += screen.displayMessageLine( ".\n" );

 // receive deposit envelope
 boolean envelopeReceived = depositSlot.isEnvelopeReceived();

 // check whether deposit envelope was received
 if ( envelopeReceived )
 {
	 screenOut += screen.displayMessageLine( "Your envelope has been " +
 "received.\nNOTE: The money just deposited will not " +
 "be available until we verify the amount of any " +
 "enclosed cash and your checks clear.\n" );
//credit account to reflect the deposit
 bankDatabase.credit( getAccountNumber(), amount );
 } // end if
 else // deposit envelope not received
 {
	 screenOut += screen.displayMessageLine( "You did not insert an " +
 "envelope, so the ATM has canceled your transaction.\n" );
 } // end else
 } // end if
 else // user canceled instead of entering amount
 {
	 screenOut += screen.displayMessageLine( "Canceling transaction...\n" );
 } // end else
 return screenOut;
 } // end method execute

 // prompt user to enter a deposit amount in cents
 
 } // end class Deposit