import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class ATM extends JFrame 
{
	private JTextArea text;

	private String screenOut = "";
	private String number = "";
	private boolean YES = false;
	
	private JButton button1;
	private JButton button2;
	private JButton button3;
	private JButton button4;
	private JButton button5;
	private JButton button6;
	private JButton button7;
	private JButton button8;
	private JButton button9;
	private JButton button0;
	private JButton buttonYes;
	private JButton buttonESC;

	
	private boolean userAuthenticated; // whether user is authenticated
	private int currentAccountNumber; // current user's account number
	private Screen screen; // ATM's screen
	private Keypad keypad; // ATM's keypad
	private CashDispenser cashDispenser; // ATM's cash dispenser
	private DepositSlot depositSlot; // ATM's deposit slot
	private BankDatabase bankDatabase; // account information database
	// constants corresponding to main menu options
	private static final int BALANCE_INQUIRY = 1;
	private static final int WITHDRAWAL = 2;
	private static final int DEPOSIT = 3;
	private static final int EXIT = 4;
	
	 // no-argument ATM constructor initializes instance variables
	 public ATM()
	 {
		 
		 super("ATM");
			setLayout(null);
			
			//set the TextField and the size and the location
			text = new JTextArea("");
			add(text);
			text.setBounds(0, 0, 400, 160);

			//create button and set the size and location
			button1 = new JButton("1");
			add(button1);
			button1.setBounds(10, 170, 70, 70);
			               
			button2 = new JButton("2");
			add(button2);
			button2.setBounds(90, 170, 70, 70);
			
			button3 = new JButton("3");
			add(button3);
			button3.setBounds(170, 170, 70, 70);
			
			button4 = new JButton("4");
			add(button4);
			button4.setBounds(10, 250, 70, 70);
			
			button5 = new JButton("5");
			add(button5);
			button5.setBounds(90, 250, 70, 70);
			
			button6 = new JButton("6");
			add(button6);
			button6.setBounds(170, 250, 70, 70);
			
			button7 = new JButton("7");
			add(button7);
			button7.setBounds(10, 330, 70, 70);
			
			button8 = new JButton("8");
			add(button8);
			button8.setBounds(90, 330, 70, 70);
			
			button9 = new JButton("9");
			add(button9);
			button9.setBounds(170, 330, 70, 70);
			
			button0 = new JButton("0");
			add(button0);
			button0.setBounds(90, 410, 70, 70);
			
			buttonYes = new JButton("OK");
			add(buttonYes);
			buttonYes.setBounds(250, 300, 150, 100);
			
			buttonESC = new JButton("AC");
			add(buttonESC);
			buttonESC.setBounds(250, 170, 150, 100);
		

			 ButtonHandler handler = new ButtonHandler();
			 button1.addActionListener( handler );
			 button2.addActionListener( handler );
			 button3.addActionListener( handler );
			 button4.addActionListener( handler );
			 button5.addActionListener( handler );
			 button6.addActionListener( handler );
			 button7.addActionListener( handler );
			 button8.addActionListener( handler );
			 button9.addActionListener( handler );
			 button0.addActionListener( handler );
			 buttonYes.addActionListener(handler);
			 buttonESC.addActionListener( handler );
			
			 
	 userAuthenticated = false; // user is not authenticated to start
	 currentAccountNumber = 0; // no current account number to start
	 screen = new Screen(); // create screen
	 keypad = new Keypad(); // create keypad
	 cashDispenser = new CashDispenser(); // create cash dispenser
	 depositSlot = new DepositSlot(); // create deposit slot
	 bankDatabase = new BankDatabase(); // create acct info database
	  } // end no-argument ATM constructor
	 
	 private class ButtonHandler implements ActionListener
	 {
	 	public void actionPerformed(ActionEvent event)
	 	{
	 		if(event.getSource() == buttonESC)
	 		{
	 			number = "";
	 			text.setText(screenOut);
	 			return;
	 		}
	 		if(event.getSource() == buttonYes)
	 		{
	 			if("" == number);
	 			else
	 				YES = true;
	 			
	 		}
	 		else 
	 		{
	 			number = number +
	 					String.format("%s", event.getActionCommand());
	 			text.setText(screenOut + number);
	 		}
 		
	 	}
	 }
	 
	 private String getNumber()
	 {
		 while(!YES)
		 {
			 if(YES)
				 System.out.println("");
		 }

		 screenOut += number;
		 return number;
	 }
	 
	 private void setOriginal()
	 {
		 YES = false;
		 number = "";
	 }
	 
	 private void clear()
	 {
		 screenOut = "";
	 }
	 
	 // start ATM
	 public void run()
	  {
	  // welcome and authenticate user; perform transactions
	  while ( true )
	  {
	  // loop while user is not yet authenticated
	  while ( !userAuthenticated )
	  {
	  screenOut += screen.displayMessageLine("\nWelcome");
	  text.setText(screenOut);
	  authenticateUser(); // authenticate user
	  } // end while
	 
	  performTransactions(); // user is now authenticated
	  userAuthenticated = false; // reset before next ATM session
	  currentAccountNumber = 0; // reset before next ATM session
	 screen.displayMessageLine( "\nThank you! Goodbye!" );
	  } // end while
	  } // end method run
	 
	  // attempts to authenticate user against database
	  private void authenticateUser()
	  {
	 screenOut += screen.displayMessage( "\r\nPlease enter your account number: " );
	 text.setText(screenOut);
	  int accountNumber = Integer.valueOf(getNumber()); // input account number
	  setOriginal();
	 screenOut +=screen.displayMessage( "\nEnter your PIN: " ); // prompt for PIN
	 text.setText(screenOut);
	  int pin = Integer.valueOf(getNumber()); // input PIN
	  setOriginal();
	  clear();
	  // set userAuthenticated to boolean value returned by database
	 userAuthenticated =
	  bankDatabase.authenticateUser( accountNumber, pin );
	 
	  // check whether authentication succeeded
	  if ( userAuthenticated )
	 {
	  currentAccountNumber = accountNumber; // save user's account #
	  } // end if
	  else
	  screenOut += screen.displayMessageLine(
	  "\nInvalid account number or PIN. Please try again." );
	  text.setText(screenOut);
	  } // end method authenticateUser
	 
	  // display the main menu and perform transactions
	  private void performTransactions()
	  {
	 // local variable to store transaction currently being processed
	  Transaction currentTransaction = null;
	  boolean userExited = false; // user has not chosen to exit
	 // loop while user has not chosen option to exit system
	   while ( !userExited )
	  {
	  // show main menu and get user selection
	  int mainMenuSelection = displayMainMenu();
	   // decide how to proceed based on user's menu selection
	   switch ( mainMenuSelection )
	   {
	  // user chose to perform one of three transaction types
	  case BALANCE_INQUIRY:
	   case WITHDRAWAL:
	  case DEPOSIT:
	   // initialize as new object of chosen type
	  currentTransaction =
	   createTransaction( mainMenuSelection );
	  screenOut += currentTransaction.execute(); // execute transaction
	  text.setText(screenOut);
	 break;
	   case EXIT: // user chose to terminate session
	   screenOut += screen.displayMessageLine( "\nExiting the system..." );
	   text.setText(screenOut);
	   userExited = true; // this ATM session should end
	   break;
	   default: // user did not enter an integer from 1-4
	   screenOut += screen.displayMessageLine(
	   "\nYou did not enter a valid selection. Try again." );
	   text.setText(screenOut);
	   break;
	   } // end switch
	   } // end while
	  } // end method performTransactions
	  
	   // display the main menu and return an input selection
	  private int displayMainMenu()
	   {
	   screenOut += screen.displayMessageLine( "\nMain menu:" );
	   screenOut += screen.displayMessageLine( "1 - View my balance\n" );
	   screenOut +=screen.displayMessageLine( "2 - Withdraw cash\n" );
	   screenOut += screen.displayMessageLine( "3 - Deposit funds\n" );
	   screenOut += screen.displayMessageLine( "4 - Exit\n" );
	   screenOut +=  screen.displayMessage( "Enter a choice: " );
	   text.setText(screenOut);
	   int isDisplay = Integer.valueOf(getNumber()); // return user's selection
	   setOriginal();
	   clear();
	   return isDisplay;
	  } // end method displayMainMenu
	 
	  // return object of specified Transaction subclass
	  private Transaction createTransaction( int type )
	   {
	   Transaction temp = null; // temporary Transaction variable
	  switch ( type )
	  {
	   case BALANCE_INQUIRY: // create new BalanceInquiry transaction
	   temp = new BalanceInquiry(
	   currentAccountNumber, screen, bankDatabase );
	  break;
	   case WITHDRAWAL: // create new Withdrawal transaction
	   temp = new Withdrawal( currentAccountNumber, screen,
	  bankDatabase, keypad, cashDispenser ,displayMenuOfAmounts());
	   break;
	   case DEPOSIT: // create new Deposit transaction
	   temp = new Deposit( currentAccountNumber, screen,
	   bankDatabase, keypad, depositSlot ,promptForDepositAmount());
	   break;
	   } // end switch
	 
	   return temp; // return the newly created object
	   } // end method createTransaction
	  
	  
	  private int displayMenuOfAmounts()
	  {
	  int userChoice = 0; // local variable to store return value

	  // array of amounts to correspond to menu numbers
	  int[] amounts = { 0, 20, 40, 60, 100, 200 };

	  // loop while no valid choice has been made
	  while ( userChoice == 0 )
	  {
	  // display the withdrawal menu
		screenOut +=  screen.displayMessageLine( "\nWithdrawal Menu:\n" );
	 	screenOut += screen.displayMessageLine( "1 - $20\n" );
	    screenOut +=  screen.displayMessageLine( "2 - $40\n" );
	    screenOut +=  screen.displayMessageLine( "3 - $60\n" );
	  	screenOut +=screen.displayMessageLine( "4 - $100\n" );
	  	screenOut +=screen.displayMessageLine( "5 - $200\n" );
	  	screenOut +=screen.displayMessageLine( "6 - Cancel transaction\n" );
	  	screenOut += screen.displayMessage( "Choose a withdrawal amount: " );
	  	text.setText(screenOut);
	   int input = Integer.valueOf(getNumber()); // get user input through keypad
	   setOriginal();
	   clear();
	   // determine how to proceed based on the input value
	   switch ( input )
	   {
	   case 1: // if the user chose a withdrawal amount
	   case 2: // (i.e., chose option 1, 2, 3, 4 or 5), return the
	   case 3: // corresponding amount from amounts array
	   case 4:
	   case 5:
	   userChoice = amounts[ input ]; // save user's choice
	   break;
	   case 6: // the user chose to cancel
	   userChoice = 6; // save user's choice
	   break;
	   default: // the user did not enter a value from 1-6
	   screenOut += screen.displayMessageLine(
	   "Invalid selection. Try again." );
	   text.setText(screenOut);
	   } // end switch
	   } // end while

	   return userChoice; // return withdrawal amount or CANCELED
	   } // end method displayMenuOfAmounts
	  
	  private double promptForDepositAmount()
	  {
	  // display the prompt
	  screenOut += screen.displayMessage( "\nPlease enter a deposit amount in " +
	  "CENTS (or 0 to cancel): " );
	  text.setText(screenOut);
	  int input = Integer.valueOf(getNumber()); // receive input of deposit amount
	  setOriginal();
	  clear();
	  // check whether the user canceled or entered a valid amount
	  if ( input == 0 )
	  return 0;
	  else
	  {
	  return ( double ) input / 100; // return dollar amount
	  } // end else
	  } // end method promptForDepositAmount
	   }



