import javax.swing.JFrame;


public class ATMCaseStudy
 {
 // main method creates and runs the ATM
 public static void main( String[] args )
 {
// ATM theATM = new ATM();
// theATM.run();
	 ATM atm = new ATM();
	 
	 atm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 atm.setSize(430, 530);
	 atm.setVisible(true);
	 atm.run();
	
 } // end main
 } // end class ATMCaseStudy