
// Represents the screen of the ATM

public class Screen
 {

// display a message without a carriage return
 public String displayMessage( String message )
 {
	 return message;
 //System.out.print( message );
 } // end method displayMessage

 // display a message with a carriage return
 public String displayMessageLine( String message )
 {
	 return message;
 //System.out.println( message );
 } // end method displayMessageLine

 // displays a dollar amount
 public String displayDollarAmount( double amount )
 {	
	 return Double.toString(amount);
 //System.out.printf( "$%,.2f", amount );
 } // end method displayDollarAmount
 } // end class Screen