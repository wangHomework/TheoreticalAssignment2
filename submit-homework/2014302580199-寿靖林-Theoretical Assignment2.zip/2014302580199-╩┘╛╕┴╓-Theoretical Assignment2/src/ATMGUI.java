/*import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class ATMGUI extends JFrame
{
	private JTextField textField;

	private String screenOut = "";
	
	private JButton button1;
	private JButton button2;
	private JButton button3;
	private JButton button4;
	private JButton button5;
	private JButton button6;
	private JButton button7;
	private JButton button8;
	private JButton button9;
	private JButton buttonYes;
	private JButton buttonESC;
	
	private boolean userAuthenticated; // whether user is authenticated
	private int currentAccountNumber; // current user's account number
	private Screen screen; // ATM's screen
	private Keypad keypad; // ATM's keypad
	private CashDispenser cashDispenser; // ATM's cash dispenser
	private DepositSlot depositSlot; // ATM's deposit slot
	private BankDatabase bankDatabase; // account information database
	// constants corresponding to main menu options
	private static final int BALANCE_INQUIRY = 1;
	private static final int WITHDRAWAL = 2;
	private static final int DEPOSIT = 3;
	private static final int EXIT = 4;
	
	
	public ATMGUI()
	{

		super("ATM");
		setLayout(null);
		
		//set the TextField and the size and the location
		textField = new JTextField("");
		add(textField);
		textField.setBounds(0, 0, 400, 150);
		
		//create button and set the size and location
		button1 = new JButton("1");
		add(button1);
		button1.setBounds(10, 170, 70, 70);
		               
		button2 = new JButton("2");
		add(button2);
		button2.setBounds(90, 170, 70, 70);
		
		button3 = new JButton("3");
		add(button3);
		button3.setBounds(170, 170, 70, 70);
		
		button4 = new JButton("4");
		add(button4);
		button4.setBounds(10, 250, 70, 70);
		
		button5 = new JButton("5");
		add(button5);
		button5.setBounds(90, 250, 70, 70);
		
		button6 = new JButton("6");
		add(button6);
		button6.setBounds(170, 250, 70, 70);
		
		button7 = new JButton("7");
		add(button7);
		button7.setBounds(10, 330, 70, 70);
		
		button8 = new JButton("8");
		add(button8);
		button8.setBounds(90, 330, 70, 70);
		
		button9 = new JButton("9");
		add(button9);
		button9.setBounds(170, 330, 70, 70);
		
		buttonYes = new JButton("OK");
		add(buttonYes);
		buttonYes.setBounds(250, 300, 150, 100);
		
		buttonESC = new JButton("AC");
		add(buttonESC);
		buttonESC.setBounds(250, 170, 150, 100);
		
		ButtonHandler handler = new ButtonHandler();
		button1.addActionListener( handler );
		button2.addActionListener( handler );
		button3.addActionListener( handler );
		button4.addActionListener( handler );
		button5.addActionListener( handler );
		button6.addActionListener( handler );
		button7.addActionListener( handler );
		button8.addActionListener( handler );
		button9.addActionListener( handler );
		buttonYes.addActionListener( handler );
		buttonESC.addActionListener( handler );
		
		 
		 userAuthenticated = false; // user is not authenticated to start
		 currentAccountNumber = 0; // no current account number to start
		 screen = new Screen(); // create screen
		 keypad = new Keypad(); // create keypad
		 cashDispenser = new CashDispenser(); // create cash dispenser
		 depositSlot = new DepositSlot(); // create deposit slot
		 bankDatabase = new BankDatabase(); // create acct info database
	}
	
	
	private class ButtonHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			if(event.getSource() == buttonESC)
			{
				screenOut = "";
				textField.setText(screenOut);
				return;
			}
			if(event.getSource() == buttonYes)
			{
				ATM atm = new ATM();
				atm.run();
				return;
			}
			screenOut = screenOut +
					String.format("%s", event.getActionCommand()); 
			textField.setText(screenOut);
			
			
			//JOptionPane.showMessageDialog(ATMGUI.this, String.format("you press%s",event.getActionCommand()));
		}
	}
	 public void run()
	  {
	  // welcome and authenticate user; perform transactions
	  while ( true )
	  {
	  // loop while user is not yet authenticated
	  while ( !userAuthenticated )
	  {
	  screen.displayMessageLine("/nWelcome");
	  authenticateUser(); // authenticate user
	  } // end while
	 
	  performTransactions(); // user is now authenticated
	  userAuthenticated = false; // reset before next ATM session
	  currentAccountNumber = 0; // reset before next ATM session
	 screen.displayMessageLine( "\nThank you! Goodbye!" );
	  } // end while
	  } // end method run
	 
	  // attempts to authenticate user against database
	  private void authenticateUser()
	  {
	 screen.displayMessage( "\nPlease enter your account number: " );
	  int accountNumber = keypad.getInput(); // input account number
	 screen.displayMessage( "\nEnter your PIN: " ); // prompt for PIN
	  int pin = keypad.getInput(); // input PIN
	  // set userAuthenticated to boolean value returned by database
	 userAuthenticated =
	  bankDatabase.authenticateUser( accountNumber, pin );
	 
	  // check whether authentication succeeded
	  if ( userAuthenticated )
	 {
	  currentAccountNumber = accountNumber; // save user's account #
	  } // end if
	  else
	  screen.displayMessageLine(
	  "Invalid account number or PIN. Please try again." );
	  } // end method authenticateUser
	 
	  // display the main menu and perform transactions
	  private void performTransactions()
	  {
	 // local variable to store transaction currently being processed
	  Transaction currentTransaction = null;
	  boolean userExited = false; // user has not chosen to exit
	 // loop while user has not chosen option to exit system
	   while ( !userExited )
	  {
	  // show main menu and get user selection
	  int mainMenuSelection = displayMainMenu();
	   // decide how to proceed based on user's menu selection
	   switch ( mainMenuSelection )
	   {
	  // user chose to perform one of three transaction types
	  case BALANCE_INQUIRY:
	   case WITHDRAWAL:
	  case DEPOSIT:
	   // initialize as new object of chosen type
	  currentTransaction =
	   createTransaction( mainMenuSelection );
	  currentTransaction.execute(); // execute transaction
	 break;
	   case EXIT: // user chose to terminate session
	   screen.displayMessageLine( "\nExiting the system..." );
	   userExited = true; // this ATM session should end
	   break;
	   default: // user did not enter an integer from 1-4
	   screen.displayMessageLine(
	   "\nYou did not enter a valid selection. Try again." );
	   break;
	   } // end switch
	   } // end while
	  } // end method performTransactions
	  
	   // display the main menu and return an input selection
	  private int displayMainMenu()
	   {
	   screen.displayMessageLine( "\nMain menu:" );
	   screen.displayMessageLine( "1 - View my balance" );
	   screen.displayMessageLine( "2 - Withdraw cash" );
	   screen.displayMessageLine( "3 - Deposit funds" );
	   screen.displayMessageLine( "4 - Exit\n" );
	   screen.displayMessage( "Enter a choice: " );
	   return keypad.getInput(); // return user's selection
	  } // end method displayMainMenu
}
	  // return object of specified Transaction subclass
*/
