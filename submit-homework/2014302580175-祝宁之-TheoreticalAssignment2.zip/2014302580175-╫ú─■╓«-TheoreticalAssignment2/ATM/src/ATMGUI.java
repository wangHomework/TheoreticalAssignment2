import java.awt.AWTException;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintStream;
import java.awt.event.ActionEvent;

import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ATMGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	
//�������������GUI��ģ�͵Ĺ�ͨ����	
	
	PrintStream printstream;
	String result;
	ATM atm;


	

//������	
	
	public static void main(String[] args) {

			try {
					ATMGUI frame =new ATMGUI();
					frame.setVisible(true);
					frame.atm.run();
				
				} catch (Exception e) {
					e.printStackTrace();
				}
				
		
		}

	/**
	 * Create the frame.
	 */
	public ATMGUI(){
		
//������׼������		
		atm=new ATM();
		result="";
		
//��ʼ����frame
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 384);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);


//JScrollPane�������
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 464, 177);
		contentPane.add(scrollPane);

//JTextArea������JScrollPane���������		
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setEditable(false);
		

//��ԭ����Screen�Ŀ���̨�����ΪJTextArea����Ĺؼ��������㾦֮��		
		
		
		printstream = new PrintStream(System.out)
		{
		      public void println(String str) 
		      {
		    	  textArea.append(str + "\n");
		    	  textArea.setCaretPosition(textArea.getText().length());
		      }
		      public void print(String str)
		      {
		    	  textArea.append(str);
		    	  textArea.setCaretPosition(textArea.getText().length());
		      }
		      
		      public void print(double num)
		      {
		    	  textArea.append(String.valueOf(num));
		    	  textArea.setCaretPosition(textArea.getText().length());
		      }
	     };
		      System.setOut(printstream);

		      
//11��button�ؼ������ҽ��result��ֵ����
		
		JButton btnNewButton = new JButton("1");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				result=result+"1";
				textArea.append("1");
			}
		});
		btnNewButton.setBounds(30, 197, 41, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				result=result+"2";
				textArea.append("2");
			}
		});
		btnNewButton_1.setBounds(91, 197, 41, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("3");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				result=result+"3";
				textArea.append("3");
			}
		});
		btnNewButton_2.setBounds(144, 197, 41, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("4");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				result=result+"4";
				textArea.append("4");
			}
		});
		btnNewButton_3.setBounds(30, 230, 41, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("5");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				result=result+"5";
				textArea.append("5");
			}
		});
		btnNewButton_4.setBounds(91, 230, 41, 23);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("6");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				result=result+"6";
				textArea.append("6");
			}
		});
		btnNewButton_5.setBounds(144, 230, 41, 23);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("7");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				result=result+"7";
				textArea.append("7");
			}
		});
		btnNewButton_6.setBounds(30, 263, 41, 23);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("8");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				result=result+"8";
				textArea.append("8");
			}
		});
		btnNewButton_7.setBounds(91, 263, 41, 23);
		contentPane.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("9");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				result=result+"9";
				textArea.append("9");
			}
		});
		btnNewButton_8.setBounds(144, 263, 41, 23);
		contentPane.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("0");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				result=result+"0";
				textArea.append("0");
			}
		});
		btnNewButton_9.setBounds(30, 296, 41, 23);
		contentPane.add(btnNewButton_9);

		
//enter����result����ģ��	
		
		JButton btnNewButton_10 = new JButton("Enter");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atm.keypad.i=Integer.parseInt(result);
				atm.keypad.bool=true;
				result="";
				
			}
		});
		btnNewButton_10.setBounds(91, 296, 93, 23);
		contentPane.add(btnNewButton_10);

		
//Ϊ�����۵Ŀɰ���β����������label ��	�������ɱ༭��text����ȻͼƬҲ�С�	
		
		
		JLabel lblTakeCashHere = new JLabel("   Take cash here ");
		lblTakeCashHere.setBounds(284, 197, 134, 29);
		contentPane.add(lblTakeCashHere);
		
		textField = new JTextField();
		textField.setBounds(233, 232, 241, 11);
		textField.setEditable(false);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblInsertDepositEnvelope = new JLabel("insert deposit envelope here");
		lblInsertDepositEnvelope.setBounds(272, 253, 184, 15);
		contentPane.add(lblInsertDepositEnvelope);
		
		textField_1 = new JTextField();
		textField_1.setBounds(233, 281, 241, 11);
		textField_1.setEditable(false);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		

	}
}
