package Text1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;









public class main2014302580158 extends JFrame {
	
	JPanel pan1;
	JPanel pan2;
	JPanel pan3;
	JPanel pan4;
	 JButton[] bt_dt;
	JButton[] bt_text;
     JTextArea txt;
	JLabel labl;
	public  String str3;
	public int a;
	public double d;
	public int accountNumber;
	public int PIN;
	public int temp;
	public int value;
	public double balance1=1200.00;
	public double balance2=200.00;
	public double b=0;
	public boolean enter=false;
	public boolean userAuthenticated;
	
    String[] str={"1","2","3","4","5","6","7","8","9","0","00","ȷ��","ȡ��","���"};
	
	GridLayout g1=new GridLayout(4,2,1,1);
	GridLayout g2=new GridLayout(5,2);
	GridLayout g3=new GridLayout(5,2);
	
	
	
	main2014302580158(){
		
		
		pan1=new JPanel();
		pan2=new JPanel();
	    pan1.setLayout(g1);
	 
	   
	    bt_dt=new JButton[str.length];
	  
	    txt=new JTextArea(15,25);
	    pan2.setBackground(Color.yellow);
	    txt.setEnabled(true);
	    pan2.add(txt);
	    
	   
	    for(int i=0;i<str.length;i++){
	    	bt_dt[i]=new JButton(str[i]);
	    	bt_dt[i].setActionCommand(str[i]);
	    	bt_dt[i].addActionListener(new btn());
	    	pan1.add(bt_dt[i]);
	    	        
	    }
	  /*  bt_dt[str.length-1]=new JButton(str[str.length-1]);
	     bt_dt[str.length-1].addActionListener(new ActionListener(){
	    	public void  actionPerformed(ActionEvent arg0){
	    		
	    		}
	    });
	    pan1.add(bt_dt[str.length-1]);*/
	    add(pan2,BorderLayout.CENTER);
	    add(pan1,BorderLayout.SOUTH);
	    
	    txt.setText("\nWelcome!");
		  txt.append("\nPlease enter your account number:\n(Ĭ��Ϊһ��������)");
	    }
public 	class btn implements ActionListener{
	@Override
	public void actionPerformed(ActionEvent e){
		 String getbt1_name=e.getActionCommand();
		 
		 if(getbt1_name=="ȷ��"){
			 temp=getnumber();
			 accountNumber=temp;
			if(accountNumber==12345)userAuthenticated = true;
			else userAuthenticated = false;
			
			  
			  		if( userAuthenticated){
				  enter=true;
				  txt.setText("\nMain menu:");
				  txt.append("\n1 - View my balance");
				  txt.append("\n2 - Withdraw cash");
				  txt.append("\n3 - Deposit funds");
				  txt.append("\n4 - Exit\n");
				  txt.append("\nEnter a choice:");
			  		}else{
			  			txt.setText("The wrong PIN , please try again");
			  		}
			
			 
			 }else if(getbt1_name=="ȡ��"){
				
				 char k=getnumber1();
				 switch(k){
					case '5':
						   balance1-=20;
						   if(balance1<0){
							   txt.setText("\n ��������");
						   }else{
						   txt.setText("\n - Available balance:"+balance1);
						   }
						break;
					case '6':
						
							balance1-=40;
							if(balance1<0){
								   txt.setText("\n ��������");
							   }else{
							txt.setText("\n - Available balance:"+balance1);
							   }
						break;
					case '7':
						
							balance1-=60;
							if(balance1<0){
								   txt.setText("\n ��������");
							   }else{
							txt.setText("\n - Available balance:"+balance1);
							   }
						break;
					case '8':
						
							balance1-=100;
							if(balance1<0){
								   txt.setText("\n ��������");
							   }else{
							txt.setText("\n - Available balance:"+balance1);
							   }
						break;
					case '9':
						
							balance1-=200;
							if(balance1<0){
								   txt.setText("\n ��������");
							   }else{
							txt.setText("\n - Available balance:"+balance1);
							   }
						break;
					case '0':
						txt.setText("\n  Canceling transaction...");

						break;
						default:
							 txt.setText("\nYou did not enter a valid selection. Try again.");
							  
						}
				 
			 }else if(getbt1_name=="���"){
				
				  double d= (double)getnumber();
				  
				  
				  if(d>0){
					 enter=true;
					  balance1+=d;
					
						  txt.setText("\n Please insert a deposit envelope containing $"+d);
						  txt.append("\n  Your envelope has been received.");
						  txt.append("\n  NOTE: The money just deposited will \n not be available until we verify \n the amount of any enclosed cash \n and your checks clear.");
						  
				  }
			 }else  {
				 	if(!enter){
				 			txt.append(getbt1_name);
				 				}else{
				 					txt.setText(getbt1_name);
				 					int m=getnumber();
				 					switch(m){
				 					case 1:
				 						txt.setText("\n Balance Information:");
				 						txt.append("\n - Available balance: $1,000.00 ");
				 						txt.append("\n- Total balance: $1,200.00");
				 						break;
				 					case 2:
				 						txt.setText("\n Withdrawal Menu:");
				 						txt.append("\n  5 - $20 ");
				 						txt.append("\n 6 - $40");
				 						txt.append("\n  7 - $60");
				 						txt.append("\n  8 - $100");
				 						txt.append("\n 9 - $200");
				 						txt.append("\n0 - Cancel transaction");
				 						txt.append("\n �밴ȡ���");
				 						txt.append("\n Choose a withdrawal amount:");
				 						enter=false;
				 								
				    
				 						break;
				 					case 3:
				 						txt.setText("\n  Please enter a deposit amount:");
				 						enter=false;
				 						txt.append("\n  �������������");
				 						  break;
				 					case 4:
				 						  txt.setText("\n  Exiting the system...");
				 						  txt.setText("\n  Thank you! Goodbye!");
				 						  break;
				 						  default:
				 							 txt.setText("\nYou did not enter a valid selection. Try again.");
					  
				 						}
				 					}
			 	}
			}
		}

//Account PIN�Ļ�ȡ

		public int getnumber(){
			
			//int m=txt.getCaretPosition();
			 str3=txt.getText();
			 String regEx="[^0-9]";   
			 Pattern   p   =   Pattern.compile(regEx);      
			 Matcher   m   =   p.matcher(str3);      
			 
			 //str3.indexOf(m);
			 int a=Integer.parseInt( m.replaceAll("").trim());
			 
			 return a;
			 
		}
		public char getnumber1(){
			
			str3=txt.getText();
			char c=str3.charAt(str3.length()-1);
			
			
			return c;
		}

public  void frame(){
	setSize(800,800);
	pan1.setBackground(Color.blue);
	pack();
	setTitle("ATMȡ���");
	setVisible(true);
}

//��ȡGUI�е�ֵ






	public static void main(String[] args) {
		// TODO �Զ����ɵķ������

		main2014302580158 in=new main2014302580158();
			in.frame();
	}

}
