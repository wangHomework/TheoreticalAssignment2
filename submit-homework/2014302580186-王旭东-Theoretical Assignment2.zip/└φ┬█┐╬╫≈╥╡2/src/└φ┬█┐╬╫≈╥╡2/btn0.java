package ���ۿ���ҵ2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class btn0 implements ActionListener
{

	int n = 0;
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
