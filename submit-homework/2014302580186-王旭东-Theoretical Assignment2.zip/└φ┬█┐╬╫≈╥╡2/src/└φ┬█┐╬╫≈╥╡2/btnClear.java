package ���ۿ���ҵ2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class btnClear implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub

	}

}
