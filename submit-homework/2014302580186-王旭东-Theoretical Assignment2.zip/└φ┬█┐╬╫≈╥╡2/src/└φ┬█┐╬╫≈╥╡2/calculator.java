package ���ۿ���ҵ2;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.*;

public class calculator extends JApplet{
Container contentPane;
JButton btn0=new JButton();
JButton btn1=new JButton();
JButton btn2=new JButton();
JButton btn3=new JButton();
JButton btn4=new JButton();
JButton btn5=new JButton();
JButton btn6=new JButton();
JButton btn7=new JButton();
JButton btn8=new JButton();
JButton btn9=new JButton();
JButton btnClear=new JButton();
JButton btnEqual=new JButton();
JButton btnPlus=new JButton();
JButton btnMinus=new JButton();
JButton btnMultiply=new JButton();
JButton btnDivide=new JButton();
JTextField textResult=new JTextField();
boolean flag=false;
String operand1;
String operand2;
double result;
String action;
public void init(){
	//contentPane=getContentPane();
	//contentPane.setLayout(null);
	//setSize(new Dimension(250,250));
	JFrame form = new JFrame("Calculator");
	form.setLayout(new GridLayout(4,4));
	//btn0.setBounds(new Rectangle(50,230,45,45));
	btn0.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
	btn0.setText("0");
	btn0.addActionListener(new btn0());
	//btnClear.setBounds(new Rectangle(100,230,45,45));
	btnClear.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
	btnClear.setText("C");
	btnClear.addActionListener(new btnClear());
	//btnEqual.setBounds(new Rectangle(150,230,45,45));
	btnEqual.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
	btnEqual.setText("=");
	btnEqual.addActionListener(new btnEqual());
	//btnPlus.setBounds(new Rectangle(200,230,45,45));
	btnPlus.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
	btnPlus.setText("+");
	btnPlus.addActionListener(new btnPlus());
	//btn1.setBounds(new Rectangle(50,180,45,45));
	btn1.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
	btn1.setText("1");
	btn1.addActionListener(new btn1());
   // btn2.setBounds(new Rectangle(100,180,45,45));
    btn2.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
    btn2.setText("2");
    btn2.addActionListener(new btn2());
    //btn3.setBounds(new Rectangle(150,180,45,45));
    btn3.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
    btn3.setText("3");
    btn3.addActionListener(new btn3());
   // btn4.setBounds(new Rectangle(50,130,45,45));
    btn4.setText("4");
    btn4.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
    btn4.addActionListener(new btn4());
    btn5.setText("5");
    //btn5.setBounds(new Rectangle(100,130,45,45));
    btn5.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
    btn5.addActionListener(new btn5());
   // btn6.setBounds(new Rectangle(150,130,45,45));
    btn6.setText("6");
    btn6.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
    btn6.addActionListener(new btn6());
    //btn7.setBounds(new Rectangle(50,80,45,45));
    btn7.setText("7");
    btn7.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
    btn7.addActionListener(new btn7());
    //btn8.setBounds(new Rectangle(100,80,45,45));
    btn8.setText("8");
    btn8.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
    btn8.addActionListener(new btn8());
    //btn9.setBounds(new Rectangle(150,80,45,45));
    btn9.setText("9");
    btn9.setFont(new java.awt.Font("wxd", Font.PLAIN,14));
    btn9.addActionListener(new btn9());
    //btnMinus.setBounds(new Rectangle(200,180,45,45));
    btnMinus.setText("-");
    btnMinus.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
    btnMinus.addActionListener(new btnMinus());
    //btnMultiply.setBounds(new Rectangle(200,130,45,45));
    btnMultiply.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
    btnMultiply.setText("*");
    btnMultiply.addActionListener(new btnMultiply());
   // btnDivide.setBounds(new Rectangle(200,80,45,45));
    btnDivide.setText("/");
    btnDivide.setFont(new java.awt.Font("wxd",Font.PLAIN,14));
    btnDivide.addActionListener(new btnDivide());
    form.add(btn0);
    form.add(btn1);
    form.add(btn2);
    form.add(btn3);
    form.add(btnPlus);
    form.add(btn3);
    form.add(btn4);
    form.add(btn5);
    form.add(btn6);
    form.add(btn7);
    form.add(btn8);
    form.add(btn9);

    form.add(btnDivide);

    form.add(btnClear);

    form.add(btnMultiply);

    form.add(btnEqual);

    form.add(btnMinus);

    TextArea txt = new TextArea();
    txt.setColumns(2);
    form.add(txt);
    form.pack();
    form.setVisible(true);
}
}

