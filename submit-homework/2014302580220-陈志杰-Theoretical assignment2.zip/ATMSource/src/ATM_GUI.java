import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class ATM_GUI {
	
	private PrintStream printstream;
    String input = "";
    public ATM atm;
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ATM_GUI gui=new ATM_GUI();
		gui.atm.run();
	}
	
	  //the component of GUI window
	  private JFrame frame;
	  public  JTextArea details_textArea;
	  private JButton button_1; 
	  private JButton button_2; 
	  private JButton button_3; 
	  private JButton button_4; 
	  private JButton button_5; 
	  private JButton button_6; 
	  private JButton button_7; 
	  private JButton button_8; 
	  private JButton button_9;
	  private JButton button_0; 
	  private JButton button_enter;
	  private JScrollPane scroll = new JScrollPane();
	  private JLabel takeCashHere_label;
	  private JLabel insert_label;
	  private JLabel background;
	  public ATM_GUI()
	  {
		  initializeAll();
		  atm = new ATM();
		  printstream = new PrintStream(System.out){
		      public void println(String x) {
		        details_textArea.append(x + "\n");
		        details_textArea.setCaretPosition(details_textArea.getText().length());
		      }
		      public void print(String x){
		    	details_textArea.append(x);
		        details_textArea.setCaretPosition(details_textArea.getText().length());}
		      
		      public void print(double x){
		    	details_textArea.append(String.valueOf(x));
		        details_textArea.setCaretPosition(details_textArea.getText().length());}
		      };
		      System.setOut(printstream);
	  }
	  //initialize method
	  public void initializeAll(){
		  //initialize window
		  frame_initialize();
		  //initialize screen
		  details_textArea_initialize();
		  //initialize buttons 
		  button_1_initialize();
		  button_2_initialize();
		  button_3_initialize();
		  button_4_initialize();
		  button_5_initialize();
		  button_6_initialize();
		  button_7_initialize();
		  button_8_initialize();
		  button_9_initialize();
		  button_0_initialize();
		  button_enter_initialize();
		  scroll_initialize();
		  takeCashHere_label_initialize();
		  insert_label_initialize();
		  background_initialize();
	  }

	  //Several initialization
	  public void frame_initialize(){
		  frame = new JFrame("ATMȡ���"); 
		  frame.setSize(800,600);
		  frame.setVisible(true);
		  frame.setLayout(null);
		  frame.setResizable(false);
	 	  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  }

	  public void details_textArea_initialize(){
		  details_textArea = new JTextArea();
		  frame.add(details_textArea);
		  details_textArea.setBounds(20, 10,750, 250);
		  details_textArea.setEditable(false);
		  details_textArea.setBackground(Color.GRAY);
		  details_textArea.setLineWrap(true);
		  details_textArea.setFont(new java.awt.Font("Dialog",1,20));
	  }

	  public void button_1_initialize(){
		  button_1 = new JButton();
		  frame.add(button_1);
		  button_1.setBounds(20,280, 100, 50);
		  button_1.setBackground(Color.pink);
		  button_1.setText("1");	 
		  button_1.addActionListener(new ActionListener() {
		  @Override
		  public void actionPerformed(ActionEvent arg0) {
		  input += "1";
		  details_textArea.append("1");
		  }
		  });
	  }

	  public void button_2_initialize(){
		  button_2 = new JButton();
		  frame.add(button_2);
		  button_2.setBounds(140,280, 100, 50);
		  button_2.setBackground(Color.pink);
		  button_2.setText("2");	 
		  button_2.addActionListener(new ActionListener() {
			  @Override
		  public void actionPerformed(ActionEvent arg0) {
		  input += "2";
		  details_textArea.append("2");
		  }
		  });
	  }

	  public void button_3_initialize(){
		  button_3 = new JButton();
		  frame.add(button_3);
		  button_3.setBounds(260,280, 100, 50);
		  button_3.setBackground(Color.pink);
		  button_3.setText("3");
		  button_3.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			input += "3";
			details_textArea.append("3");
		}
		  });
	  }

	  public void button_4_initialize(){
		  button_4 = new JButton();
		  frame.add(button_4);
		  button_4.setBounds(20,350, 100, 50);
		  button_4.setBackground(Color.pink);
		  button_4.setText("4");
		  button_4.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			input += "4";
			details_textArea.append("4");
			}
		 });
	  }

	  public void button_5_initialize(){
		  button_5 = new JButton();
		  frame.add(button_5);
		  button_5.setBounds(140,350, 100, 50);
		  button_5.setBackground(Color.pink);
		  button_5.setText("5");
		  button_5.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			input += "5";
			details_textArea.append("5");
			}
		  });
	  }

	  public void button_6_initialize(){
		  button_6 = new JButton();
		  frame.add(button_6);
		  button_6.setBounds(260,350, 100, 50);
		  button_6.setBackground(Color.pink);
		  button_6.setText("6");
		  button_6.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			input += "6";
			details_textArea.append("6");
			}
		  });
	  }

	  public void button_7_initialize(){
		  button_7 = new JButton();
		  frame.add(button_7);
		  button_7.setBounds(20,420, 100, 50);
		  button_7.setBackground(Color.pink);
		  button_7.setText("7");
		  button_7.addActionListener(new ActionListener() {
			@Override
		   public void actionPerformed(ActionEvent arg0) {
				input += "7";
				details_textArea.append("7");
			}
		});
}

	 public void button_8_initialize(){
		 button_8 = new JButton();
		 frame.add(button_8);
		 button_8.setBounds(140,420, 100, 50);
		 button_8.setBackground(Color.pink);
		 button_8.setText("8");
		 button_8.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				input += "8";
				details_textArea.append("8");
			}
		});
	 }
	 
	 public void button_9_initialize(){
		 button_9 = new JButton();
		 frame.add(button_9);
		 button_9.setBounds(260,420, 100, 50);
		 button_9.setBackground(Color.pink);
		 button_9.setText("9");
		 button_9.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				input += "9";
				details_textArea.append("9");
			}
		});
	 }
	 
	 public void button_0_initialize(){
		 button_0 = new JButton();
		 frame.add(button_0);
		 button_0.setBounds(20,490, 100, 50);
		 button_0.setBackground(Color.pink);
		 button_0.setText("0");
		 button_0.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				input += "0";
				details_textArea.append("0");
			}
		});
	 }
	 
	 public void button_enter_initialize(){
		 button_enter = new JButton();
		 frame.add(button_enter);
		 button_enter.setBounds(140,490, 221, 50);
		 button_enter.setBackground(Color.pink);
		 button_enter.setText("Enter");
		 button_enter.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				atm.keypad.n=Integer.parseInt(input);
				atm.keypad.am=true;
				input="";
		}});
	 }
	 
	 public void scroll_initialize(){
	    scroll = new JScrollPane();
		scroll.setBounds(20, 10,750, 250);
		frame.add(scroll);
		scroll.setViewportView(details_textArea);
	 }
	 
	 public void takeCashHere_label_initialize(){
		 ImageIcon BI1 =new ImageIcon("images/takecashhere.jpg");
		 takeCashHere_label = new JLabel(BI1);
		 frame.add(takeCashHere_label);
		 takeCashHere_label.setBounds(420, 300,320,100);
	 }
	 
	 //insert image initialization
	 public void insert_label_initialize(){
		 ImageIcon BI2 =new ImageIcon("images/insert.jpg");
		 insert_label = new JLabel(BI2);
		 frame.add(insert_label);
		 insert_label.setBounds(420, 420,320, 100);
	 }
	
	 //background image initialization
	 public void background_initialize(){
		 ImageIcon BI =new ImageIcon("images/background.jpg");
		 background = new JLabel(BI);
		 background.setBounds(0, 0, BI.getIconWidth(),

				 BI.getIconHeight());

				 JPanel backPanel = (JPanel) frame.getContentPane();

				 backPanel.setOpaque(false);

				 frame.getLayeredPane().setLayout(null);

				 frame.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));

				 backPanel.setLayout(new BorderLayout());
	 }
	 
	 
}
