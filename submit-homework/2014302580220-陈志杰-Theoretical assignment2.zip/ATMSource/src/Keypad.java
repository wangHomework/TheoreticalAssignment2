
public class Keypad
 {
 public int n;
 public boolean am=false;

//rewrite method getInput
 public int getInput()
 {
	 //use am and while to get input from GUI window
	 am =false;
	 while(!am){System.out.print("");}
     return n;
 } 
 }