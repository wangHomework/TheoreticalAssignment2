// Keypad.java
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;




// Represents the keypad of the ATM
import javax.swing.*;

public class Frame extends JFrame
{
	private Client client=new Client();
    private Screen screen=new Screen();
    private CashDispenser cashDispenser=new CashDispenser();
    private DepositSlot depositSlot=new DepositSlot();
    private keypadPanel keypadPanel=new keypadPanel();
	public Frame()
	{
		client.setClient("12345", "12345", 1000);
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		this.setLocation(250, 200);
		this.setSize(400,280);
		this.setLayout(new GridLayout(2,1,0,5));
		this.add(screen);
		JPanel panelCash=new JPanel();
		JPanel panelDown=new JPanel();
		panelCash.setLayout(new GridLayout(2,1,0,5));
		panelDown.setLayout(new GridLayout(1,2,5,0));
		panelCash.add(cashDispenser);
		panelCash.add(depositSlot);
		panelDown.add(keypadPanel);
		panelDown.add(panelCash);
		this.add(panelDown);
		this.setTitle("ATM Test Account number and password both are 12345");
		
	}
	class keypadPanel extends JPanel{
		public keypadPanel(){
			showKeypad();
		} 
		private void showKeypad(){
			this.setLayout(new GridLayout(4,3,5,5));
			for(int i=0;i<=9;i++){
				JButton jb = new JButton(""+i);
			    this.add(jb);
			    setListener(jb,"i");}
				JButton buttonEnter = new JButton("Enter");
				this.add(buttonEnter);
				
			
		}
		private void setListener(JButton a,String number){
			a.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) 
	            {
	            	switch(screen.choice){
	            	case 1:
	            		if(screen.nextInput==1){
	            			screen.setLabelAccountNum(screen.getLabelAccountNum()+number);
	            		}
	            		if(screen.nextInput==2){
	            			screen.setLabelPinNum(screen.getLabelPinNum()+number);
	            		}
	            		break;
	            	case 2:
	            		if(Integer.parseInt(number)<5)
	            			screen.setInput3(number);
	            		break;
	            	case 3:
	            		if(Integer.parseInt(number)<7)
	            			screen.setInput4(number);
	            		break;
	            	case 4:screen.setInput5(screen.getInput5()+number);break;
	                default:break;
	            	}
	            }
			});
		}
		private void setSureButton(JButton a){
			a.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) 
	            {
	            	if(screen.choice==1){
	            		if(screen.nextInput==1){
	            			screen.nextInput=2;
	            		}
	            		else{
	            			if(client.checkAccount(screen.getLabelAccountNum())){
	            				if(client.checkPassword(screen.getLabelPinNum())){
	            					screen.change(2);
	            					screen.setLabelPinNum("");
	            					screen.setLabelAccountNum("");
	            					screen.nextInput=1;
	            				}
	            				else{
	            					JOptionPane.showMessageDialog(null, "password error"
											,"ERROR",JOptionPane.ERROR_MESSAGE);
	            					screen.setLabelPinNum("");
	            				}
	            			}
	            			else{
	            				JOptionPane.showMessageDialog(null, "accountNumber error"
										,"ERROR",JOptionPane.ERROR_MESSAGE);
	            				screen.setLabelPinNum("");
            					screen.setLabelAccountNum("");
	            				screen.nextInput=1;
	            			}
	            		}
	            	}
	            	if(screen.choice==2){
	            		switch (screen.getInput3())
	            		{
	            		case "1":screen.Screen5(client);break;
	            		case "2":screen.change(3);break;
	            		case "3":screen.change(4);break;
	            		case "4":System.exit(0);break;
	            		default :
	            			JOptionPane.showMessageDialog(null, "Chose a number between 1 to 4!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            				break;
	            		}
	            	}
	            	
	            	if(screen.choice==3){
	            		//Withdrawal
	            		switch (screen.getInput4()){
	            		case "1":
	            			client.drawMoney(20);
	            			JOptionPane.showMessageDialog(null, "You draw $20 successfully! Take it!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            			screen.change(2);
	            			break;
	            		case "2":
	            			client.drawMoney(40);
	            			JOptionPane.showMessageDialog(null, "You draw $40 successfully! Take it!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            			screen.change(2);
	            			break;
	            		case "3":
	            			client.drawMoney(60);
	            			JOptionPane.showMessageDialog(null, "You draw $60 successfully! Take it!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            			screen.change(2);
	            			break;
	            		case "4":
	            			client.drawMoney(100);
	            			JOptionPane.showMessageDialog(null, "You draw $100 successfully! Take it!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            			screen.change(2);
	            			break;
	            		case "5":
	            			client.drawMoney(200);
	            			JOptionPane.showMessageDialog(null, "You draw $200 successfully! Take it!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            			screen.change(2);
	            			break;
	            		case "6":
	            			screen.change(2);
	            			break;
	            		default :break;
	            		}
	            		screen.setInput3("");
	            		screen.setInput4("");
	            	}
	            	if(screen.choice==4){
	            		//deposit
	            		client.deposit(Double.valueOf(screen.getInput5()));
	            		JOptionPane.showMessageDialog(null, "You can deposit your money now!"
								,"Nice",JOptionPane.INFORMATION_MESSAGE);
	            		screen.change(2);
            			screen.setInput3("");
            			screen.setInput5("");
	            	}
	            	if(screen.choice==5)
	            	{
	            		screen.change(2);
	            		screen.setInput3("");
	            	}
	            }
		    });
		}
		private void setBackButton(JButton a){
			a.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) 
	            {
	            	switch (screen.choice)
	            	{
	            	case 1:
	            		screen.setLabelPinNum("");
    					screen.setLabelAccountNum("");
    					screen.nextInput=1;
    					break;
	            	case 2:
	            		screen.setInput3("");break;
	            	case 3:
	            		screen.setInput4("");break;
	            	case 4:
	            		screen.setInput5("");break;
	            	case 5:
	            		screen.change(2);
	            		screen.setInput3("");
	            		break;
	            	default : break;
	            	}
	            }
		    });
		}
	}
    
} 



