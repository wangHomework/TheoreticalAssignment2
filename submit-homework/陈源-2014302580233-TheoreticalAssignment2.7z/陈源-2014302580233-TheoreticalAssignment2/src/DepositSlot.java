import java.awt.Color;
import java.awt.Graphics;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

// DepositSlot.java
// Represents the deposit slot of the ATM

public class DepositSlot extends JPanel
{
	public DepositSlot(){
        setSize(300,100);
        setBackground(new Color(197,228,250));
        setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
    }
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawString("Insert deposit envelope here", this.getWidth()/2-80, 20);
        g.drawRect(30, this.getHeight()-30, 230, 10);
    }
} // end class DepositSlot


