
public class Client {
	    private String accountNumber=null;
	    private String password=null;
	    private double money=0;
	    public boolean setClient(String accountNumber,String password,double money){
	        if(accountNumber.isEmpty()||password.isEmpty()||money<0)
	            return false;
	        this.accountNumber=accountNumber;
	        this.password=password;
	        this.money=money;
	        return true;
	    }
	    public boolean checkAccount(String account){
	        if(account.compareTo(accountNumber)==0)
	            return true;
	        else 
	            return false;
	    }
	    public boolean checkPassword(String password){
	        if(password.compareTo(this.password)==0)
	            return true;
	        else 
	            return false;
	    }
	    public boolean deposit(double money){
	        if(money<=0)
	            return false;
	        this.money+=money;
	        return true;
	    }
	    public boolean drawMoney(double money){
	        if(money<=0||money>this.money)
	            return false;
	        this.money-=money;
	        return true;
	    }
	    public String getMoney(){
	        return String.valueOf(money);
	    }
}
