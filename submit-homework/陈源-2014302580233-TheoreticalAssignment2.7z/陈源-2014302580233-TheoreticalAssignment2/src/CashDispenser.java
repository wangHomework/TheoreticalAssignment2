import java.awt.Color;
import java.awt.Graphics;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

// CashDispenser.java
// Represents the cash dispenser of the ATM

public class CashDispenser extends JPanel
{
	public CashDispenser(){
        setSize(300,100);
        setBackground(new Color(197,228,250));
        setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
    }
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawString("Take cash here", this.getWidth()/2-40, 20);
        g.drawRect(30, this.getHeight()-30, 230, 10);
        
    }
} // end class CashDispenser


