package com;

/**
 * Created by HuXijie on 2015/10/29.
 * DepositSlot.java
 * Represents the deposit slot of the ATM
 */
public class DepositSlot {
    //indicates whether envelope was reveived(always returns true,
    //because this is only a software simulation of a real deposit slot)
    public boolean isEnvelopReceived() {
        return true;    //deposit envelope was received
    }
}
