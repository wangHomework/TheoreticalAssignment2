package com;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Created by Administrator on 2015/10/30.
 */
public class ATM_GUI {
    public static void main(String[] args) {
        new Login();
    }
}

//登陆
class Login {
    private JFrame jf;
    private JLabel jl;
    private JLabel jl2;
    private JLabel jl3;
    private JLabel jl4;
    private JTextField jtf;
    private JPasswordField jpw;
    private JButton jb;
    private BankDatabase bankDatabase = new BankDatabase();
    private Account account;

    public Login() {
        setJf();
        setJl();
        setJl2();
        setJl3();
        setJl4();
        setJb();
        keyPressed();
    }

    //构造窗口1
    private void setJf() {
        jf = new JFrame("ATM_Login");
        jf.setLayout(null);
        jf.setSize(450,500);
        jf.setLocationRelativeTo(null);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    //设置标签1
    private void setJl() {
        jl = new JLabel("Welcome!");
        jl.setBounds(50,30,100,30);
        jf.add(jl);
    }

    //设置标签2
    private void setJl2() {
        jl2 = new JLabel("Before use ATM, please enter your account number and PIN. ");
        jl2.setBounds(50,80,400,30);
        jf.add(jl2);
    }

    //设置标签3
    private void setJl3() {
        jl3 = new JLabel("AccountNumber:");
        jl3.setBounds(50,240,100,30);
        jtf = new JTextField();
        jtf.setBounds(180,240,200,30);
        jf.add(jl3);
        jf.add(jtf);
    }

    //设置标签4
    private void setJl4() {
        jl4 = new JLabel("PIN:");
        jl4.setBounds(50,280,100,30);
        jpw = new JPasswordField();
        jpw.setBounds(180,280,200,30);
        jf.add(jl4);
        jf.add(jpw);
    }

    //设置按钮
    private void setJb() {
        jb = new JButton("Login");
        jb.setBounds(150,320,100,30);
        jf.add(jb);

        jb.addActionListener(new ActionListener() {
            //验证用户名与密码
            public boolean userAuthenticated() {
                int userAccountNumber = Integer.parseInt(jtf.getText());
                int userPIN = Integer.parseInt(new String(jpw.getPassword()));
                if(bankDatabase.authenticateUser(userAccountNumber,userPIN)) {
                    account = bankDatabase.getAccount(userAccountNumber);
                }
                return bankDatabase.authenticateUser(userAccountNumber,userPIN);
            }
            @Override
            public void actionPerformed(ActionEvent e) {
                if(userAuthenticated()) {
                    jf.dispose();
                    jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                    new MainFrame(bankDatabase,account);
                }else {
                    JOptionPane.showMessageDialog(jf,"Invalid account number of PIN. Please try again.");
                    jtf.setText("");
                    jpw.setText("");
                }
            }
        });
    }

    //定义按下回车实现的功能
    private void keyPressed() {
        jpw.addKeyListener(new KeyListener() {
            public boolean userAuthenticated() {
                int userAccountNumber = Integer.parseInt(jtf.getText());
                int userPIN = Integer.parseInt(new String(jpw.getPassword()));
                if(bankDatabase.authenticateUser(userAccountNumber,userPIN)) {
                    account = bankDatabase.getAccount(userAccountNumber);
                }
                return bankDatabase.authenticateUser(userAccountNumber,userPIN);
            }
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                int target = e.getKeyCode();
                if(target == KeyEvent.VK_ENTER) {
                    if(userAuthenticated()) {
                        jf.dispose();
                        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                        new MainFrame(bankDatabase,account);
                    }else {
                        JOptionPane.showMessageDialog(jf,"Invalid account number of PIN. Please try again.");
                        jtf.setText("");
                        jpw.setText("");
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
    }
}

//主窗口
class MainFrame {
    private int userAccountNumber = 0;
    private BankDatabase currentBankDatabase;
    private Screen currentScreen = new Screen();
    private Keypad currentKeypad = new Keypad();
    private CashDispenser currentCashDispenser = new CashDispenser();
    private DepositSlot currentDepositSlot = new DepositSlot();
    private JFrame jf2;
    private JTextArea jta;
    private JLabel jl;
    private JLabel jl2;
    private JLabel jl3;
    private JLabel jl4;
    private String str[] = {"1","2","3","4","5","6","7","8","9","0","Enter"};
    private int withdrawalMoney[] = {20,40,60,100,200};
    private int depositMoney[] = {50,100,200,400,600};
    private double availableBalance;
    private double totalBalance;
    private JButton jb[] = new JButton[str.length];
    private int choice = 0;
    private int judge = 0;
    private Transaction transaction;
    private static final int BALANCE_INQUIRY = 1;
    private static final int WITHDRAWAL = 2;
    private static final int DEPOSIT = 3;
    private static final int EXIT =4;


    //获得当前账号
    public int getUserAccountNumber() {
        return userAccountNumber;
    }

    //获得当前数据库
    public BankDatabase getBankDatabase() {
        return currentBankDatabase;
    }

    //获得当前交易程序
    public Transaction getTransaction() {
        return transaction;
    }


    public MainFrame(BankDatabase bankDatabase,Account account) {
        userAccountNumber = account.getAccountNumber();
        currentBankDatabase = bankDatabase;
        setJf();
        setJta();
        setJl();
        setJl3();
        showMenu();
        setJb();
    }

    //构造窗口2
    private void setJf() {
        jf2 = new JFrame("ATM_Frame");
        jf2.setLayout(null);
        jf2.setSize(450, 480);
        jf2.setLocationRelativeTo(null);
        jf2.setVisible(true);
        jf2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    //设置文本域
    private void setJta() {
        jta = new JTextArea();
        jta.setEditable(false);
        jta.setBounds(10,10,415,200);
        jf2.add(jta);
    }

    //设置取钱标签与图标
    private void setJl() {
        jl = new JLabel("Take cash here");
        jl.setBounds(260,220,100,30);
        jf2.add(jl);
        Icon icon = new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                g.fillRect(5,10,200,10);
            }

            @Override
            public int getIconWidth() {
                return 0;
            }

            @Override
            public int getIconHeight() {
                return 0;
            }
        };
        jl2 = new JLabel(icon);
        jl2.setBounds(200,250,200,30);
        jf2.add(jl2);
    }

    //设置存钱标签与图标
    private void setJl3() {
        jl3 = new JLabel("Insert deposit envelope here");
        jl3.setBounds(230,320,200,30);
        jf2.add(jl3);
        Icon icon = new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                g.fillRect(5,10,200,10);
            }

            @Override
            public int getIconWidth() {
                return 0;
            }

            @Override
            public int getIconHeight() {
                return 0;
            }
        };
        jl4 = new JLabel(icon);
        jl4.setBounds(200,350,200,30);
        jf2.add(jl4);
    }

    //设置数字键盘按钮
    private void setJb() {
        for(int i = 0;i<str.length-1;i++) {
            jb[i] = new JButton(str[i]);
            if(i/3 == 0) {
                jb[i].setBounds(10+60*i,220,50,40);
            }else if(i/3==1) {
                jb[i].setBounds(10+60*(i-3),270,50,40);
            }else if(i/3==2){
                jb[i].setBounds(10+60*(i-6),320,50,40);
            }else {
                jb[i].setBounds(10+60*(i-9),370,50,40);
            }
            jf2.add(jb[i]);
        }

        jb[str.length-1] = new JButton(str[str.length-1]);
        jb[str.length-1].setBounds(70, 370, 110, 40);
        jf2.add(jb[str.length-1]);

        jb[0].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                choice = 1;
            }
        });

        jb[1].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                choice = 2;
            }
        });

        jb[2].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                choice = 3;
            }
        });

        jb[3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                choice = 4;
            }
        });

        jb[4].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                choice = 5;
            }
        });

        jb[5].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                choice = 6;
            }
        });

        jb[9].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                choice = 0;
            }
        });

        jb[10].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(judge == 0) {
                    transaction(choice);
                }else if(judge == 1) {
                    switch (choice) {
                        case 0:
                            jta.setText("");
                            showMenu();
                            judge = 0;
                            break;
                        default:
                            JOptionPane.showMessageDialog(jf2,"You did not enter a valid selection. Try again.");
                            judge = 1;
                    }
                }else if(judge == 2) {
                    switch (choice) {
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                            setWithdrawalExecute(choice);
                            break;
                        case 0:
                            jta.setText("");
                            showMenu();
                            judge = 0;
                            break;
                        default:
                            JOptionPane.showMessageDialog(jf2,"You did not enter a valid selection. Try again.");
                            judge = 2;
                    }
                }else if(judge == 3) {
                    switch (choice) {
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                            setDepositExecute(choice);
                            break;
                        case 0:
                            jta.setText("");
                            showMenu();
                            judge = 0;
                            break;
                    }
                }
            }
        });
    }

    //显示主菜单
    public void showMenu() {
        jta.append(System.lineSeparator()+"Main menu:");
        jta.append(System.lineSeparator() + "1 - View my balance");
        jta.append(System.lineSeparator() + "2 - Withdraw cash");
        jta.append(System.lineSeparator() + "3 - Deposit funds");
        jta.append(System.lineSeparator() + "4 - Exit");
        jta.append(System.lineSeparator() + "Enter a choice: ");
    }

    //获得并处理交易程序
    private void transaction(int choice) {
        switch (choice) {
            case BALANCE_INQUIRY:
                judge = 1;
                transaction = getTransaction(choice);
                setBalanceInquiryExecute();
                break;
            case WITHDRAWAL:
                judge = 2;
                transaction = getTransaction(choice);
                setWithdrawalShow();
                break;
            case DEPOSIT:
                judge = 3;
                transaction = getTransaction(choice);
                setDepositShow();
                break;
            case EXIT:
                System.exit(0);
                break;
            default:
                jta.setText("");
                jta.append(System.lineSeparator()+"You did not enter a valid selection. Try again.");
                showMenu();
                break;
        }
    }

    //获得交易程序
    private Transaction getTransaction(int choice) {
        Transaction tempTransaction=null;
        switch (choice) {
            case BALANCE_INQUIRY:
                tempTransaction = new BalanceInquiry(userAccountNumber,currentScreen,currentBankDatabase);
                break;
            case WITHDRAWAL:
                tempTransaction = new Withdrawal(userAccountNumber,currentScreen,currentBankDatabase,currentKeypad,currentCashDispenser);
                break;
            case DEPOSIT:
                tempTransaction = new Deposit(userAccountNumber,currentScreen,currentBankDatabase,currentKeypad,currentDepositSlot);
                break;
        }
        return tempTransaction;
    }

    //显示余额
    private void setBalanceInquiryExecute() {
        availableBalance = currentBankDatabase.getAvailableBalance(transaction.getAccountNumber());
        totalBalance = currentBankDatabase.getTotalBalance(transaction.getAccountNumber());
        jta.setText("");
        jta.append(System.lineSeparator()+"Balance Information:");
        jta.append(System.lineSeparator()+" - Available balance: ");
        jta.append(System.lineSeparator()+availableBalance);
        jta.append(System.lineSeparator()+" - Total balance:    ");
        jta.append(System.lineSeparator()+totalBalance);
        jta.append(System.lineSeparator()+"Select 0 to go back to menu.");
    }

    //显示取款
    private void setWithdrawalShow() {
        jta.setText("");
        jta.append(System.lineSeparator()+"Withdrawal Menu:");
        jta.append(System.lineSeparator()+"1 - $20");
        jta.append(System.lineSeparator()+"2 - $40");
        jta.append(System.lineSeparator()+"3 - $60");
        jta.append(System.lineSeparator()+"4 - $100");
        jta.append(System.lineSeparator()+"5 - $200");
        jta.append(System.lineSeparator()+"0 - Cancel transaction");
        jta.append(System.lineSeparator()+"Choose a withdrawal amount: ");
    }

    //处理取款
    private void setWithdrawalExecute(int choice) {
        availableBalance = currentBankDatabase.getAvailableBalance(transaction.getAccountNumber());
        totalBalance = currentBankDatabase.getTotalBalance(transaction.getAccountNumber());
        if(withdrawalMoney[choice-1]<=availableBalance) //检查账户中是否有足够的钱
        {
            //检查ATM机中是否有足够的钱
            if(currentCashDispenser.isSufficientCashAvailable(withdrawalMoney[choice-1]))
            {
                //更新账户余额
                currentBankDatabase.debit(userAccountNumber,withdrawalMoney[choice-1]);
                //更新ATM余额
                currentCashDispenser.dispenseCash(withdrawalMoney[choice-1]);

                //引导用户取钱
                JOptionPane.showMessageDialog(jf2,"Your cash has been"+
                        " dispensed.Please take your cash now.");
            } else    //ATM机中没有足够的钱
            {
                JOptionPane.showMessageDialog(jf2,"Insufficient cash available in the ATM." +
                        "\n\nPlease choose a smaller amount.");
            }
        }else   //账户中没有足够的钱
        {
            JOptionPane.showMessageDialog(jf2,"Insufficient funs in your account." +
                    "\n\nPlease choose a smaller amount.");
        }
    }

    //显示存款界面
    private void setDepositShow()
    {
        jta.setText("");
        jta.append(System.lineSeparator() + "\nPlease select a deposit amount 0 to cancel: ");
        jta.append(System.lineSeparator()+"1 - $50");
        jta.append(System.lineSeparator()+"2 - $100");
        jta.append(System.lineSeparator()+"3 - $200");
        jta.append(System.lineSeparator()+"4 - $400");
        jta.append(System.lineSeparator()+"5 - $600");
        jta.append(System.lineSeparator()+"0 - Cancel transaction");
    }

    //处理存款
    private void setDepositExecute(int choice) {
        availableBalance = currentBankDatabase.getAvailableBalance(transaction.getAccountNumber());
        totalBalance = currentBankDatabase.getTotalBalance(transaction.getAccountNumber());

        //检测是否已存入现金
        boolean envelopReceived = currentDepositSlot.isEnvelopReceived();

        //若已存入现金
        if (envelopReceived) {
            currentBankDatabase.credit(transaction.getAccountNumber(), depositMoney[choice - 1]);
            JOptionPane.showMessageDialog(jf2, "Your envelope has been " +
                    "received.\nNOTE: The money just deposited will not " +
                    "be available until we vertify the amount of any " +
                    "enclosed cah and your checks clear.");
        } else    //没有存入现金
        {
            JOptionPane.showMessageDialog(jf2, "You did not insert an " +
                    "envelope, so the ATM has canceled your transaction. ");
        }
    }
}
