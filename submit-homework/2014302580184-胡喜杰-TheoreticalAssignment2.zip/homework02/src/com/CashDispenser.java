package com;

/**
 * Created by HuXijie on 2015/10/29.
 * CashDispenser.java
 * Represents the cash dispenser of the ATM
 */
public class CashDispenser {
    //the default initial number of bills in the cash dispenser
    private final static int INITIAL_COUNT = 500;
    private int count;      //numbers of $20 bills remaining

    public CashDispenser()
    {
        count = INITIAL_COUNT;  //set count attribute to default
    }

    //simulates dispensing of specified amount of cash
    public void dispenseCash(int amount)
    {
        int billsRequired = amount/20;  //number of $20 bills required
        count -= billsRequired; //update the count of bills
    }

    //indicates whether cash dispenser can dispense desired amount
    public boolean isSufficientCashAvailable(int amount)
    {
        int billsRequired = amount/20;  //number of $20 bills required

        if(count>=billsRequired) return true;   //enough bills avaiable
        else return false;  //not enough bills avaiable
    }
}
