import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class GUI extends JFrame{
	private static final long serialVersionUID = 1L;
	private ATM atm;
	private JPanel pan;
	private JButton btn[];
	private JTextField tf[];
	private JTextArea ta;
	private JScrollPane sp;
	private PrintStream ps;
	private StringBuffer sb;
	private boolean bip;
	
	public static void main( String[] args ){
		GUI gui = new GUI();
		gui.atm.run();
	}	
	
	public GUI(){
		super("ATM");
		atm = new ATM();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(450, 400);
		pan = new JPanel();
		pan.setLayout(null);
		add(pan);
		
		sb = new StringBuffer();
		btn = new JButton[11];
		for(int i = 0;i < 3;i++)
			for(int j = 1;j <= 3;j++){
			btn[i*3+j] = new JButton(""+(i*3+j));
			btn[i*3+j].setBounds(j*50-30, 170+i*45, 45, 40);
			}
		btn[0] = new JButton(""+0);
		btn[0].setBounds(20, 305, 45, 40);
		class numberAL implements ActionListener{
			private int n;
			numberAL(int n){
				this.n = n;
			}
			public void actionPerformed(ActionEvent e) {
				if(bip==false) {
					sb.append(n);
					bip=true;
					ta.append(""+n);
					return;
				}
				else sb.append(n);
				ta.append(""+n);
			}
		}
		for(int i = 0;i < 10;i++)btn[i].addActionListener(new numberAL(i));
		btn[10] = new JButton("Enter");
		btn[10].setBounds(70, 305, 95, 40);
		btn[10].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					atm.setInput(Integer.parseInt(sb.toString()));
					sb.setLength(0);
			}
		});
		for(int i = 0;i < 11;i++)pan.add(btn[i]);
		
		tf = new JTextField[4];
		tf[0] = new JTextField("Take cash here");
		tf[0].setBounds(285, 190, 90, 20);
		tf[1] = new JTextField(20);
		tf[1].setBounds(250, 220, 160, 20);
		tf[2] = new JTextField("Insert deposit envolope here");
		tf[2].setBounds(250, 270, 160, 20);
		tf[3] = new JTextField(20);
		tf[3].setBounds(250, 300, 160, 20);
		for(int i = 0;i < 4;i++)tf[i].setEditable(false);
		for(int i = 0;i < 4;i++)pan.add(tf[i]);
		
		ta = new JTextArea();
		ta.setEditable(false);
		sp = new JScrollPane(ta);
		sp.setBounds(20, 10, 390, 150);
		pan.add(sp);
		
		ps = new PrintStream(System.out){
			public void println(String str) {
		        ta.append(str + "\n");
		        ta.setCaretPosition(ta.getText().length());
		    }
			
		    public void print(String str) {
		    	ta.append(str);
		    	ta.setCaretPosition(ta.getText().length());
		    }
		      
		    public void print(double x) {
		    	ta.append(String.valueOf(x));
		        ta.setCaretPosition(ta.getText().length());}
		};
		System.setOut(ps);
		
		//sb.append(6);
		//ta.append(sb.toString());
		
		setVisible(true);
	}
} 