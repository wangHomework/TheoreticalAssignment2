public class Keypad{
	private int input;
	private boolean bip;
	
	public int getInput(){
		bip = false;
		while(!bip){System.out.print("");}
		return input;
	}
	
	public void setInput(int input){
		this.input = input;
		bip = true;
	}
}