

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class ATM_Login extends JFrame{

	private JLabel User,Password,TestAccount;
	private JTextField Account,pin;
	private JButton LoginOK,LoginCANCEL;
	private JPanel L1,L2,L3,L4;
	private ATM theATM;
	public  ATM_Login() {
		// TODO Auto-generated constructor stub
		//������Ϣ
		User = new JLabel("UserName");
		Password = new JLabel("Password");
		TestAccount =new JLabel("Test User Name 12345,Password 54321");
		Account = new JTextField(20);
		pin = new JTextField(20);
		LoginOK = new JButton("LOGIN");
		LoginCANCEL = new JButton("CANCEL");
		
		theATM = new ATM();
		
		L1 = new JPanel();
		L2 = new JPanel();
		L3 = new JPanel();
		L4 = new JPanel();
		
		L1.add(User);
		L1.add(Account);
		L2.add(Password);
		L2.add(pin);
		L3.add(LoginOK);
		L3.add(LoginCANCEL);
		L4.add(TestAccount);
		
		this.add(L1);
		this.add(L2);
		this.add(L3);
		this.add(L4);
		//��������
		this.setLayout(new GridLayout(4, 1));
		this.setTitle("ATM LOGIN");
		this.setSize(400, 400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		//��֤�û����룬�����������
		LoginCANCEL.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						dispose();
					}
				}
			);
				
		LoginOK.addActionListener(new ActionListener() {		
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int accountNumber1 =Integer.parseInt(Account.getText());
				int password=Integer.parseInt(pin.getText());
				
				boolean x =theATM.authenticateUser(accountNumber1, password);
							if (x) {
									ATM_GUI b= new ATM_GUI(theATM);
									dispose();
									}else{
										JOptionPane.showMessageDialog(null, "input error"
												,"ERROR",JOptionPane.ERROR_MESSAGE);
										}
							}
					}
			);		
		
		
		
		}
}
