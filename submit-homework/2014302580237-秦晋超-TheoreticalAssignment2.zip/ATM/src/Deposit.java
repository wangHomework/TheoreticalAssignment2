import javax.swing.JOptionPane;

public class Deposit extends Transaction
 {
 private double amount; // amount to deposit
 private Keypad keypad; // reference to keypad
 private DepositSlot depositSlot; // reference to deposit slot
 private final static int CANCELED = 0; // constant for cancel option

 // Deposit constructor
 public Deposit( int userAccountNumber, 
 BankDatabase atmBankDatabase, Keypad atmKeypad,
 DepositSlot atmDepositSlot )
 {
 // initialize superclass variables
 super( userAccountNumber,  atmBankDatabase );

 // initialize references to keypad and deposit slot
 keypad = atmKeypad;
 depositSlot = atmDepositSlot;
 } // end Deposit constructor

 // perform transaction
 @Override
 public void execute()
 {
	 
	 boolean envelopeReceived = depositSlot.isEnvelopeReceived();
	 if (envelopeReceived) {
		 JOptionPane.showMessageDialog(null, 
				"\nPlease insert a deposit envelope containing",
				"Deposit Information",JOptionPane.INFORMATION_MESSAGE);
	 
	}
	
 } // end method execute
 } // end class Deposit