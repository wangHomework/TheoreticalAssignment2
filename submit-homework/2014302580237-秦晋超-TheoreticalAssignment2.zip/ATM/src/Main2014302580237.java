
public class Main2014302580237 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ATM_Login a = new ATM_Login();
		 
	}

}
