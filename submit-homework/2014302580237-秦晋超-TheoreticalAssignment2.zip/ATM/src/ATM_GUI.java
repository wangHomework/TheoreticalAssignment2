import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ATM_GUI extends JFrame{

	private ATM ATM;
	
	private JButton Deposit,Withdraw,Cancel,Inquiry;
	private JLabel Message;
	private JPanel L1 =new JPanel();
	private JPanel L2 =new JPanel();
	private JPanel L3 =new JPanel();
	private JPanel L4 =new JPanel();
	
	public ATM_GUI( ATM theATM) {
		
		this.ATM = theATM;
		Deposit = new JButton("���");
		Withdraw = new JButton("ȡ��");
		Inquiry = new JButton("��ѯ���");
		Cancel = new JButton("����");
		Message = new JLabel();
		
		L1.add(Inquiry);
		L2.add(Deposit);
		L2.add(Withdraw);
		L3.add(Cancel);
		L4.add(Message);
		
		this.add(L1);
		this.add(L2);
		this.add(L3);
		this.add(L4);
		
		this.setLayout(new GridLayout(4, 1));
		this.setTitle("ATM MAIN INTERFACE");
		this.setSize(600, 400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		
		Inquiry.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				BalanceInquiry currentTransaction=ATM.createBalanceInquiry();
				currentTransaction.execute();
				JOptionPane.showMessageDialog(null, 
			"\n- Available balance: "+currentTransaction.availableBalance
			+"\n - Total balance:"+currentTransaction.totalBalance+"\n",
			"Balance Information",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		Deposit.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Deposit currentTransaction=ATM.createDeposit();
				String s =JOptionPane.showInputDialog("Please enter a deposit amount :");
				double ipt = Double.parseDouble(s);
				if ( ipt != 0 )
				 {
					JOptionPane.showMessageDialog(null, 
							"\nPlease insert a deposit envelope containing",
							"Deposit Information",JOptionPane.INFORMATION_MESSAGE);
							}
				currentTransaction.execute();
				BankDatabase bankDatabase = currentTransaction.getBankDatabase(); 
				bankDatabase.credit( currentTransaction.getAccountNumber(), ipt );
		
				 
			
			}
		});
		Withdraw.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Withdrawal currentTransaction=ATM.createWithdrawal();
				currentTransaction.execute();
				
			}
		});
		Cancel.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
		
		
		
		
		
	}
	
}
