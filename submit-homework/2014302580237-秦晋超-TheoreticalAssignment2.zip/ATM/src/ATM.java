
public class ATM {
	private boolean userAuthenticated; // whether user is authenticated
	private int currentAccountNumber; // current user's account number
	private Screen screen; // ATM's screen
	private Keypad keypad; // ATM's keypad
	private CashDispenser cashDispenser; // ATM's cash dispenser
	private DepositSlot depositSlot; // ATM's deposit slot
	private BankDatabase bankDatabase; // account information database
	// constants corresponding to main menu options
	private static final int BALANCE_INQUIRY = 1;
	private static final int WITHDRAWAL = 2;
	private static final int DEPOSIT = 3;
	private static final int EXIT = 4;
	
	 // no-argument ATM constructor initializes instance variables
	 public ATM()
	 {
	 userAuthenticated = false; // user is not authenticated to start
	 currentAccountNumber = 0; // no current account number to start
	 screen = new Screen(); // create screen
	 keypad = new Keypad(); // create keypad
	 cashDispenser = new CashDispenser(); // create cash dispenser
	 depositSlot = new DepositSlot(); // create deposit slot
	 bankDatabase = new BankDatabase(); // create act info database
	  } // end no-argument ATM constructor
	 // start ATM
	/*public void run()
	  {
	  // welcome and authenticate user; perform transactions
	  while ( true )
	  {
	  // loop while user is not yet authenticated
	  while ( !userAuthenticated )
	  {
	  screen.displayMessageLine("\nWelcome");
	  authenticateUser(); // authenticate user
	  
	  } // end while
	 
	  performTransactions(); // user is now authenticated
	  userAuthenticated = false; // reset before next ATM session
	  currentAccountNumber = 0; // reset before next ATM session
	 screen.displayMessageLine( "\nThank you! Goodbye!" );
	  } // end while
	  } // end method run
	 
	  // attempts to authenticate user against database
	   
	   */
	  public boolean authenticateUser(int accountNumber, int pin)
	  {
		  userAuthenticated =
				  bankDatabase.authenticateUser( accountNumber, pin );
	 
	  // check whether authentication succeeded
	  if ( userAuthenticated )
	 {
	
	  currentAccountNumber = accountNumber; 
	  return true;// save user's account #
	  } // end if
	  else{
	  //screen.displayMessageLine(
	  //"Invalid account number or PIN. Please try again." );
	  return false;
	  }
	  } // end method authenticateUser
	 
	  // display the main menu and perform transactions
	  
	
	 
	 public BalanceInquiry createBalanceInquiry(){
 
        	 BalanceInquiry temp = new BalanceInquiry( 
               currentAccountNumber,bankDatabase );
   
      return temp;
	 }
 	 public Withdrawal createWithdrawal()
 	   {
 	
 	       Withdrawal temp = new Withdrawal( currentAccountNumber,
 	        bankDatabase,cashDispenser );
 	          return temp; 
 	    } 
	 public Deposit createDeposit()
	   {
	
		 Deposit temp =new Deposit( currentAccountNumber, 
 	               bankDatabase, keypad, depositSlot );

	          return temp; 
	    } 

 	           
 	     
   } 
   













