import java.awt.AWTException;
import java.awt.Robot;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.awt.event.ActionEvent;

import javax.swing.JScrollPane;

public class GUI extends JFrame{
	private JPanel contentPane;
    private PrintStream ps;
    String input;
    boolean i=false;
    public ATM theATM;
    public Robot robot;
    
	/**
	 * @throws AWTException 
	 * @throws IOException 
	 */
	public static void main( String[] args ) throws AWTException, IOException{
		GUI newGUI =new GUI();
		newGUI.setVisible(true);
		newGUI.theATM.run();
	}
    
	/**
	 * @throws AWTException 
	 * @throws IOException 
	 */
	public GUI() throws AWTException, IOException{
		setTitle("ATM");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 520, 460);
		theATM = new ATM();
		File file =new File("temp.txt");
		System.setIn(new FileInputStream(file));
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 484, 168);
		contentPane.add(scrollPane);
		JTextArea txtrScreen = new JTextArea();
		scrollPane.setViewportView(txtrScreen);
		txtrScreen.setEditable(false);
		
		ps = new PrintStream(System.out){
		     public void println(String x){
		        txtrScreen.append(x + "\n");
		        txtrScreen.setCaretPosition(txtrScreen.getText().length());
		        }
		     public void print(String x){
		    	txtrScreen.append(x);
		        txtrScreen.setCaretPosition(txtrScreen.getText().length());
		        }
		      
		     public void print(double x){
		    	txtrScreen.append(String.valueOf(x));
		        txtrScreen.setCaretPosition(txtrScreen.getText().length());
		        }
		     };
		System.setOut(ps);
		
		JButton btn1 = new JButton("1");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i==false){	
					input="1";
					i=true;
					 txtrScreen.append("1");
					return;
				}
				if(i==true){
					input=input+"1";
				}
				 txtrScreen.append("1");
			}
		});

		JButton btn2 = new JButton("2");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i==false){	
					input="2";
					i=true;
					 txtrScreen.append("2");
					return;
				}
				if(i==true){
					input=input+"2";
				}
				 txtrScreen.append("2");
			}
		});

		JButton btn3 = new JButton("3");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i==false){	
					input="3";
					i=true;
					 txtrScreen.append("3");
					return;
				}
				if(i==true){
					input=input+"3";
				}
				 txtrScreen.append("3");
			}
		});
		
		JButton btn4 = new JButton("4");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i==false){	
					input="4";
					i=true;
					 txtrScreen.append("4");
					return;
				}
				if(i==true){
					input=input+"4";
				}
				 txtrScreen.append("4");
			}
		});
		
		JButton btn5 = new JButton("5");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i==false){	
					input="5";
					i=true;
					 txtrScreen.append("5");
					return;
				}
				if(i==true){
					input=input+"5";
				}
				 txtrScreen.append("5");
			}
		});
		
		JButton btn6 = new JButton("6");
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i==false){	
					input="6";
					i=true;
					 txtrScreen.append("6");
					return;
				}
				if(i==true){
					input=input+"6";
				}
				 txtrScreen.append("6");
			}
		});

		JButton btn7 = new JButton("7");
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i==false){	
					input="7";
					i=true;
					 txtrScreen.append("7");
					return;
				}
				if(i==true){
					input=input+"7";
				}
				 txtrScreen.append("7");
			}
		});
		
		JButton btn8 = new JButton("8");
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i==false){	
					input="8";
					i=true;
					 txtrScreen.append("8");
					return;
				}
				if(i==true){
					input=input+"8";
				}
				 txtrScreen.append("8");
			}
		});
		
		JButton btn9 = new JButton("9");
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i==false){	
					input="9";
					i=true;
					 txtrScreen.append("9");
					return;
				}
				if(i==true){
					input=input+"9";
				}
				 txtrScreen.append("9");
			}
		});
		
		JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i==false){	
					input="0";
					i=true;
					 txtrScreen.append("0");
					return;
				}
				if(i==true){
					input=input+"0";
				}
				 txtrScreen.append("0");
			}
		});
		
		JButton btnEnter = new JButton("ENTER");
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					theATM.keypad.num=Integer.parseInt(input);
					theATM.keypad.flag=true;
					input="";
			}
		});
		
		JTextArea txtrTakeCashHere = new JTextArea();
		txtrTakeCashHere.setText("Take cash here");
		txtrTakeCashHere.setEditable(false);
		
		JTextArea txtrInsert = new JTextArea();
		txtrInsert.setText("Insert  deposit envelope here");
		txtrInsert.setEditable(false);
		
		btn1.setBounds(10, 200, 50, 50);
		contentPane.add(btn1);
		
		btn2.setBounds(65, 200, 50, 50);
		contentPane.add(btn2);
		
		btn3.setBounds(120, 200, 50, 50);
		contentPane.add(btn3);
		
		btn4.setBounds(10, 255, 50, 50);
		contentPane.add(btn4);
		
		btn5.setBounds(65, 255, 50, 50);
		contentPane.add(btn5);
		
		btn6.setBounds(120, 255, 50, 50);
		contentPane.add(btn6);
		
		btn7.setBounds(10, 310, 50, 50);
		contentPane.add(btn7);
		
		btn8.setBounds(65, 310, 50, 50);
		contentPane.add(btn8);
		
		btn9.setBounds(120, 310, 50, 50);
		contentPane.add(btn9);
		
		btn0.setBounds(10, 365, 50, 50);
		contentPane.add(btn0);
		
		btnEnter.setBounds(65, 365, 105, 50);
		contentPane.add(btnEnter);
		
		txtrTakeCashHere.setBounds(207, 200, 267, 47);
		contentPane.add(txtrTakeCashHere);
		
		txtrInsert.setBounds(207, 310, 267, 55);
		contentPane.add(txtrInsert);
	}
	

}
