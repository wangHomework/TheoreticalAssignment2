import javax.swing.*;

public class Keypad {
    private int num;
    private JTextArea input;


    Keypad(JTextArea input_)
    {
        input = input_;
    }

    public void input(int inputNum)
    {
        num = num * 10 + inputNum;
        input.setText(String.format("%d", num));
    }

    public void back()
    {
        num = num / 10;
        input.setText(String.format("%d", num));
    }

    // return an integer value entered by user
    public int getInput() throws InterruptedException {
        synchronized(this)
        {
            wait();
        }
        int tmp = num;
        num = 0;
        input.setText("");
        return tmp;
    } // end method getInput
}