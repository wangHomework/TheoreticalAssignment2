
// Represents the screen of the ATM

import javax.swing.*;
import java.awt.*;

public class Screen{

    private JTextArea output;

    Screen(JTextArea output_)
    {
        output = output_;
        output.setText("");
    }

    // display a message without a carriage return
    public void displayMessage(String message) {
        output.append(message);
        output.setCaretPosition(output.getText().length());
    } // end method displayMessage

    // display a message with a carriage return
    public void displayMessageLine(String message) {
        output.append(String.format("%s\n", message));
        output.setCaretPosition(output.getText().length());
    } // end method displayMessageLine

    public void clear()
    {
        output.setText("");
    }

    // displays a dollar amount
    public void displayDollarAmount(double amount) {
        output.append(String.format("$%,.2f", amount));
        output.setCaretPosition(output.getText().length());
    } // end method displayDollarAmount
} // end class Screen