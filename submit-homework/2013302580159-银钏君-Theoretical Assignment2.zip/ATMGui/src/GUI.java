import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by fuxiuyin on 15-11-1.
 */
public class GUI extends JFrame {
    private JTextArea input;
    private JTextArea output;
    private Container contentPane;
    private Keypad keypad;
    private ATM atm;

    GUI()
    {
        super("ATM");
        setSize(640, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
        contentPane = getContentPane();
        contentPane.setLayout(null);
        initInput();
        initOutput();
        mainWindows();
    }

    private void initInput()
    {
        input = new JTextArea();
        input.setBackground(new Color(0x51BA3B));
        input.setForeground(new Color(0, 0, 0));
        input.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        input.setOpaque(true);
        input.setEditable(false);
        input.setBounds(250, 460, 350, 20);
    }

    private void initOutput()
    {
        output = new JTextArea();
        output.setBackground(new Color(0x51BA3B));
        output.setForeground(new Color(0, 0, 0));
        output.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        output.setLineWrap(true);
        output.setOpaque(true);
        output.setEditable(false);
    }

    private void mainWindows()
    {
        contentPane.removeAll();
        JScrollPane panel = new JScrollPane(output,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        panel.setBounds(250, 50, 350, 400);

        contentPane.add(input);
        contentPane.add(panel);
        contentPane.revalidate();
        contentPane.repaint();
        Screen screen = new Screen(output);
        keypad = new Keypad(input);
        atm = new ATM(screen, keypad);
        atm.start();
        setButton();
    }

    private void setButton()
    {
        JButton[] buttons = new JButton[12];
        int y = 250;
        int x = 50;
        for (int i = 0; i < 12; i++)
        {
            buttons[i] = new JButton();
            buttons[i].setBounds(x, y, 50, 50);
            if (i % 3 == 2)
            {
                y += 60;
                x = 50;
            }
            else
            {
                x += 60;
            }
            if (i == 10)
            {
                buttons[i].setText("ok");
                buttons[i].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        synchronized (keypad) {
                            keypad.notify();
                        }
                    }
                });
            }
            else if (i == 11)
            {
                buttons[i].setText("bs");
                buttons[i].addActionListener(e -> keypad.back());
            }
            else
            {
                Integer tmp = i;
                buttons[i].setText(tmp.toString());

                final int finalI = i;
                buttons[i].addActionListener(e -> keypad.input(finalI));
            }
            contentPane.add(buttons[i]);
        }
        contentPane.repaint();

    }
}
