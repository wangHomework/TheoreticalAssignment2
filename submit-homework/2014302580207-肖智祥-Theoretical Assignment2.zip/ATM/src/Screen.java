import java.awt.*;

import javax.swing.*;
import javax.swing.border.BevelBorder;

// Screen.java
// Represents the screen of the ATM

public class Screen extends JPanel
{
   public int nextInput=1;
   public int choice=1;
   private JLabel labelAccountNum=new JLabel("");
   private JLabel labelPinNum = new JLabel("");
   private JLabel input3=new JLabel();
   private JLabel input4=new JLabel();
   private JLabel input5=new JLabel();
   
   public Screen(){
	   this.screenAccount();
   }
   public void setLabelAccountNum(String a)
   {
	   labelAccountNum.setText(a);
   }
   public String getLabelAccountNum(){
	   return labelAccountNum.getText();
   }
   public void setLabelPinNum(String a)
   {
	   labelPinNum.setText(a);
   }
   public String getLabelPinNum(){
	   return labelPinNum.getText();
   }
   public void setInput3(String a){
	   input3.setText(a);
   }
   public String getInput3(){
	   return input3.getText();
   }
   public void setInput4(String a){
	   input4.setText(a);
   }
   public String getInput4(){
	   return input4.getText();
   }
   public void setInput5(String a){
	   input5.setText(a);
   }
   public String getInput5(){
	   return input5.getText();
   }
  
private void screenAccount()
   {//�˺��������
	   removeAll();
	   this.setLayout(new GridLayout(2,2,5,5));
	   this.setSize(600, 300);
	   JLabel labelAccount = new JLabel("                  Account number:   ");
	   labelAccount.setBackground(new Color(200,200,250));
	   labelAccount.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
	   labelAccount.setOpaque(true);
	   JLabel labelPin = new JLabel("                           PIN:  ");
	   labelPin.setBackground(new Color(200,200,250));
	   labelPin.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
	   labelPin.setOpaque(true);
	   this.add(labelAccount);
	   labelAccountNum.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
	   this.add(labelAccountNum);
	   labelPin.setOpaque(true);
	   this.add(labelPin);
	   labelPinNum.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
	   this.add(labelPinNum);
	   
   }
   public void change(int i){
       switch(i){
           case 1:screenAccount();break;
           case 2:Screen2();break;
           case 3:Screen3();break;
           case 4:Screen4();break;
           default:break;
       }
       choice=i;
   }
   private void Screen2(){
       removeAll();
       setLayout(new GridLayout(6,1,0,5));
       JLabel label1=new JLabel("Main Menu");
       JLabel label2=new JLabel("         1-View my balance");
       JLabel label3=new JLabel("         2-Withdraw cash");
       JLabel label4=new JLabel("         3-Deposit funds");
       JLabel label5=new JLabel("         4-Exit");
       JLabel label6=new JLabel("Enter a choice:");
       JPanel panel=new JPanel();
       panel.setLayout(new GridLayout(1,2,5,0));
       panel.add(label6);
       panel.add(input3);
       add(label1);
       add(label2);
       add(label3);
       add(label4);
       add(label5);
       add(panel);
       setVisible(false);
       setVisible(true);
   }
   private void Screen3(){
       removeAll();
       setLayout(new GridLayout(3,1,0,5));
       JPanel panel1=new JPanel();
       JPanel panel2=new JPanel();
       panel1.setLayout(new GridLayout(3,2,0,5));
       panel2.setLayout(new GridLayout(1,2,5,0));
       JLabel label1=new JLabel("Withdrawal menu");
       JLabel label2=new JLabel("               1 - $20");
       JLabel label3=new JLabel("               4 - $100");
       JLabel label4=new JLabel("               2 - $40");
       JLabel label5=new JLabel("               5 - $200");
       JLabel label6=new JLabel("               3 - $60");
       JLabel label7=new JLabel("               6 - Cancel transaction");
       JLabel label8=new JLabel("Choose a withdrawal amount:");
       panel1.add(label2);
       panel1.add(label3);
       panel1.add(label4);
       panel1.add(label5);
       panel1.add(label6);
       panel1.add(label7);
       panel2.add(label8);
       panel2.add(input4);
       add(label1);
       add(panel1);
       add(panel2);
       setVisible(false);
       setVisible(true);
   }
   private void Screen4(){
       removeAll();
       JLabel label1=new JLabel("����Ҫ��ȡ������:\n(��������������Ǯ��");
       setLayout(new GridLayout(2,1,0,5));
       add(label1);
       add(input5);
       setVisible(false);
       setVisible(true);
   }
   public void Screen5( Client client){
       removeAll();
       add(new JLabel("�������ǣ� "+client.getMoney()));
       setVisible(false);
       setVisible(true);
       choice = 5;
   }
} // end class Screen


