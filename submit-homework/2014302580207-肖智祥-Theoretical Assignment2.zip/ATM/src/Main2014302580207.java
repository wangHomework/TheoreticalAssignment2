public class Main2014302580207 
{
    public static void main(String args[])
    {
    	new Frame();
    	
    }
}
