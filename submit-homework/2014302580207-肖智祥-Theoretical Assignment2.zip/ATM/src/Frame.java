// Keypad.java
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;




// Represents the keypad of the ATM
import javax.swing.*;

public class Frame extends JFrame
{
	private Client client=new Client();
    private Screen screen=new Screen();
    private CashDispenser cashDispenser=new CashDispenser();
    private DepositSlot depositSlot=new DepositSlot();
    private keypadPanel keypadPanel=new keypadPanel();
	public Frame()
	{
		client.setClient("123", "123", 1000);
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		this.setLocation(250, 200);
		this.setSize(600,400);
		this.setLayout(new GridLayout(2,1,0,5));
		this.add(screen);
		JPanel panelCash=new JPanel();
		JPanel panelDown=new JPanel();
		panelCash.setLayout(new GridLayout(2,1,0,5));
		panelDown.setLayout(new GridLayout(1,2,5,0));
		panelCash.add(cashDispenser);
		panelCash.add(depositSlot);
		panelDown.add(keypadPanel);
		panelDown.add(panelCash);
		this.add(panelDown);
		this.setTitle("ATM Test Account number and password both are 123");
		
	}
	class keypadPanel extends JPanel
	{
		public keypadPanel(){
			showKeypad();
		}
		private void showKeypad(){
			this.setLayout(new GridLayout(4,3,5,5));
			JButton button0 = new JButton("0");
			JButton button1 = new JButton("1");
			JButton button2 = new JButton("2");
			JButton button3 = new JButton("3");
			JButton button4 = new JButton("4");
			JButton button5 = new JButton("5");
			JButton button6 = new JButton("6");
			JButton button7 = new JButton("7");
			JButton button8 = new JButton("8");
			JButton button9 = new JButton("9");
			JButton buttonBack = new JButton("Back");
			JButton buttonEnter = new JButton("Enter");	
            this.add(button1);
            this.add(button2);
            this.add(button3);
			this.add(button4);
			this.add(button5);
			this.add(button6);
			this.add(button7);
			this.add(button8);
			this.add(button9);
			this.add(buttonBack);
			this.add(button0);
			this.add(buttonEnter);
			setListener(button1, "1");
			setListener(button2, "2");
			setListener(button3, "3");
			setListener(button4, "4");
			setListener(button5, "5");
			setListener(button6, "6");
			setListener(button7, "7");
			setListener(button8, "8");
			setListener(button9, "9");
			setListener(button0, "0");
			setSureButton(buttonEnter);
			setBackButton(buttonBack);
		}
		private void setListener(JButton a,String number){
			a.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) 
	            {
	            	switch(screen.choice){
	            	case 1:
	            		if(screen.nextInput==1){
	            			screen.setLabelAccountNum(screen.getLabelAccountNum()+number);
	            		}
	            		if(screen.nextInput==2){
	            			screen.setLabelPinNum(screen.getLabelPinNum()+number);
	            		}
	            		break;
	            	case 2:
	            		if(Integer.parseInt(number)<5)
	            			screen.setInput3(number);
	            		break;
	            	case 3:
	            		if(Integer.parseInt(number)<7)
	            			screen.setInput4(number);
	            		break;
	            	case 4:screen.setInput5(screen.getInput5()+number);break;
	                default:break;
	            	}
	            }
			});
		}
		private void setSureButton(JButton a){
			a.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) 
	            {
	            	if(screen.choice==1){
	            		if(screen.nextInput==1){
	            			screen.nextInput=2;
	            		}
	            		else{
	            			if(client.checkAccount(screen.getLabelAccountNum())){
	            				if(client.checkPassword(screen.getLabelPinNum())){
	            					screen.change(2);
	            					screen.setLabelPinNum("");
	            					screen.setLabelAccountNum("");
	            					screen.nextInput=1;
	            				}
	            				else{
	            					JOptionPane.showMessageDialog(null, "password error"
											,"ERROR",JOptionPane.ERROR_MESSAGE);
	            					screen.setLabelPinNum("");
	            				}
	            			}
	            			else{
	            				JOptionPane.showMessageDialog(null, "accountNumber error"
										,"ERROR",JOptionPane.ERROR_MESSAGE);
	            				screen.setLabelPinNum("");
            					screen.setLabelAccountNum("");
	            				screen.nextInput=1;
	            			}
	            		}
	            	}
	            	if(screen.choice==2){
	            		switch (screen.getInput3())
	            		{
	            		case "1":screen.Screen5(client);break;
	            		case "2":screen.change(3);break;
	            		case "3":screen.change(4);break;
	            		case "4":System.exit(0);break;
	            		default :
	            			JOptionPane.showMessageDialog(null, "Chose a number between 1 to 4!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            				break;
	            		}
	            	}
	            	
	            	if(screen.choice==3){
	            		//Withdrawal
	            		switch (screen.getInput4()){
	            		case "1":
	            			client.drawMoney(20);
	            			JOptionPane.showMessageDialog(null, "You draw $20 successfully! Take it!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            			screen.change(2);
	            			break;
	            		case "2":
	            			client.drawMoney(40);
	            			JOptionPane.showMessageDialog(null, "You draw $40 successfully! Take it!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            			screen.change(2);
	            			break;
	            		case "3":
	            			client.drawMoney(60);
	            			JOptionPane.showMessageDialog(null, "You draw $60 successfully! Take it!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            			screen.change(2);
	            			break;
	            		case "4":
	            			client.drawMoney(100);
	            			JOptionPane.showMessageDialog(null, "You draw $100 successfully! Take it!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            			screen.change(2);
	            			break;
	            		case "5":
	            			client.drawMoney(200);
	            			JOptionPane.showMessageDialog(null, "You draw $200 successfully! Take it!"
									,"Good",JOptionPane.INFORMATION_MESSAGE);
	            			screen.change(2);
	            			break;
	            		case "6":
	            			screen.change(2);
	            			break;
	            		default :break;
	            		}
	            		screen.setInput3("");
	            		screen.setInput4("");
	            	}
	            	if(screen.choice==4){
	            		//deposit
	            		client.deposit(Double.valueOf(screen.getInput5()));
	            		JOptionPane.showMessageDialog(null, "You can deposit your money now!"
								,"Nice",JOptionPane.INFORMATION_MESSAGE);
	            		screen.change(2);
            			screen.setInput3("");
            			screen.setInput5("");
	            	}
	            	if(screen.choice==5)
	            	{
	            		screen.change(2);
	            		screen.setInput3("");
	            	}
	            }
		    });
		}
		private void setBackButton(JButton a){
			a.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) 
	            {
	            	switch (screen.choice)
	            	{
	            	case 1:
	            		screen.setLabelPinNum("");
    					screen.setLabelAccountNum("");
    					screen.nextInput=1;
    					break;
	            	case 2:
	            		screen.setInput3("");break;
	            	case 3:
	            		screen.setInput4("");break;
	            	case 4:
	            		screen.setInput5("");break;
	            	case 5:
	            		screen.change(2);
	            		screen.setInput3("");
	            		break;
	            	default : break;
	            	}
	            }
		    });
		}
	}
    
} 



