import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad
 {
 private String input=""; // reads data from the command line
 private static Boolean hasInput = false; 
// no-argument constructor initializes the Scanner
 public Keypad()
 {
 
 } // end no-argument Keypad constructor
public void setInput(String keyEnterInput){
	this.input = keyEnterInput;
}
 // return an integer value entered by user
 public int getInput()
 {
	 if(input!=""){
		 hasInput = true;
	 }else{
		 hasInput = false;
	 }
	 synchronized (hasInput) {
		   //��������߳�Ϊfalse����ִ��ѭ��
		while (hasInput == false) {
			synchronized (hasInput) {};
		}
	 }
	 String last = input;
	 hasInput = false;
	 input = "";
	 return Integer.parseInt(last);
 } // end method getInput
 
 public void sethasInput(){
	 hasInput = true;
 }
 
 
 }