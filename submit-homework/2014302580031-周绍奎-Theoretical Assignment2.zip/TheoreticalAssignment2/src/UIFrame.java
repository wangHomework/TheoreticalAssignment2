


import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;


public class UIFrame extends JFrame {

	public JTextArea textarea = null;
	private PrintStream printstream = null;
	private ATM ATM = null;
	private String keyEnterInput = "";
	private JButton button_1 = null;
	private JButton button_2 = null;
	private JButton button_3 = null;
	private JButton button_4 = null;
	private JButton button_5 = null;
	private JButton button_6 = null;
	private JButton button_7 = null;
	private JButton button_8 = null;
	private JButton button_9 = null;
	private JButton button_0 = null;
	private JMenuBar bar = null;
	private JButton btnEnter = null;
	
	
	public UIFrame() {
		ATM = new ATM();
		this.getContentPane().setLayout(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(100, 100, 432, 376);
		this.setTitle("UIFrame");
		this.setVisible(true);
		createBtn();
		addListener();
		
	}
	
	public void createBtn(){
		button_1 = new JButton("1");
		button_1.setBounds(0, 114, 56, 56);
		this.getContentPane().add(button_1);
		
		button_4 = new JButton("4");
		button_4.setBounds(0, 170, 56, 56);
		this.getContentPane().add(button_4);
		
		button_7 = new JButton("7");
		button_7.setBounds(0, 223, 56, 56);
		this.getContentPane().add(button_7);
		
		button_8 = new JButton("8");
		button_8.setBounds(56, 223, 56, 56);
		this.getContentPane().add(button_8);
		
		button_5 = new JButton("5");
		button_5.setBounds(56, 170, 56, 56);
		this.getContentPane().add(button_5);
		
		button_2 = new JButton("2");
		button_2.setBounds(56, 114, 56, 56);
		this.getContentPane().add(button_2);
		
		button_9 = new JButton("9");
		button_9.setBounds(113, 223, 56, 56);
		this.getContentPane().add(button_9);
		
		button_6 = new JButton("6");
		button_6.setBounds(113, 170, 56, 56);
		this.getContentPane().add(button_6);
		
		button_3 = new JButton("3");
		button_3.setBounds(113, 114, 56, 56);
		this.getContentPane().add(button_3);
		
		button_0 = new JButton("0");
		button_0.setBounds(0, 281, 56, 56);
		this.getContentPane().add(button_0);
		
		btnEnter = new JButton("Enter");
		btnEnter.setBounds(56, 281, 113, 56);
		this.getContentPane().add(btnEnter);
		
//		button_start = new JButton("����");
//		button_start.setBounds(231, 170, 136, 109);
//		this.getContentPane().add(button_start);
		
		textarea = new JTextArea();
		JScrollPane scroll = new JScrollPane(textarea);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		textarea.setAutoscrolls(true);
		textarea.setLineWrap(true);
		
		scroll.setBounds(0, 0, 416, 118);
		textarea.setRows(5);
		this.setJMenuBar(bar);
		this.getContentPane().add(scroll);
		
		
//		button_start.addActionListener(new ActionListener(){
//
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				// TODO Auto-generated method stub
//				
//			}
//			
//		});
	}
	
	public void redirectStream(){
		printstream = new PrintStream(System.out){
			public void println(String str){
				textarea.setText(textarea.getText()+str+"\n");
			}
			public void print(String str){
				textarea.setText(textarea.getText()+str);
			}
			public void print(double str){
				textarea.setText(textarea.getText()+Double.toString(str)+"\n");
			}
		};
		System.setOut(printstream);
		ATM.run();
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					UIFrame frame = new UIFrame();
					frame.redirectStream();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private void addListener(){
		button_1.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.print(1+"");
				keyEnterInput = keyEnterInput+1+"";
			}
			
		});
		button_0.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.print(0+"");
				keyEnterInput = keyEnterInput+"0";
			}
			
		});
		button_2.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.print(2+"");
				keyEnterInput = keyEnterInput+"2";
			}
			
		});
		button_3.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.print(3+"");
				keyEnterInput = keyEnterInput+"3";
			}
			
		});
		button_4.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.print(4+"");
				keyEnterInput = keyEnterInput+"4";
			}
			
		});
		button_5.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.print(5+"");
				keyEnterInput = keyEnterInput+"5";
			}
			
		});
		button_6.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.print(6+"");
				keyEnterInput = keyEnterInput+"6";
			}
			
		});
		button_7.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.print(7+"");
				keyEnterInput = keyEnterInput+"7";
			}
			
		});
		button_8.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.print(8+"");
				keyEnterInput = keyEnterInput+"8";
			}
			
		});
		button_9.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.out.print(9+"");
				keyEnterInput = keyEnterInput+"9";
			}
			
		});
		
		btnEnter.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(keyEnterInput==""){
					return;
				}
				else{
					System.out.println(keyEnterInput);
					ATM.keypad.setInput(keyEnterInput);
					ATM.keypad.sethasInput();
					keyEnterInput = "";
				}
			}
			
		});
	}
	
	
}
