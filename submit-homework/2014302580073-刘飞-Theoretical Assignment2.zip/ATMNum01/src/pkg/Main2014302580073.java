package pkg;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Font;

public class Main2014302580073 extends JFrame 
{

	private JPanel contentPane;
	static JTextArea textArea = new JTextArea();
	String input;
	public ATM atm;
	boolean ip=false;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args)throws AWTException, IOException 
	{
		/*EventQueue.invokeLater(new Runnable()
		{
			public void run() 
			{
				try 
				{
					
					Main2014302580073 frame = new Main2014302580073();
					frame.setVisible(true);
					ATM atm=new ATM();
					atm.run();
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});	*/
		Main2014302580073 frame = new Main2014302580073();
		frame.setVisible(true);
		frame.atm.run();
	}

	/**
	 * Create the frame.
	 */
	public Main2014302580073() {
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 328);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setBackground(Color.YELLOW);
		textArea.setEditable(false);
		textArea.setBounds(0, 0, 434, 97);
		JScrollPane scrollpane=new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		contentPane.add(textArea);
		atm=new ATM();
		JButton btnNewButton = new JButton("1");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textArea.setText(textArea.getText()+"1");
				if(ip==false){
					input="2";
					ip=true;
					return;
				}
				if(ip==true){
				input=input+"1";
				}
			}
		});
		btnNewButton.setBounds(0, 107, 50, 38);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textArea.setText(textArea.getText()+"2");
				if(ip==false){
					input="2";
					ip=true;
					return;
				}
				if(ip==true){
					input=input+"2";
				}
			}
		});
		btnNewButton_1.setBounds(62, 107, 50, 38);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("3");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textArea.setText(textArea.getText()+"3");
				if(ip==false){
					input="3";
					ip=true;
					return;
				}
				if(ip==true){
					input=input+"3";
				}
			}
		});
		btnNewButton_2.setBounds(122, 107, 50, 38);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("4");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textArea.setText(textArea.getText()+"4");
				if(ip==false){
					input="4";
					ip=true;
					return;
				}
				if(ip==true){
					input=input+"4";
				}
			}
		});
		btnNewButton_3.setBounds(0, 155, 49, 38);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("5");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				textArea.setText(textArea.getText()+"5");
				if(ip==false){
					input="5";
					ip=true;
					return;
				}
				if(ip==true){
					input=input+"5";
				}
			}
		});
		btnNewButton_4.setBounds(62, 155, 49, 38);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("6");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textArea.setText(textArea.getText()+"6");
				if(ip==false){
					input="6";
					ip=true;
					return;
				}
				if(ip==true){
					input=input+"6";
				}
			}
		});
		btnNewButton_5.setBounds(122, 155, 49, 38);
		contentPane.add(btnNewButton_5);
		
		JButton button = new JButton("7");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				textArea.setText(textArea.getText()+"7");
				if(ip==false){
					input="7";
					ip=true;
					return;
				}
				if(ip==true){
					input=input+"7";
				}
			}
		});
		button.setBounds(0, 203, 50, 38);
		contentPane.add(button);
		
		JButton button_1 = new JButton("8");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				textArea.setText(textArea.getText()+"8");
				if(ip==false){
					input="8";
					ip=true;
					return;
				}
				if(ip==true){
					input=input+"8";
				}
			}
		});
		button_1.setBounds(62, 203, 50, 38);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("9");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textArea.setText(textArea.getText()+"9");
				if(ip==false){
					input="9";
					ip=true;
					return;
				}
				if(ip==true){
					input=input+"9";
				}
			}
		});
		button_2.setBounds(122, 203, 50, 38);
		contentPane.add(button_2);
		
		JButton btnNewButton_6 = new JButton("0");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				textArea.setText(textArea.getText()+"0");
				if(ip==false){
					input="0";
					ip=true;
					return;
				}
				if(ip==true){
					input=input+"0";
				}
			}
		});
		btnNewButton_6.setBounds(0, 251, 50, 38);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Enter");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				atm.keypad.num=Integer.parseInt(input);
				atm.keypad.b=true;
				input="";
			}
		});
		btnNewButton_7.setBounds(62, 251, 110, 38);
		contentPane.add(btnNewButton_7);
		
		JButton btnTakeCachHere = new JButton("Take cach here");
		btnTakeCachHere.setBounds(182, 107, 242, 86);
		contentPane.add(btnTakeCachHere);
		
		JButton btnNewButton_8 = new JButton("Insert deposit envelope here ");
		btnNewButton_8.setBounds(182, 203, 242, 86);
		contentPane.add(btnNewButton_8);
		
	}
}
