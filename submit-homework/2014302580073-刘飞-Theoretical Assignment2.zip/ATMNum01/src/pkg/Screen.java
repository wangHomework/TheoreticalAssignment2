package pkg;
public class Screen
{ 
	public Main2014302580073 Main2014302580073;
	// display a message without a carriage return 
	public void displayMessage( String message ) 
	{
		//System.out.printf(message );
		String temp=Main2014302580073.textArea.getText();
		Main2014302580073.textArea.setText(temp+message);
	} // end method displayMessage 
	// display a message with a carriage return 
	public void displayMessageLine( String message )
	{ 
		//System.out.printf(message );
		String temp=Main2014302580073.textArea.getText();
		Main2014302580073.textArea.setText(temp+"\n"+message);
	} // end method displayMessageLine 
	// displays a dollar amount 
	public void displayDollarAmount( double amount )
	{ 
		//System.out.printf( "$%,.2f", amount );
		String temp=Main2014302580073.textArea.getText();
		Main2014302580073.textArea.setText(temp+amount);
		
	} // end method displayDollarAmount
}// end class Screen

