
public abstract class Transaction {
	private int accountNumber;
	private Screen screen;
	private BankDataBase bankDataBase;
	
	public Transaction(int userAccountNumber,BankDataBase atmBankDataBase){
		accountNumber = userAccountNumber;
		//screen = atmScreen;
		bankDataBase = atmBankDataBase;
	}
	
	public int getAccountNumber(){
		return accountNumber;
	}
	
	public Screen getScreen(){
		return screen;
	}
	
	public BankDataBase getBankDataBase(){
		return bankDataBase;
	}
	
	abstract public void execute();
}
