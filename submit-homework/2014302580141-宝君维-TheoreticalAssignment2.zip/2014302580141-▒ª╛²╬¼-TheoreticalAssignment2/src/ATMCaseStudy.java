
public class ATMCaseStudy  {

	public static void ATM() {
		// TODO Auto-generated method stub
		ATM myATM = new ATM();	
		myATM.run();
	}

}
