
public class Withdrawal extends Transaction{
	
	private double amount;
	private Keypad keypad;
	private CashDispenser cashDispenser;
	
	private final static int CANCELLED = 6; 
	
	public Withdrawal(int userAccountNumber, Screen atmScreen,
			BankDataBase atmBankDataBase,Keypad atmKeypad,CashDispenser atmCashDispenser) {
		super(userAccountNumber,atmBankDataBase);
		// TODO Auto-generated constructor stub
		keypad = atmKeypad;
		cashDispenser = atmCashDispenser;
	}
	
	@Override
	public void execute(){
		boolean cashDispensed = false;
		double availableBalance;
		
		BankDataBase bankDataBase = getBankDataBase();
		Screen screen = getScreen(); 
		
		do{
			amount = displayMenuOfAmount();
			
			if(amount!=CANCELLED){
				availableBalance = bankDataBase.getAvailableBalance(getAccountNumber());
				
				if(amount<=availableBalance){
					if(cashDispenser.isSufficientCashAvailable(amount)){
						bankDataBase.debit(getAccountNumber(), amount);
						
						cashDispenser.dispenserCash(amount);
						cashDispensed = true;
						
						screen.displayMessageLine("\nYour cash has been "+"dipensed.Please take your cash now.");
						
					}
					else{
						screen.displayMessageLine("\nInsufficient cash available in the ATM."+
					"\n\nPlease choose a smaller amount.");
					}
				}
				else{
					screen.displayMessageLine("\nInsufficient funds in your account."+
				"\n\nPlease choose a smaller amount");
				}
			}
			else{
				screen.displayMessageLine("\nCancelling transaction...");
				return;
			}
			
		}while(!cashDispensed);
	}
	
	private int displayMenuOfAmount(){
		int userChoice = 0;
		
		Screen screen = getScreen();
		
		int []amount = {0,20,40,60,100,200};
		
		while(userChoice==0){
			screen.displayMessageLine("\nWithdrawal Menu:");
			screen.displayMessageLine("1 - $20");
			screen.displayMessageLine("2 - $40");
			screen.displayMessageLine("3 - $60:");
			screen.displayMessageLine("4 - $100");
			screen.displayMessageLine("5 - $200");
			screen.displayMessageLine("6 - Cancel transaction");
			screen.displayMessage("\nChoose a withdrawal amount:");
			
			int input = keypad.getInput();
			
			switch(input){
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
				userChoice = amount[input];
				break;
			case CANCELLED:
				userChoice = CANCELLED;
				break;
			default:
				screen.displayMessageLine("\nInvalid selection.Try again.");	
			}
		}
		return userChoice;
	}
}
