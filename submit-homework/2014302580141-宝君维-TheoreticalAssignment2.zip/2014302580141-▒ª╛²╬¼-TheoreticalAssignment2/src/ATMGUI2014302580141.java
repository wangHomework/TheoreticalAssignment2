import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Component;
import java.awt.Window.Type;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;


public class ATMGUI2014302580141 extends JFrame {
	private JPanel contentPane;
	private BankDataBase bankDatabase = new BankDataBase();
	private JTextField textField;
	private JTextField textField_1;
	private JTextArea enterIsFalse;
	private JButton bBalance;
	private JButton bWithdrawal;
	private JButton bDeposit;
	private JButton bMainMenu;
	private JButton bBack;
	private JTextArea tADeposit;
	private JTextArea tABalance;
	private JTextArea tABalanceAmount;
	private JTextArea tAWithdrawal;
	private JButton bFetch;
	private JTextArea tAWait;
	private JTextField tFWithdrawal;
	private JTextArea tANotEnough;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ATMGUI2014302580141 frame = new ATMGUI2014302580141();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ATMGUI2014302580141() {
		setTitle("\u4E2D\u56FD\u94F6\u884C\u81EA\u52A9\u5B58\u53D6\u673A");
		setName("\u4E2D\u56FD\u94F6\u884CATM");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setForeground(Color.LIGHT_GRAY);
		contentPane.setAlignmentX(Component.LEFT_ALIGNMENT);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea txtratm = new JTextArea();
		txtratm.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		txtratm.setTabSize(11);
		txtratm.setText("\u6B22\u8FCE\u4F7F\u7528\u4E2D\u56FD\u94F6\u884CATM\u81EA\u52A8\u5B58\u53D6\u673A");
		txtratm.setBounds(75, 10, 309, 28);
		contentPane.add(txtratm);
		
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		textArea.setText("\u8BF7\u8F93\u5165\u8D26\u6237\u53F7\uFF1A");
		textArea.setBounds(156, 55, 150, 24);
		contentPane.add(textArea);
		
		textField = new JTextField();
		textField.setFont(new Font("������", Font.PLAIN, 18));
		textField.setBounds(156, 89, 116, 42);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JTextArea txtrpin = new JTextArea();
		txtrpin.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		txtrpin.setText("\u8BF7\u8F93\u5165PIN\uFF1A");
		txtrpin.setBounds(156, 141, 116, 28);
		contentPane.add(txtrpin);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("������", Font.PLAIN, 18));
		textField_1.setColumns(10);
		textField_1.setBounds(156, 179, 116, 42);
		contentPane.add(textField_1);
		
		JButton bInput = new JButton("\u786E\u8BA4");
		bInput.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String account = textField.getText();
				String pin = textField_1.getText();
				int accountInt = Integer.parseInt(account);
				int pinInt = Integer.parseInt(pin);
				if(bankDatabase.authenticateUser(accountInt, pinInt)){
					textArea.setVisible(false);
					txtrpin.setVisible(false);
					textField.setVisible(false);
					textField_1.setVisible(false);
					bInput.setVisible(false);
					bBalance.setVisible(true);
					bWithdrawal.setVisible(true);
					bDeposit.setVisible(true);
				}
				else{
					textArea.setVisible(false);
					txtrpin.setVisible(false);
					textField.setVisible(false);
					textField_1.setVisible(false);
					enterIsFalse.setVisible(true);
				}
		
				
				
			}
		});
		bInput.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		bInput.setBounds(291, 231, 93, 23);
		contentPane.add(bInput);
		
		enterIsFalse = new JTextArea();
		enterIsFalse.setVisible(false);
		enterIsFalse.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		enterIsFalse.setText("\u60A8\u7684\u8D26\u6237\u53F7\u6216PIN\u8F93\u5165\u6709\u8BEF\uFF0C\u8BF7\u91CD\u65B0\u8F93\u5165\uFF01");
		enterIsFalse.setBounds(60, 95, 341, 65);
		contentPane.add(enterIsFalse);
		
		bBalance = new JButton("\u67E5\u8BE2\u4F59\u989D");
		bBalance.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String account = textField.getText();
				int accountInt = Integer.parseInt(account);
				BalanceInquiry balance = new BalanceInquiry(accountInt,bankDatabase);
				String myBalance = balance.balance();
				tABalance.setVisible(true);
				tABalanceAmount.setText('$'+myBalance);
				
				bBack.setVisible(true);
				bBalance.setVisible(false);
				bWithdrawal.setVisible(false);
				bDeposit.setVisible(false);
			}
		});
		bBalance.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		bBalance.setVisible(false);
		bBalance.setBounds(156, 48, 150, 37);
		contentPane.add(bBalance);
		
		bWithdrawal = new JButton("\u6211\u8981\u53D6\u6B3E");
		bWithdrawal.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				bBack.setVisible(true);
				bBalance.setVisible(false);
				bWithdrawal.setVisible(false);
				bDeposit.setVisible(false);
				tAWithdrawal.setVisible(true);
				tFWithdrawal.setVisible(true);
				bFetch.setVisible(true);
				
			}
		});
		bWithdrawal.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		bWithdrawal.setVisible(false);
		bWithdrawal.setBounds(156, 110, 150, 42);
		contentPane.add(bWithdrawal);
		
		bDeposit = new JButton("\u6211\u8981\u5B58\u6B3E");
		bDeposit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				tADeposit.setVisible(true);
				bBalance.setVisible(false);
				bWithdrawal.setVisible(false);
				bDeposit.setVisible(false);
				bBack.setVisible(true);
			}
		});
		bDeposit.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		bDeposit.setVisible(false);
		bDeposit.setBounds(156, 179, 150, 42);
		contentPane.add(bDeposit);
		
		bMainMenu = new JButton("\u4E3B\u83DC\u5355");
		bMainMenu.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				textArea.setVisible(true);
				txtrpin.setVisible(true);
				textField.setVisible(true);
				textField_1.setVisible(true);
				bInput.setVisible(true);
				bBalance.setVisible(false);
				bWithdrawal.setVisible(false);
				bDeposit.setVisible(false);
				enterIsFalse.setVisible(false);
				
			}
		});
		bMainMenu.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		bMainMenu.setBounds(49, 231, 93, 23);
		contentPane.add(bMainMenu);
		
		bBack = new JButton("\u540E\u9000");
		bBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				tADeposit.setVisible(false);
				bBalance.setVisible(true);
				bWithdrawal.setVisible(true);
				bDeposit.setVisible(true);
				bBack.setVisible(false);
				tABalance.setVisible(false);
				tABalanceAmount.setVisible(false);
				tAWithdrawal.setVisible(false);
				tFWithdrawal.setVisible(false);
				bFetch.setVisible(false);
				tAWait.setVisible(false);
				tANotEnough.setVisible(false);
				
			}
		});
		bBack.setVisible(false);
		bBack.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		bBack.setBounds(49, 190, 93, 23);
		contentPane.add(bBack);
		
		tADeposit = new JTextArea();
		tADeposit.setVisible(false);
		tADeposit.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		tADeposit.setText("\u8BF7\u572830\u79D2\u5185\u5C06\u949E\u7968\u653E\u5165\u5B58\u6B3E\u69FD...");
		tADeposit.setBounds(75, 89, 320, 74);
		contentPane.add(tADeposit);
		
		tABalance = new JTextArea();
		tABalance.setVisible(false);
		tABalance.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		tABalance.setText("\u60A8\u7684\u8D26\u6237\u4F59\u989D\u4E3A\uFF1A");
		tABalance.setBounds(75, 60, 309, 40);
		contentPane.add(tABalance);
		
		tABalanceAmount = new JTextArea();
		tABalanceAmount.setBounds(75, 122, 225, 37);
		contentPane.add(tABalanceAmount);
		
		tAWithdrawal = new JTextArea();
		tAWithdrawal.setVisible(false);
		tAWithdrawal.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		tAWithdrawal.setText("\u8BF7\u8F93\u5165\u60A8\u8981\u53D6\u51FA\u7684\u91D1\u989D\uFF1A");
		tAWithdrawal.setBounds(75, 48, 309, 42);
		contentPane.add(tAWithdrawal);
		
		bFetch = new JButton("\u786E\u8BA4\u91D1\u989D");
		bFetch.setVisible(false);
		bFetch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String account = textField.getText();
				int accountInt = Integer.parseInt(account);
				BalanceInquiry balance = new BalanceInquiry(accountInt,bankDatabase);
				String myBalance = balance.balance();
				double dBalance = Double.parseDouble(myBalance);
				
				String sFetch = tFWithdrawal.getText();
				double dFetch = Double.valueOf(sFetch);
				if(dFetch<=dBalance){
					tAWait.setVisible(true);
					tAWithdrawal.setVisible(false);
					tFWithdrawal.setVisible(false);
				}
				else{
					tANotEnough.setVisible(true);
					tAWithdrawal.setVisible(false);
					tFWithdrawal.setVisible(false);
				}
			}
		});
		bFetch.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		bFetch.setBounds(291, 190, 110, 23);
		contentPane.add(bFetch);
		
		tAWait = new JTextArea();
		tAWait.setVisible(false);
		tAWait.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		tAWait.setText("\u7CFB\u7EDF\u6B63\u5728\u914D\u7F6E\uFF0C\u8BF7\u7A0D\u540E...");
		tAWait.setBounds(75, 60, 283, 52);
		contentPane.add(tAWait);
		
		tFWithdrawal = new JTextField();
		tFWithdrawal.setVisible(false);
		tFWithdrawal.setFont(new Font("������", Font.PLAIN, 18));
		tFWithdrawal.setColumns(10);
		tFWithdrawal.setBounds(156, 89, 116, 42);
		contentPane.add(tFWithdrawal);
		
		tANotEnough = new JTextArea();
		tANotEnough.setVisible(false);
		tANotEnough.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		tANotEnough.setText("\u60A8\u7684\u4F59\u989D\u4E0D\u8DB3\uFF0C\u8BF7\u91CD\u65B0\u8F93\u5165\u91D1\u989D\uFF01");
		tANotEnough.setBounds(75, 66, 310, 65);
		contentPane.add(tANotEnough);
	}
}
