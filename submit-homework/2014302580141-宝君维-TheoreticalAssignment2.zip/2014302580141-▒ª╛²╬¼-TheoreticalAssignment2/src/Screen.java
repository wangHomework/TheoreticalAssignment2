
public class Screen {
	
	private static String temp1;
	private static String temp2;
	
	public String displayMessage(String message){
		temp1 = message;
		return message;
	}
	

	public String displayMessageLine(String message){
		temp2 = message;
		return message;

	}
	
	public void displayDollarAmount(double amount){
		System.out.printf("$%,.2f",amount);

	}
	
	public static String get(){
		return temp1;
	}
	
	public static String getLine(){
		return temp2;
	}
}
