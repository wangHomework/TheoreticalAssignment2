
public class BalanceInquiry extends Transaction {
	public BalanceInquiry(int userAccountNumber,BankDataBase atmBankDataBase){
		super(userAccountNumber,atmBankDataBase);
	}
	
	@Override
	public void execute(){
		BankDataBase bankDataBase = getBankDataBase();
		Screen screen = getScreen();
		
		double availableBalance = bankDataBase.getAvailableBalance(getAccountNumber());
		double totalBalance = bankDataBase.getTotalBalance(getAccountNumber());
	
		
		screen.displayMessageLine("\nBalance Information:");
		screen.displayMessage("- Available balance:");
		screen.displayDollarAmount(availableBalance);
		screen.displayMessage("- Total banlance:");
		screen.displayDollarAmount(totalBalance);
		screen.displayMessageLine("");
	}
	
	public String balance(){
		BankDataBase bankDataBase = getBankDataBase();
		
		double availableBalance = bankDataBase.getAvailableBalance(getAccountNumber());
		
		String balance = String.valueOf(availableBalance);
		
		return balance;
	}
}
