import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;

@SuppressWarnings("serial")
public class MainFrame extends JFrame
{
	public JTextArea textArea = new JTextArea();
	private JScrollPane scrollPane = new JScrollPane(textArea);
	public ATM atm;
	public String input;
	private PrintStream output;
	private boolean m;
	private JButton btn0 = new JButton("0");
	private JButton btn1 = new JButton("1");
	private JButton btn2 = new JButton("2");
	private JButton btn3 = new JButton("3");
	private JButton btn4 = new JButton("4");
	private JButton btn5 = new JButton("5");
	private JButton btn6 = new JButton("6");
	private JButton btn7 = new JButton("7");
	private JButton btn8 = new JButton("8");
	private JButton btn9 = new JButton("9");
	private JButton btnEnter = new JButton("ok");
	private JButton btnDelete = new JButton("��");
	
	/*
	 * ��ȡǮ����
	 */
	private ImageIcon image1 = new ImageIcon("label1.png");
	private ImageIcon image2 = new ImageIcon("label2.png");
	private JLabel label1 = new JLabel(image1);
	private JLabel label2 = new JLabel(image2);
	
	/*
	 * ��ȡ����ֵ
	 */
	private void get_input(String i) {
		if (m==false) {
			input = i;
			m = true;
		}else {
			input = input + i;
		}
		//��JTextArea����ʾ����ֵ
		textArea.append(i);
	}
	
	public MainFrame()
	{
		super("ATM��̨��");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 450, 487);
		//�޸�Ĭ�ϲ���
		setLayout(null);
		
		atm = new ATM();
		
		//����JTextArea���ܱ��༭
	    textArea.setEditable(false);
	    textArea.setFont(new Font("Serif", Font.BOLD, 16)); // �޸�����ʹ�С
	    
	    /*
	     * ���ӹ�������������ˮƽ������Ҫ����ʾ����ֱ����һֱ��ʾ
	     */
		add(scrollPane);
		scrollPane.setBounds(0, 0, 437, 250);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		label1.setBounds(154, 252, 277, 98);add(label1);
		label2.setBounds(154, 352, 277, 98);add(label2);
		
		/*
		 * ����˵���Ϣ
		 */
		output = new PrintStream(System.out){
			public void println(String n) {
				textArea.append(n + '\n');
			}
			public void print(String n) {
				textArea.append(n);
			}
			public void println(double n) {
				textArea.append(String.valueOf(n));
			}
		};
		System.setOut(output);
	    
		/*
		 * ��ť����
		 */
		btn1.setBounds(0, 250, 50, 50);add(btn1);
		btn2.setBounds(50, 250, 50, 50);add(btn2);
		btn3.setBounds(100, 250, 50, 50);add(btn3);
		btn4.setBounds(0, 300, 50, 50);add(btn4);
		btn5.setBounds(50, 300, 50, 50);add(btn5);
		btn6.setBounds(100, 300, 50, 50);add(btn6);
		btn7.setBounds(0, 350, 50, 50);add(btn7);
		btn8.setBounds(50, 350, 50, 50);add(btn8);
		btn9.setBounds(100, 350, 50, 50);add(btn9);
		btn0.setBounds(0, 400, 50, 50);add(btn0);
		btnEnter.setBounds(50, 400, 50, 50);add(btnEnter);
		btnDelete.setBounds(100, 400, 50, 50);add(btnDelete);
		
		/*
		 * ��ť�¼�
		 */
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 get_input("0");
			}
		});
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 get_input("1");
			}
		});
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 get_input("2");
			}
		});
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 get_input("3");
			}
		});
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 get_input("4");
			}
		});
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 get_input("5");
			}
		});
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		     	 get_input("6");
			}
		});
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 get_input("7");
			}
		});
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				get_input("8");
			}
		});
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 get_input("9");
			}
		});
		
		/*
		 * ȷ�ϼ�
		 */
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*
				 * �ж��Ƿ�����ֵ����ȻInteger��parseInt("")�ᱨ��
				 */
				if (input.length() > 0) {
					atm.keypad.num = Integer.parseInt(input);
				    atm.keypad.p = true;
				    input = "";
				}
				 
			}
		});
		
		/*
		 * ���˼���ɾ�����һ������
		 */
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*
				 * �ж�����ֵ�Ƿ�Ϊ��
				 */
				if (input.length() > 0) {
				    input = input.substring(0, input.length() - 1);
					textArea.setText(textArea.getText().substring(0, textArea.getText().length() - 1)); 
				}
			}
		});
		
	}
}