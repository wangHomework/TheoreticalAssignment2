public class Keypad
 {
 public int num;
 public boolean p;
 public Keypad()
 {
 }

 public int getInput()
 {
	 p = false;
	 while (!p) {
		 System.out.print("");
	 }
	 return num;
 }
 }
