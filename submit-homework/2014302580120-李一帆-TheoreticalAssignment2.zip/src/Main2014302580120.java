
public class Main2014302580120 {

	public static void main(String[] args) {

		 MainFrame mainFrame = new MainFrame();
		 mainFrame.setVisible(true);
		 mainFrame.atm.run();
		
	}

}
