//Screen.java
public class Screen {
	public void displayMessage(String message){
		ATMface.textArea.append(message);
		System.out.print(message);
	}
	public void displayMessageLine(String message){
		ATMface.textArea.append(message+"\n");
		System.out.println(message);
	}
	public void displayDollarAmount(double amount){
		String str=Double.toString(amount);
		ATMface.textArea.append("$"+str);
		System.out.printf("$%,.2f",amount);
	}
}
