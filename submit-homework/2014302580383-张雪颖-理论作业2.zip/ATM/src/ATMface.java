import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class ATMface {
	String str="";
	public JFrame frmAtm;
	public ATM atm;
	static JTextArea textArea = new JTextArea();
	private JTextField txtTakeCash;
	private JTextField txtInputCash;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
	
					ATMface window = new ATMface();
					window.frmAtm.setVisible(true);
					window.atm.run();
			
	}

	/**
	 * Create the application.
	 */
	public ATMface() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void inputProc(int number){
		String num=String.valueOf(number);	
		str+=num;		
	}
	
	public void initialize() {
		atm=new ATM();
		frmAtm = new JFrame();
		frmAtm.setBackground(new Color(153, 204, 204));
		frmAtm.setTitle("ATM");
		frmAtm.setBounds(100, 100, 420, 413);
		frmAtm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAtm.getContentPane().setLayout(null);
		
		
		textArea.setBackground(new Color(153, 204, 204)); 
		textArea.setBounds(30, 21, 330, 117);
		textArea.setRows(4);
		frmAtm.getContentPane().add(textArea);
		
		JButton button1 = new JButton("1");
		button1.setBackground(new Color(153, 204, 255));
		button1.setFont(new Font("��Բ", Font.BOLD, 12));
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						inputProc(1);
						textArea.append("1");
			}
		});
		button1.setBounds(30, 162, 41, 40);
		frmAtm.getContentPane().add(button1);
		
		JButton button2 = new JButton("2");
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputProc(2);
				textArea.append("2");
			}
			
		});
		button2.setBackground(new Color(153, 204, 255));
		button2.setFont(new Font("��Բ", Font.BOLD, 12));
		button2.setBounds(85, 162, 41, 40);
		frmAtm.getContentPane().add(button2);
		
		JButton button3 = new JButton("3");
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputProc(3);
				textArea.append("3");
			}
		});
		button3.setBackground(new Color(153, 204, 255));
		button3.setFont(new Font("��Բ", Font.BOLD, 12));
		button3.setBounds(142, 162, 41, 40);
		frmAtm.getContentPane().add(button3);
		
		JButton button4 = new JButton("4");
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputProc(4);
				textArea.append("4");
			     
			}
		});
		button4.setBackground(new Color(153, 204, 255));
		button4.setFont(new Font("��Բ", Font.BOLD, 12));
		button4.setBounds(30, 214, 41, 40);
		frmAtm.getContentPane().add(button4);
		
		JButton button5 = new JButton("5");
		button5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputProc(5);
				textArea.append("5");
			}
		});
		button5.setBackground(new Color(153, 204, 255));
		button5.setFont(new Font("��Բ", Font.BOLD, 12));
		button5.setBounds(85, 212, 41, 40);
		frmAtm.getContentPane().add(button5);
		
		JButton button6 = new JButton("6");
		button6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputProc(6);
				textArea.append("6");
			}
		});
		button6.setBackground(new Color(153, 204, 255));
		button6.setFont(new Font("��Բ", Font.BOLD, 12));
		button6.setBounds(142, 212, 41, 40);
		frmAtm.getContentPane().add(button6);
		
		JButton button7 = new JButton("7");
		button7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputProc(7);
				textArea.append("7");
			}
		});
		button7.setBackground(new Color(153, 204, 255));
		button7.setFont(new Font("��Բ", Font.BOLD, 12));
		button7.setBounds(30, 264, 41, 40);
		frmAtm.getContentPane().add(button7);
		
		JButton button8 = new JButton("8");
		button8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputProc(8);
				textArea.append("8");
			}
		});
		button8.setBackground(new Color(153, 204, 255));
		button8.setFont(new Font("��Բ", Font.BOLD, 12));
		button8.setBounds(85, 262, 41, 40);
		frmAtm.getContentPane().add(button8);
		
		JButton button9 = new JButton("9");
		button9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputProc(9);
				textArea.append("9");
			
			}
		});
		button9.setBackground(new Color(153, 204, 255));
		button9.setFont(new Font("��Բ", Font.BOLD, 12));
		button9.setBounds(142, 262, 41, 40);
		frmAtm.getContentPane().add(button9);
		
		JButton button0 = new JButton("0");
		button0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputProc(0);
				textArea.append("0");
			}
		});
		button0.setBackground(new Color(153, 204, 255));
		button0.setFont(new Font("��Բ", Font.BOLD, 12));
		button0.setBounds(30, 314, 41, 40);
		frmAtm.getContentPane().add(button0);
		
		JButton buttonEnter = new JButton("enter");
		buttonEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				atm.keypad.number=Integer.parseInt(str);
				atm.keypad.bl=true;
				str="";
			}
		});
		buttonEnter.setBackground(new Color(153, 204, 255));
		buttonEnter.setFont(new Font("��Բ", Font.BOLD, 12));
		buttonEnter.setBounds(90, 314, 93, 40);
		frmAtm.getContentPane().add(buttonEnter);
		
		txtTakeCash = new JTextField();
		txtTakeCash.setBackground(new Color(51, 204, 255));
		txtTakeCash.setHorizontalAlignment(SwingConstants.CENTER);
		txtTakeCash.setFont(new Font("��Բ", Font.BOLD, 12));
		txtTakeCash.setText("take cash");
		txtTakeCash.setBounds(212, 198, 144, 32);
		frmAtm.getContentPane().add(txtTakeCash);
		txtTakeCash.setColumns(10);
		
		txtInputCash = new JTextField();
		txtInputCash.setBackground(new Color(51, 204, 255));
		txtInputCash.setHorizontalAlignment(SwingConstants.CENTER);
		txtInputCash.setFont(new Font("��Բ", Font.BOLD, 12));
		txtInputCash.setText("input cash");
		txtInputCash.setColumns(10);
		txtInputCash.setBounds(212, 285, 144, 32);
		frmAtm.getContentPane().add(txtInputCash);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 21, 330, 117);
		frmAtm.getContentPane().add(scrollPane);
		scrollPane.setViewportView(textArea);
	}

	
}
