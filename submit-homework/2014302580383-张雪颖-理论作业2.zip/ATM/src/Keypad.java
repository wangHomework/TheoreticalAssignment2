
//Keypad.java
public class Keypad {
	public  int number;
	public boolean bl=false;
	public Keypad(){
	}
	public int getInput(){
		bl=false;
		 while(!bl){System.out.print("");}
		return number;
	}

}
