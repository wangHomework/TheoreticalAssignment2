import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class ATMCaseStudy
 {
  // main method creates and runs the ATM
	static String account_num ="";
	static String account_pin ="";
	static String amountStr ="";
	static int amount=0;
    static int page=0;
    static int num=0;
    static int id=0;
    static int pin=0;
 public static void main( String[] args )
 {
 /*ATM theATM = new ATM();
 theATM.run();*/
	 ATM atm = new ATM();

     JFrame atmFrame = new JFrame();
     atmFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     atmFrame.setSize(500, 563);
     atmFrame.setResizable(false);
     atmFrame.setVisible(true);
     atmFrame.setLayout(null);
     
     JTextArea textArea = new JTextArea();
     atmFrame.add(textArea);
     textArea.setBounds(20, 20, 440, 180);     
     textArea.setEnabled(false);
     
     JLabel withdrawLabel = new JLabel(new ImageIcon("withdrawSlot.png"));
     atmFrame.add(withdrawLabel);
     withdrawLabel.setBounds(260, 220, 216, 142);

     JLabel depositLabel = new JLabel(new ImageIcon("depositSlot.png"));
     atmFrame.add(depositLabel);
     depositLabel.setBounds(260, 362, 214, 152);


     textArea.setText("\nWelcome\n\nPlease enter your account number: ");
     
     JButton botton_1 = new JButton();
     botton_1.setText("1");
     atmFrame.add(botton_1);
     botton_1.setBounds(0, 220, 70, 63);
     botton_1.setFocusPainted(false);
     botton_1.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 if(num==0)
            	 {
            		 textArea.setText(textArea.getText()+"1");
            		 account_num=account_num+"1";
            	 }
            	 if(num==1)
            	 {
            		 textArea.setText(textArea.getText()+"*");
            		 account_pin=account_pin+"1";
            	 }
            	 break;
             case 1:
            	 page=3;
            	 textArea.setText("\nPlease enter the amout you want to deposit:");
            	 break;
             case 3:
            	 textArea.setText(textArea.getText()+"1");
            	 amountStr=amountStr+"1";
            	 break;
             case 4:
            	 textArea.setText(textArea.getText()+"1");
            	 amountStr=amountStr+"1";
            	 break;
             }         
         }
     });

     JButton botton_2 = new JButton();
     botton_2.setText("2");
     atmFrame.add(botton_2);
     botton_2.setBounds(85, 220, 70, 63);
     botton_2.setFocusPainted(false);
     botton_2.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 if(num==0)
            	 {
            		 textArea.setText(textArea.getText()+"2");
            		 account_num=account_num+"2";
            	 }
            	 if(num==1)
            	 {
            		 textArea.setText(textArea.getText()+"*");
            		 account_pin=account_pin+"2";
            	 }
            	 break;
             case 1:
            	 page=4;
            	 textArea.setText("\nPlease enter the amout you want to withdraw:");
            	 break;
             case 3:
            	 textArea.setText(textArea.getText()+"2");
            	 amountStr=amountStr+"2";
            	 break;
             case 4:
            	 textArea.setText(textArea.getText()+"2");
            	 amountStr=amountStr+"2";
            	 break;
             }         
         }
     });
     
     JButton botton_3 = new JButton();
     botton_3.setText("3");
     atmFrame.add(botton_3);
     botton_3.setBounds(170, 220, 70, 63);
     botton_3.setFocusPainted(false);
     botton_3.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 if(num==0)
            	 {
            		 textArea.setText(textArea.getText()+"3");
            		 account_num=account_num+"3";
            	 }
            	 if(num==1)
            	 {
            		 textArea.setText(textArea.getText()+"*");
            		 account_pin=account_pin+"3";
            	 }
            	 break;
             case 1:
            	 double availableBalance=atm.bankDatabase.getAvailableBalance(id);
            	 double totalBalance=atm.bankDatabase.getTotalBalance(id);
            	 page=2;
            	 textArea.setText("\nBalance Information:\n\n- Available balance:"+availableBalance+"\n\n- Total balance:"+totalBalance);
            	 break;
             case 3:
            	 textArea.setText(textArea.getText()+"3");
            	 amountStr=amountStr+"3";
            	 break;
             case 4:
            	 textArea.setText(textArea.getText()+"3");
            	 amountStr=amountStr+"3";
            	 break;
             }         
         }
     });
     
     JButton botton_4 = new JButton();
     botton_4.setText("4");
     atmFrame.add(botton_4);
     botton_4.setBounds(0, 298, 70, 63);
     botton_4.setFocusPainted(false);
     botton_4.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 if(num==0)
            	 {
            		 textArea.setText(textArea.getText()+"4");
            		 account_num=account_num+"4";
            	 }
            	 if(num==1)
            	 {
            		 textArea.setText(textArea.getText()+"*");
            		 account_pin=account_pin+"4";
            	 }
            	 break;
             case 3:
            	 textArea.setText(textArea.getText()+"4");
            	 amountStr=amountStr+"4";
            	 break;
             case 4:
            	 textArea.setText(textArea.getText()+"4");
            	 amountStr=amountStr+"4";
            	 break;
             }         
         }
     });
     
     JButton botton_5 = new JButton();
     botton_5.setText("5");
     atmFrame.add(botton_5);
     botton_5.setBounds(85, 298, 70, 63);
     botton_5.setFocusPainted(false);
     botton_5.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 if(num==0)
            	 {
            		 textArea.setText(textArea.getText()+"5");
            		 account_num=account_num+"5";
            	 }
            	 if(num==1)
            	 {
            		 textArea.setText(textArea.getText()+"*");
            		 account_pin=account_pin+"5";
            	 }
            	 break;
             case 3:
            	 textArea.setText(textArea.getText()+"5");
            	 amountStr=amountStr+"5";
            	 break;
             case 4:
            	 textArea.setText(textArea.getText()+"5");
            	 amountStr=amountStr+"5";
            	 break;
             }         
         }
     });
     
     JButton botton_6 = new JButton();
     botton_6.setText("6");
     atmFrame.add(botton_6);
     botton_6.setBounds(170, 298, 70, 63);
     botton_6.setFocusPainted(false);
     botton_6.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 if(num==0)
            	 {
            		 textArea.setText(textArea.getText()+"6");
            		 account_num=account_num+"6";
            	 }
            	 if(num==1)
            	 {
            		 textArea.setText(textArea.getText()+"*");
            		 account_pin=account_pin+"6";
            	 }
            	 break;
             case 3:
            	 textArea.setText(textArea.getText()+"6");
            	 amountStr=amountStr+"6";
            	 break;
             case 4:
            	 textArea.setText(textArea.getText()+"6");
            	 amountStr=amountStr+"6";
            	 break;
             }         
         }
     });
     
     JButton botton_7 = new JButton();
     botton_7.setText("7");
     atmFrame.add(botton_7);
     botton_7.setBounds(0, 376, 70, 63);
     botton_7.setFocusPainted(false);
     botton_7.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 if(num==0)
            	 {
            		 textArea.setText(textArea.getText()+"7");
            		 account_num=account_num+"7";
            	 }
            	 if(num==1)
            	 {
            		 textArea.setText(textArea.getText()+"*");
            		 account_pin=account_pin+"7";
            	 }
            	 break;
             case 3:
            	 textArea.setText(textArea.getText()+"7");
            	 amountStr=amountStr+"7";
            	 break;
             case 4:
            	 textArea.setText(textArea.getText()+"7");
            	 amountStr=amountStr+"7";
            	 break;
             }         
         }
     });
     
     JButton botton_8 = new JButton();
     botton_8.setText("8");
     atmFrame.add(botton_8);
     botton_8.setBounds(85, 376, 70, 63);
     botton_8.setFocusPainted(false);
     botton_8.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 if(num==0)
            	 {
            		 textArea.setText(textArea.getText()+"8");
            		 account_num=account_num+"8";
            	 }
            	 if(num==1)
            	 {
            		 textArea.setText(textArea.getText()+"*");
            		 account_pin=account_pin+"8";
            	 }
            	 break;
             case 3:
            	 textArea.setText(textArea.getText()+"8");
            	 amountStr=amountStr+"8";
            	 break;
             case 4:
            	 textArea.setText(textArea.getText()+"8");
            	 amountStr=amountStr+"8";
            	 break;
             }         
         }
     });
     
     JButton botton_9 = new JButton();
     botton_9.setText("9");
     atmFrame.add(botton_9);
     botton_9.setBounds(170, 376, 70, 63);
     botton_9.setFocusPainted(false);
     botton_9.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 if(num==0)
            	 {
            		 textArea.setText(textArea.getText()+"9");
            		 account_num=account_num+"9";
            	 }
            	 if(num==1)
            	 {
            		 textArea.setText(textArea.getText()+"*");
            		 account_pin=account_pin+"9";
            	 }
            	 break;
             case 3:
            	 textArea.setText(textArea.getText()+"9");
            	 amountStr=amountStr+"9";
            	 break;
             case 4:
            	 textArea.setText(textArea.getText()+"9");
            	 amountStr=amountStr+"9";
            	 break;
             }         
         }
     });
     
     JButton botton_0 = new JButton();
     botton_0.setText("0");
     atmFrame.add(botton_0);
     botton_0.setBounds(0, 454, 70, 63);
     botton_0.setFocusPainted(false);
     botton_0.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 if(num==0)
            	 {
            		 textArea.setText(textArea.getText()+"0");
            		 account_num=account_num+"0";
            	 }
            	 if(num==1)
            	 {
            		 textArea.setText(textArea.getText()+"*");
            		 account_pin=account_pin+"0";
            	 }
            	 break;
             case 3:
            	 textArea.setText(textArea.getText()+"0");
            	 amountStr=amountStr+"0";
            	 break;
             case 4:
            	 textArea.setText(textArea.getText()+"0");
            	 amountStr=amountStr+"0";
            	 break;
             }         
         }
     });
     
     JButton botton_cancel = new JButton();
     botton_cancel.setText("cancel");
     atmFrame.add(botton_cancel);
     botton_cancel.setBounds(84, 454, 72, 63);
     botton_cancel.setFocusPainted(false);
     botton_cancel.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 textArea.setText("\nWelcome\n\nPlease enter your account number: ");
            	 num=0;
            	 account_num="";
            	 account_pin="";
            	 break;
             case 1:
            	 textArea.setText("\nWelcome\n\nPlease enter your account number: ");
            	 num=0;
            	 account_num="";
            	 account_pin="";
            	 break;
             case 2:
            	 textArea.setText("Please choose a event\n\n1-Deposit    3-Inquire balance \n\n 2-WithDeaw    Cancel-Exit");
            	 page=1;
            	 break;
             case 3:
            	 textArea.setText("Please choose a event\n\n1-Deposit    3-Inquire balance \n\n 2-WithDeaw    Cancel-Exit");
            	 page=1;
            	 amountStr="";
            	 break;
             case 4:
            	 textArea.setText("Please choose a event\n\n1-Deposit    3-Inquire balance \n\n 2-WithDeaw    Cancel-Exit");
            	 page=1;
            	 amountStr="";
            	 break;
             case 9:
            	 textArea.setText("Please choose a event\n\n1-Deposit    3-Inquire balance \n\n 2-WithDeaw    Cancel-Exit");
            	 page=1;
            	 amountStr="";
            	 break;
             }         
         }
     });
     
     JButton botton_enter = new JButton();
     botton_enter.setText("enter");
     atmFrame.add(botton_enter);
     botton_enter.setBounds(170, 454, 70, 63);
     botton_enter.setFocusPainted(false);
     botton_enter.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
             switch (page)
             {
             case 0:
            	 if(atm.bankDatabase.getAccount(Integer.parseInt(account_num))!=null)
            	 {
            		 if(num==0)
            		 {
            			 id=Integer.parseInt(account_num);
            			 num=num+1;
            			 textArea.setText(textArea.getText()+"\n\nPlease enter your PIN:");
            		 }
            		 if(num==1)
            		 {
            			 pin=Integer.parseInt(account_pin);
            			 if(atm.bankDatabase.authenticateUser(id,pin))
            			 {
            				 page=1;
            				 textArea.setText("\nPlease choose a event\n\n1-Deposit    3-Inquire balance \n\n 2-WithDeaw    Cancel-Exit");
            			 }
            			 else
            			 {
            				 textArea.setText("\nSorry,the pin is wrong,please try it again\n\nPlease enter your account number:");
            				 account_pin="";
            				 account_num="";
            				 num=0;
            			 }
            		 }
            	 }
            	 else
            	 {
            		 textArea.setText("\nSorry,your account id is wrong,please check it and print it again.\n\nPlease enter your account number:");
            		 account_num="";
            	 }
            	 break;
             case 3:
            	 page=9;
            	 amount=Integer.parseInt(amountStr);
            	 Account currentAccount=atm.bankDatabase.getAccount(id);
            	 currentAccount.credit(amount);
            	 textArea.setText("\nYour operation is successful \n\nenter the cancel to return the menu");
            	 break;
             case 4:
                 amount=Integer.parseInt(amountStr);
                 Account currentAccount1=atm.bankDatabase.getAccount(id);
                 if(amount<=currentAccount1.getAvailableBalance())
                 {
                	 page=9;
                	 currentAccount1.debit(amount);
                     textArea.setText("\nYour operation is successful \n\nenter the cancel to return the menu\n\nDon't forget to take the cash");
                 }
                 else
                 {
                	 amountStr="";
                	 textArea.setText("\n\nYou dou't have enough money in your account \n\nPlease enter a smaller number");
                 }
                 break;
             }         
         }
     });


 } // end main
 } // end class ATMCaseStudy