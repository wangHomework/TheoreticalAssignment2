import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
/*
 * 
 * 2014302580386 Ф���
 */



public class GUI {
    String str="";
	static JTextArea textArea = new JTextArea();
	public ATM atm;
	
	public GUI(){
		CreateJFrame();
	}
	
	public void CreateJFrame()                       
	{                                
		JFrame jf = new JFrame();                             //ʵ����һ��JFrame����
		Container c = jf.getContentPane();                    //��ȡһ������
		c.setBackground(Color.white);                         //��������������ɫ
		jf.setTitle("ATM");                                   //��������
		jf.setVisible(true);                                  //�������
		jf.setBounds(200,20, 400, 700);                       //���ô����С
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    //���ô���رշ���
		c.setLayout(null);
		
		
		//�������
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 20, 360, 160);
		scrollPane.setViewportView(textArea);
		c.add(scrollPane);
		
		//���ð�ť
		JButton button1 = new JButton("1");
		button1.setBounds(20, 430, 120, 60);
		button1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				inputProc(1);
				textArea.append("1");
				}
		});
		c.add(button1);
		
		JButton button2 = new JButton("2");
		button2.setBounds(140, 430, 120, 60);
		button2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				inputProc(1);
				textArea.append("2");
				}
		});
		c.add(button2);
		
		JButton button3 = new JButton("3");
		button3.setBounds(260, 430, 120, 60);
		button3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				inputProc(1);
				textArea.append("3");
				}
		});
		c.add(button3);
		
		JButton button4 = new JButton("4");
		button4.setBounds(20, 490, 120, 60);
		button4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				inputProc(1);
				textArea.append("4");
				}
		});
		c.add(button4);
		
		JButton button5 = new JButton("5");
		button5.setBounds(140, 490, 120, 60);
		button5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				inputProc(1);
				textArea.append("5");
				}
		});
		c.add(button5);
		
		JButton button6 = new JButton("6");
		button6.setBounds(260, 490, 120, 60);
		button6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				inputProc(1);
				textArea.append("6");
				}
		});
		c.add(button6);
		
		JButton button7 = new JButton("7");
		button7.setBounds(20, 550, 120, 60);
		button7.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				inputProc(1);
				textArea.append("7");
				}
		});
		c.add(button7);
		
		JButton button8 = new JButton("8");
		button8.setBounds(140, 550, 120, 60);
		button8.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				inputProc(1);
				textArea.append("8");
				}
		});
		c.add(button8);
		
		JButton button9 = new JButton("9");
		button9.setBounds(260, 550, 120, 60);
		button9.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				inputProc(1);
				textArea.append("9");
				}
		});
		c.add(button9);
		
		JButton button10 = new JButton("0");
		button10.setBounds(20, 610, 120, 60);
		button10.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				inputProc(1);
				textArea.append("0");
				}
		});
		c.add(button10);
		
		JButton button11 = new JButton("ENTER");
		button11.setBounds(140, 610, 240, 60);
		button11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				atm.keypad.number=Integer.parseInt(str);
				atm.keypad.bl=true;
				str="";
			}
		});
		c.add(button11);
		
		
		//�����ı���
		JTextField takecash = new JTextField();
		takecash.setBounds(20, 200, 360, 90);
		takecash.setHorizontalAlignment(SwingConstants.CENTER);
		takecash.setText("Take Cash");
		c.add(takecash);
		
		JTextField putincash = new JTextField();
		putincash.setBounds(20, 310, 360, 90);
		putincash.setHorizontalAlignment(SwingConstants.CENTER);
		putincash.setText("Putin Cash");
		c.add(putincash);
	
	
	}

	protected void inputProc(int i) {
		// TODO �Զ����ɵķ������
		String num=String.valueOf(i);	
		str+=num;
	}
	
	public static void main (String args[]){
		ATM theATM = new ATM();
		theATM.run();
		//new GUI();
	}

}
