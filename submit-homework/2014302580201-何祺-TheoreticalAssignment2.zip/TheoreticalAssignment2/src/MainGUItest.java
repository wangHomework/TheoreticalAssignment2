
public class MainGUItest {

	public static void main(String[] args) {
		new MainGUI();
	}

}

