import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class MainGUI extends JFrame {
	private String a;
	private String b;
	private JFrame mainGui;
	private JFrame atmGui;
	private JFrame errorGui;
	private JFrame balanceGui;
	private JFrame creditGui;
	private JFrame debitGui;
	private JLabel accountNumber;
	private JLabel pin;
	private JLabel texterror;
	private JTextField textAccountNumber;
	private JTextField textPin;
	private JButton login;
	private JButton balance;
	private JButton credit;
	private JButton debit;
	private JButton exit;
	private JButton back1;
	private JButton back2;
	private JButton credit1;
	private JButton credit2;
	private JButton credit3;
	private JButton credit4;
	private JButton credit5;
	private JButton back3;
	private JButton debit1;
	private JButton debit2;
	private JButton debit3;
	private JButton debit4;
	private JButton debit5;
	private JButton back4;
	private boolean userAuthenticated;
	private BankDatabase bankDatabase = new BankDatabase(); 
															
															

	public MainGUI() {
		login();
	}

	public void login() {
		mainGui = new JFrame("login");
		mainGui.setSize(500, 100);
		mainGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainGui.setLayout(new FlowLayout());
		accountNumber = new JLabel("�û���:");
		textAccountNumber = new JTextField(10);
		pin = new JLabel("����:");
		textPin = new JTextField(10);
		login = new JButton("��½");
		mainGui.add(accountNumber);
		mainGui.add(textAccountNumber);
		mainGui.add(pin);
		mainGui.add(textPin);
		mainGui.add(login);
		login.addActionListener(new handler());
		mainGui.setVisible(true);
		mainGui.setLocationRelativeTo(null);
	}

	private void atm() {
		atmGui = new JFrame("atm");
		atmGui.setSize(500, 100);
		atmGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		atmGui.setLayout(new FlowLayout());
		balance = new JButton("���");
		credit = new JButton("��Ǯ");
		debit = new JButton("ȡǮ");
		exit = new JButton("�˳�");
		atmGui.add(balance);
		atmGui.add(credit);
		atmGui.add(debit);
		atmGui.add(exit);
		balance.addActionListener(new handler());
		credit.addActionListener(new handler());
		debit.addActionListener(new handler());
		exit.addActionListener(new handler());
		atmGui.setVisible(true);
		atmGui.setLocationRelativeTo(null);
	}

	private void error() {
		errorGui = new JFrame();
		errorGui.setSize(500, 100);
		errorGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		errorGui.setLayout(new FlowLayout());
		texterror = new JLabel("�˺������������������");
		back1 = new JButton("����");
		errorGui.add(texterror);
		errorGui.add(back1);
		back1.addActionListener(new handler());
		errorGui.setVisible(true);
		errorGui.setLocationRelativeTo(null);
		mainGui.dispose();
	}

	private void balance() {
		balanceGui = new JFrame("���");
		balanceGui.setSize(500, 210);
		balanceGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		balanceGui.setLayout(new FlowLayout());
		JTextArea Balance = new JTextArea(15, 20);
		back2 = new JButton("����");
		balanceGui.add(Balance);
		balanceGui.add(back2);
		double availableBalance = bankDatabase.getAvailableBalance(Integer.parseInt(a));
		double totalBalance = bankDatabase.getTotalBalance(Integer.parseInt(a));
		String TextBalance = "availableBalance:" + Double.toString(availableBalance) + "\n" + "totalBalance:"
				+ Double.toString(totalBalance);
		Balance.setText(TextBalance);
		back2.addActionListener(new handler());
		balanceGui.setVisible(true);
		balanceGui.setLocationRelativeTo(null);
		atmGui.dispose();
	}

	private void credit() {
		creditGui = new JFrame("���X");
		creditGui.setSize(500, 100);
		creditGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		creditGui.setLayout(new FlowLayout());
		credit1 = new JButton("$20");
		credit2 = new JButton("$40");
		credit3 = new JButton("$60");
		credit4 = new JButton("$100");
		credit5 = new JButton("$200");
		back3 = new JButton("����");
		creditGui.add(credit1);
		creditGui.add(credit2);
		creditGui.add(credit3);
		creditGui.add(credit4);
		creditGui.add(credit5);
		creditGui.add(back3);
		credit1.addActionListener(new handler());
		credit2.addActionListener(new handler());
		credit3.addActionListener(new handler());
		credit4.addActionListener(new handler());
		credit5.addActionListener(new handler());
		back3.addActionListener(new handler());
		creditGui.setVisible(true);
		creditGui.setLocationRelativeTo(null);
		atmGui.dispose();
	}

	private void debit() {
		debitGui = new JFrame("ȡ�X");
		debitGui.setSize(500, 100);
		debitGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		debitGui.setLayout(new FlowLayout());
		debit1 = new JButton("$20");
		debit2 = new JButton("$40");
		debit3 = new JButton("$60");
		debit4 = new JButton("$100");
		debit5 = new JButton("$200");
		back4 = new JButton("����");
		debitGui.add(debit1);
		debitGui.add(debit2);
		debitGui.add(debit3);
		debitGui.add(debit4);
		debitGui.add(debit5);
		debitGui.add(back4);
		debit1.addActionListener(new handler());
		debit2.addActionListener(new handler());
		debit3.addActionListener(new handler());
		debit4.addActionListener(new handler());
		debit5.addActionListener(new handler());
		back4.addActionListener(new handler());
		debitGui.setVisible(true);
		debitGui.setLocationRelativeTo(null);
		atmGui.dispose();
	}

	private class handler implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			if (event.getSource() == login) {
				a = textAccountNumber.getText();
				b = textPin.getText();
				userAuthenticated = bankDatabase.authenticateUser(Integer.parseInt(a), Integer.parseInt(b));
				if (!userAuthenticated) {
					error();
				} else {
					atm();
					mainGui.dispose();
				}
			}
			if (event.getSource() == back1) {
				mainGui.setVisible(true);
				errorGui.dispose();
			}
			if (event.getSource() == balance) {
				balance();
			}
			if(event.getSource()==credit){
				credit();
			}
			if(event.getSource()==debit){
				debit();
			}
			if (event.getSource() == back2) {
				atmGui.setVisible(true);
				balanceGui.dispose();
			}
			if(event.getSource()==back3){
				atmGui.setVisible(true);
				creditGui.dispose();
			}
			if(event.getSource()==back4){
				atmGui.setVisible(true);
				debitGui.dispose();
			}
			if(event.getSource()==credit1 ){
				bankDatabase.credit(Integer.parseInt(a), 20);
				atmGui.setVisible(true);
				creditGui.dispose();
			}
			if(event.getSource()==credit2){
				bankDatabase.credit(Integer.parseInt(a), 40);
				atmGui.setVisible(true);
				creditGui.dispose();
			}
			if(event.getSource()==credit3){
				bankDatabase.credit(Integer.parseInt(a), 60);
				atmGui.setVisible(true);
				creditGui.dispose();
			}
			if(event.getSource()==credit4){
				bankDatabase.credit(Integer.parseInt(a), 100);
				atmGui.setVisible(true);
				creditGui.dispose();
			}
			if(event.getSource()==credit5){
				bankDatabase.credit(Integer.parseInt(a), 200);
				atmGui.setVisible(true);
				creditGui.dispose();
			}
			if(event.getSource()==debit1){
				bankDatabase.debit(Integer.parseInt(a), 20);
				atmGui.setVisible(true);
				debitGui.dispose();
			}
			if(event.getSource()==debit2){
				bankDatabase.debit(Integer.parseInt(a), 40);
				atmGui.setVisible(true);
				debitGui.dispose();
			}
			if(event.getSource()==debit3){
				bankDatabase.debit(Integer.parseInt(a), 60);
				atmGui.setVisible(true);
				debitGui.dispose();
			}
			if(event.getSource()==debit4){
				bankDatabase.debit(Integer.parseInt(a), 100);
				atmGui.setVisible(true);
				debitGui.dispose();
			}
			if(event.getSource()==debit5){
				bankDatabase.debit(Integer.parseInt(a), 200);
				atmGui.setVisible(true);
				debitGui.dispose();
			}
			if(event.getSource()==exit){
				System.exit(0);
			}
		}
	}
}

