import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.Color;

import javax.swing.border.BevelBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextArea;

import java.awt.Font;

import javax.swing.JScrollPane;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

public class ATMCaseStudy extends JFrame {
	JTextArea txtrScreen= new JTextArea();
	JButton btnEnter = new JButton("enter");
	private JPanel contentPane;
	boolean inputIsOK = false;
	int input=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		//EventQueue.invokeLater(new Runnable() {
		//	public void run() {
				
				ATMCaseStudy frame = new ATMCaseStudy();
				frame.setVisible(true);
				ATM theATM = new ATM();
				theATM.start(frame);
		//	}
		//});
	
	}

	/**
	 * Create the frame.
	 */
	public ATMCaseStudy() {
		setTitle("ljm\u7684\u76AE\u795E\u94F6\u884C");
		setIconImage(Toolkit.getDefaultToolkit().getImage(ATMCaseStudy.class.getResource("/com/sun/java/swing/plaf/windows/icons/HardDrive.gif")));
			setResizable(false);
		Screen screen = new Screen();
		// init the whole window
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 488);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(135, 206, 235));
		contentPane.setForeground(new Color(47, 79, 79));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		// keyb buttons
		JButton button_0 = new JButton("1");
		button_0.setBackground(new Color(105, 105, 105));
		button_0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String temp = txtrScreen.getText();
				txtrScreen.setText(temp+"1");
				System.out.println(txtrScreen.getText().length());
				txtrScreen.setCaretPosition(txtrScreen.getText().length());
				input = input*10+1;
			}
		});
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(getClass().getResource("/tbg.jpg")));
		label.setBounds(211, 293, 223, 156);
		contentPane.add(label);
		button_0.setBounds(20, 176, 50, 50);
		contentPane.add(button_0);

		JButton button_1 = new JButton("2");
		button_1.setBackground(new Color(105, 105, 105));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String temp = txtrScreen.getText();
				txtrScreen.setText(temp+"2");
				System.out.println(txtrScreen.getText().length());
				txtrScreen.setCaretPosition(txtrScreen.getText().length());
				input = input*10+2;
			}
		});
		button_1.setBounds(80, 176, 50, 50);
		contentPane.add(button_1);

		JButton button_2 = new JButton("3");
		button_2.setBackground(new Color(105, 105, 105));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String temp = txtrScreen.getText();
				txtrScreen.setText(temp+"3");
				System.out.println(txtrScreen.getText().length());
				txtrScreen.setCaretPosition(txtrScreen.getText().length());
				input = input*10+3;
			}
		});
		button_2.setBounds(140, 176, 50, 50);
		contentPane.add(button_2);

		JButton button_3 = new JButton("4");
		button_3.setBackground(new Color(105, 105, 105));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String temp = txtrScreen.getText();
				txtrScreen.setText(temp+"4");
				System.out.println(txtrScreen.getText().length());
				txtrScreen.setCaretPosition(txtrScreen.getText().length());
				input = input*10+4;
			}
		});
		button_3.setBounds(20, 246, 50, 50);
		contentPane.add(button_3);

		JButton button_4 = new JButton("5");
		button_4.setBackground(new Color(105, 105, 105));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String temp = txtrScreen.getText();
				txtrScreen.setText(temp+"5");
				System.out.println(txtrScreen.getText().length());
				txtrScreen.setCaretPosition(txtrScreen.getText().length());
				input = input*10+5;
			}
		});
		button_4.setBounds(80, 246, 50, 50);
		contentPane.add(button_4);

		JButton button_5 = new JButton("6");
		button_5.setBackground(new Color(128, 128, 128));
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String temp = txtrScreen.getText();
				txtrScreen.setText(temp+"6");
				System.out.println(txtrScreen.getText().length());
				txtrScreen.setCaretPosition(txtrScreen.getText().length());
				input = input*10+6;
			}
		});
		button_5.setBounds(140, 246, 50, 50);
		contentPane.add(button_5);

		JButton button_6 = new JButton("7");
		button_6.setBackground(new Color(105, 105, 105));
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String temp = txtrScreen.getText();
				txtrScreen.setText(temp+"7");
				System.out.println(txtrScreen.getText().length());
				txtrScreen.setCaretPosition(txtrScreen.getText().length());
				input = input*10+7;
			}
		});
		button_6.setBounds(20, 316, 50, 50);
		contentPane.add(button_6);

		JButton button_7 = new JButton("8");
		button_7.setBackground(new Color(105, 105, 105));
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String temp = txtrScreen.getText();
				txtrScreen.setText(temp+"8");
				System.out.println(txtrScreen.getText().length());
				txtrScreen.setCaretPosition(txtrScreen.getText().length());
				input= input*10+8;
			}
		});
		button_7.setBounds(80, 316, 50, 50);
		contentPane.add(button_7);

		JButton button_8 = new JButton("9");
		button_8.setBackground(new Color(105, 105, 105));
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String temp = txtrScreen.getText();
				txtrScreen.setText(temp+"9");
				System.out.println(txtrScreen.getText().length());
				txtrScreen.setCaretPosition(txtrScreen.getText().length());
				input = input*10+9;
			}
		});
		button_8.setBounds(140, 316, 50, 50);
		contentPane.add(button_8);

		JButton button_9 = new JButton("0");
		button_9.setBackground(new Color(105, 105, 105));
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String temp = txtrScreen.getText();
				txtrScreen.setText(temp+"0");
				System.out.println(txtrScreen.getText().length());
				txtrScreen.setCaretPosition(txtrScreen.getText().length());
				input = input*10;
			}
		});
		button_9.setBounds(20, 386, 50, 50);
		contentPane.add(button_9);
		btnEnter.setBackground(new Color(105, 105, 105));
		//
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputIsOK = true; 
			}
		});

		btnEnter.setBounds(80, 386, 110, 50);
		contentPane.add(btnEnter);

		// keyb background
		JLabel label_1 = new JLabel("");
		label_1.setOpaque(true);
		label_1.setBackground(new Color(250, 250, 210));
		label_1.setBounds(10, 164, 191, 285);
		contentPane.add(label_1);
		txtrScreen.setWrapStyleWord(true);
		txtrScreen.setLineWrap(true);
		txtrScreen.setEnabled(false);
		txtrScreen.setEditable(false);
		txtrScreen.setFont(new Font("΢���ź�", Font.PLAIN, 14));

		
		txtrScreen.setDisabledTextColor(Color.BLACK);
		txtrScreen.setText(" ");
		txtrScreen.setBounds(10, 10, 414, 150);
		JScrollPane txtPane = new JScrollPane(txtrScreen);
		txtPane.setBounds(10, 10, 414, 150);
		contentPane.add(txtPane);
		
		JButton btnNewButton = new JButton("clear");
		btnNewButton.setFont(new Font("΢���ź�", Font.BOLD, 14));
		btnNewButton.setBackground(new Color(147, 112, 219));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtrScreen.setText(" ");
			}
		});
		btnNewButton.setBounds(277, 233, 147, 50);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("backspace");
		btnNewButton_1.setFont(new Font("΢���ź�", Font.BOLD, 14));
		btnNewButton_1.setBackground(new Color(65, 105, 225));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtrScreen.setText(txtrScreen.getText().substring(0, txtrScreen.getText().length()-1));
				input/=10;
			}
		});
		btnNewButton_1.setBounds(211, 176, 121, 50);
		contentPane.add(btnNewButton_1);
		
	}
}
