// Represents the screen of the ATM

public class Screen {
	// display a message without a carriage return
	public void displayMessage(ATMCaseStudy ATMCaseStudy, String message) {
		String temp = ATMCaseStudy.txtrScreen.getText();
		ATMCaseStudy.txtrScreen.setText(temp+message);
		System.out.println(ATMCaseStudy.txtrScreen.getText().length());
		ATMCaseStudy.txtrScreen.setCaretPosition(ATMCaseStudy.txtrScreen.getText().length());
	} // end method displayMessage

	// display a message with a carriage return
	public void displayMessageLine(ATMCaseStudy ATMCaseStudy, String message) {
		String temp = ATMCaseStudy.txtrScreen.getText();
		ATMCaseStudy.txtrScreen.setText(temp+"\n"+message);
		System.out.println(ATMCaseStudy.txtrScreen.getText().length());
		ATMCaseStudy.txtrScreen.setCaretPosition(ATMCaseStudy.txtrScreen.getText().length());
	} // end method displayMessageLine

	// displays a dollar amount
	public void displayDollarAmount(ATMCaseStudy ATMCaseStudy, double amount) {
		String temp = ATMCaseStudy.txtrScreen.getText();
		ATMCaseStudy.txtrScreen.setText(temp+amount);
		System.out.println(ATMCaseStudy.txtrScreen.getText().length());
		ATMCaseStudy.txtrScreen.setCaretPosition(ATMCaseStudy.txtrScreen.getText().length());
	} // end method displayDollarAmount
} // end class Screen