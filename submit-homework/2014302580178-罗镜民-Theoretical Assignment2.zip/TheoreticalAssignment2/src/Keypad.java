import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner; // program uses Scanner to obtain user input

public class Keypad {
	// reads data from the command line
	// no-argument constructor initializes the Scanner
	public Keypad() {

	} // end no-argument Keypad constructor

	// return an integer value entered by user
	public int getInput(ATMCaseStudy ATMCaseStudy) {
		while (true) {
			try {
				Thread.sleep(1500); // ��ͣ��ÿ1500hao�����һ��
			} catch (InterruptedException e) {
				return 0;
			}
			System.out.println(ATMCaseStudy.inputIsOK);
			if (ATMCaseStudy.inputIsOK) {
				ATMCaseStudy.inputIsOK = false;
				int temp = ATMCaseStudy.input;
				ATMCaseStudy.input = 0;
				return temp;
			}

			// �ȴ���ť���˲�����return
			// we assume that user enters an integer

		}
	} // end method getInput
}