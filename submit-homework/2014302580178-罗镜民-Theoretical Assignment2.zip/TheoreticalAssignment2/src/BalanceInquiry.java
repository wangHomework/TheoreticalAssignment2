public class BalanceInquiry extends Transaction
 {
 // BalanceInquiry constructor
 public BalanceInquiry( int userAccountNumber, Screen atmScreen,
 BankDatabase atmBankDatabase )
 {
 super( userAccountNumber, atmScreen, atmBankDatabase );
 } // end BalanceInquiry constructor

 // performs the transaction
 @Override
 public void execute(ATMCaseStudy ATMCaseStudy)
 {
	// get references to bank database and screen
	  BankDatabase bankDatabase = getBankDatabase();
	  Screen screen = getScreen();
	 
	  // get the available balance for the account involved
	  double availableBalance =
	  bankDatabase.getAvailableBalance( getAccountNumber() );
	 
	  // get the total balance for the account involved
	  double totalBalance =
	  bankDatabase.getTotalBalance( getAccountNumber() );
	 
	  // display the balance information on the screen
	  screen.displayMessageLine(ATMCaseStudy, "\nBalance Information:" );
	  screen.displayMessage( ATMCaseStudy," - Available balance: " );
	  screen.displayDollarAmount(ATMCaseStudy, availableBalance );
	  screen.displayMessage(ATMCaseStudy, "\n - Total balance: " );
	  screen.displayDollarAmount(ATMCaseStudy, totalBalance );
	  screen.displayMessageLine( ATMCaseStudy,"" );
	  } // end method execute
	  }
 