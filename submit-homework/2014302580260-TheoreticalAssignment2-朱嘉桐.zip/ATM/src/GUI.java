

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import java.awt.font.*;
public class GUI{
public static void main(String args[] ){
	new denglu();
}
}
class denglu{
private JFrame f;
private JFrame f2;
private JFrame f3;
private JFrame f4;
private JFrame f5;
private JFrame f6;
private JFrame f7;
private JTextArea jta;
private JTextArea jta2;
private JTextArea jta3;
private JTextArea jta4;
private JTextArea jta5;
private JTextArea jta6;
private JTextArea jta7;
private JButton bt1;
private JButton bt2;
private JButton bt3;
private JButton bt4;
private JButton bt5;
private JButton bt6;
private JButton bt7;
private JButton bt8;
private JButton bt9;
private JButton bt10;
private JButton bt11;
private JButton bt21;
private JButton bt22;
private JButton bt23;
private JButton bt24;
private JButton bt25;
private JButton bt26;
private JButton bt27;
private JButton bt28;
private JButton bt29;
private JButton bt210;
private JButton bt31;
private JButton bt0;
private JButton bt41;
private JButton bt42;
private JButton bt43;
private JButton bt44;
private JButton bt45;
private JButton bt46;
private JButton bt47;
private JButton bt48;
private JButton bt49;
private JButton bt50;
private JButton bt51;
private JButton bt52;
private JButton bt53;
private JButton bt54;
private JButton bt60;
private JButton bt61;
private JButton bt62;
private JButton bt63;
private JButton bt64;
private JButton bt70;
private JPanel panel;
/**
 * 
 */
public denglu(){
	f=new JFrame("ATM");
	f.setBounds(500,500,1200,1200);
	f.setLayout(null);
	f.setVisible(true);
	f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	panel=new JPanel();
	panel.setLayout(new GridLayout(4,4));
	panel.setBounds(1400, 800, 500, 500);
	f.add(panel);
	jta=new JTextArea();
	jta.setText("欢迎！");
	Font mf=new Font("Serif",0,35);
	jta.setFont(mf);
	jta.setBounds(1200,400,1000,400);
	f.add(jta);
	bt0=new JButton("继续");
	panel.add(bt0);
    bt0.addActionListener(new ActionListener()
 {
    	public void actionPerformed(ActionEvent e){
    		f.setVisible(false);
    		f6.setVisible(true);
    	}
  });
    f6=new JFrame("ATM");
   	f6.setBounds(500,500,1200,1200);
   	f6.setLayout(null);
   	f6.setVisible(false);
   	f6.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
   	panel=new JPanel();
   	panel.setLayout(new GridLayout(4,4));
   	panel.setBounds(1400, 800, 500, 500);
   	f6.add(panel);
   	jta5=new JTextArea();
   	jta5.setText("请输入用户名:");
   	jta5.setFont(mf);
   	jta5.setBounds(1200,400,1000,400);
   	f6.add(jta5);
   	bt1=new JButton("1");
   	panel.add(bt1);
   	bt2=new JButton("2");
   	panel.add(bt2);
   	bt3=new JButton("3");
   	panel.add(bt3);
   	bt4=new JButton("4");
   	panel.add(bt4);
   	bt5=new JButton("5");
   	panel.add(bt5);
   	bt6=new JButton("6");
   	panel.add(bt6);
   	bt7=new JButton("7");
   	panel.add(bt7);
   	bt8=new JButton("8");
   	panel.add(bt8);
   	bt9=new JButton("9");
   	panel.add(bt9);
   	bt11=new JButton("继续:");
   	panel.add(bt11);
   	bt1.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			jta5.setText("请输入用户名:1");
   		}
   	});
   	bt2.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			jta5.setText("请输入用户名:12");
   		}
   	});
   	bt3.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			jta5.setText("请输入用户名:123");
   		}
   	});
   	bt4.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			jta5.setText("请输入用户名:1234");
   		}
   	});
   	bt5.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			jta5.setText("请输入用户名:12345");
   		}
   	});
   	bt11.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			f6.setVisible(false);
   			f7.setVisible(true);
   		}
   	});
   	f7=new JFrame("ATM");
   	f7.setBounds(500,500,1200,1200);
   	f7.setLayout(null);
   	f6.setVisible(false);
   	f7.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
   	panel=new JPanel();
   	panel.setLayout(new GridLayout(4,4));
   	panel.setBounds(1400, 800, 500, 500);
   	f7.add(panel);
   	jta6=new JTextArea();
   	jta6.setText("请输入密码:");
   	jta6.setFont(mf);
   	jta6.setBounds(1200,400,1000,400);
   	f7.add(jta6);
   	bt41=new JButton("1");
   	panel.add(bt41);
   	bt42=new JButton("2");
   	panel.add(bt42);
   	bt43=new JButton("3");
   	panel.add(bt43);
   	bt44=new JButton("4");
   	panel.add(bt44);
   	bt45=new JButton("5");
   	panel.add(bt45);
   	bt46=new JButton("6");
   	panel.add(bt46);
   	bt47=new JButton("7");
   	panel.add(bt47);
   	bt48=new JButton("8");
   	panel.add(bt48);
   	bt49=new JButton("9");
   	panel.add(bt49);
   	bt50=new JButton("登录:");
   	panel.add(bt50);
   	bt45.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			jta6.setText("请输入密码:5");
   		}
   	});
   	bt44.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			jta6.setText("请输入密码:54");
   		}
   	});
   	bt43.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			jta6.setText("请输入密码:543");
   		}
   	});
   	bt42.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			jta6.setText("请输入密码:5432");
   		}
   	});
   	bt41.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			jta6.setText("请输入密码:54321");
   		}
   	});
   	bt50.addActionListener(new ActionListener(){
   		public void actionPerformed(ActionEvent e){
   			f7.setVisible(false);
   			f2.setVisible(true);
   		}
   	});
   	f2=new JFrame("ATM");
	f2.setBounds(500,500,1200,1200);
	f2.setLayout(null);
	f2.setVisible(false);
	f2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	panel=new JPanel();
	panel.setLayout(new GridLayout(4,4));
	panel.setBounds(1400, 800, 500, 500);
	f2.add(panel);
	jta2=new JTextArea();
	jta2.setText("请选择:\n1.账户信息查询\n2.取款\n3.存款\n4.退出");
	jta2.setFont(mf);
	jta2.setBounds(1200,400,1000,400);
	f2.add(jta2);
	bt21=new JButton("1");
	panel.add(bt21);
	bt22=new JButton("2");
	panel.add(bt22);
	bt23=new JButton("3");
	panel.add(bt23);
	bt24=new JButton("4");
	panel.add(bt24);
	bt25=new JButton("5");
	panel.add(bt25);
	bt26=new JButton("6");
	panel.add(bt26);
	bt27=new JButton("7");
	panel.add(bt27);
	bt28=new JButton("8");
	panel.add(bt28);
	bt29=new JButton("9");
	panel.add(bt29);
	bt210=new JButton("返回");
	panel.add(bt210);
	bt210.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			f.setVisible(true);
			f2.setVisible(false);
		}
	});
	bt21.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			f2.setVisible(false);
			f3.setVisible(true);
		}
	});
	bt22.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			f2.setVisible(false);
			f4.setVisible(true);
		}
	});
	bt23.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			f2.setVisible(false);
			f5.setVisible(true);
		}
	});
	bt24.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			System.exit(0);
		}
	});
	f3=new JFrame("ATM");
	f3.setBounds(500,500,1200,1200);
	f3.setLayout(null);
	f3.setVisible(false);
	f3.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	panel=new JPanel();
	panel.setLayout(new GridLayout(4,4));
	panel.setBounds(1400, 800, 500, 500);
	f3.add(panel);
	jta3=new JTextArea();
	jta3.setText("账户信息:\n余额为1200");
	jta3.setFont(mf);
	jta3.setBounds(1200,400,1000,400);
	f3.add(jta3);
	bt31=new JButton("返回");
	panel.add(bt31);
	bt31.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		f3.setVisible(false);
		f2.setVisible(true);
		}
	});
	f4=new JFrame("ATM");
	f4.setBounds(500,500,1200,1200);
	f4.setLayout(null);
	f4.setVisible(false);
	f4.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	panel=new JPanel();
	panel.setLayout(new GridLayout(4,4));
	panel.setBounds(1400, 800, 500, 500);
	f4.add(panel);
	jta4=new JTextArea();
	jta4.setText("取款:\n1.20\n2.40\n3.60\n4.100");
	jta4.setFont(mf);
	jta4.setBounds(1200,400,1000,400);
	f4.add(jta4);
	bt51=new JButton("1");
	panel.add(bt51);
	bt52=new JButton("2");
	panel.add(bt52);
	bt53=new JButton("3");
	panel.add(bt53);
	bt54=new JButton("4");
	panel.add(bt54);
	bt60=new JButton("返回");
	panel.add(bt60);
	bt60.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		f4.setVisible(false);
		f2.setVisible(true);
		}
	});
	bt51.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		JOptionPane.showMessageDialog(f4,"取出20");
		}
	});
	bt52.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		JOptionPane.showMessageDialog(f4,"取出40");
		}
	});
	bt53.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		JOptionPane.showMessageDialog(f4,"取出60");
		}
	});
	bt54.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		JOptionPane.showMessageDialog(f4,"取出100");
		}
	});
	f5=new JFrame("ATM");
	f5.setBounds(500,500,1200,1200);
	f5.setLayout(null);
	f5.setVisible(false);
	f5.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	panel=new JPanel();
	panel.setLayout(new GridLayout(4,4));
	panel.setBounds(1400, 800, 500, 500);
	f5.add(panel);
	jta7=new JTextArea();
	jta7.setText("存款:\n1.20\n2.40\n3.60\n4.100");
	jta7.setFont(mf);
	jta7.setBounds(1200,400,1000,400);
	f5.add(jta7);
	bt61=new JButton("1");
	panel.add(bt61);
	bt62=new JButton("2");
	panel.add(bt62);
	bt63=new JButton("3");
	panel.add(bt63);
	bt64=new JButton("4");
	panel.add(bt64);
	bt70=new JButton("返回");
	panel.add(bt70);
	bt60.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		f4.setVisible(false);
		f2.setVisible(true);
		}
	});
	bt61.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		JOptionPane.showMessageDialog(f5,"存入20");
		}
	});
	bt62.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		JOptionPane.showMessageDialog(f5,"存入40");
		}
	});
	bt63.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		JOptionPane.showMessageDialog(f5,"存入60");
		}
	});
	bt64.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		JOptionPane.showMessageDialog(f5,"存入100");
		}
	});
	bt70.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		f5.setVisible(false);
		f2.setVisible(true);
		}
	});
}
}



