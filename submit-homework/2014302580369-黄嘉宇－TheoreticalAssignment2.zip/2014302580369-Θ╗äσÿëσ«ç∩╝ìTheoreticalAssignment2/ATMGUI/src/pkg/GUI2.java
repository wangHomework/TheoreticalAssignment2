package pkg;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class GUI2 {

	protected Shell shell;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			GUI2 window = new GUI2();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("SWT Application");
		
		Label lblNewLabel = new Label(shell, SWT.NONE);
		lblNewLabel.setFont(SWTResourceManager.getFont(".Helvetica Neue DeskInterface", 15, SWT.NORMAL));
		lblNewLabel.setBounds(36, 21, 371, 48);
		lblNewLabel.setText("WELCOME PLEASE CHOOSE FROM THE BUTTONS");
		
		Button btnNewButton = new Button(shell, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				GUI3 window3 = new GUI3();
				
					try {
						shell.close();
					} catch (Throwable e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				window3.open();
			}
		});
		btnNewButton.setFont(SWTResourceManager.getFont(".Helvetica Neue DeskInterface", 18, SWT.NORMAL));
		btnNewButton.setForeground(SWTResourceManager.getColor(0, 0, 0));
		btnNewButton.setBounds(36, 75, 186, 48);
		btnNewButton.setText("取钱");
		
		Button btnNewButton_1 = new Button(shell, SWT.NONE);
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				GUI4 window4 = new GUI4();
				
				try {
					shell.close();
				} catch (Throwable e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			window4.open();
			}
		});
		btnNewButton_1.setFont(SWTResourceManager.getFont(".Helvetica Neue DeskInterface", 18, SWT.NORMAL));
		btnNewButton_1.setBounds(223, 75, 184, 49);
		btnNewButton_1.setText("存款");
		
		Button btnNewButton_2 = new Button(shell, SWT.NONE);
		btnNewButton_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				GUI5 window5 = new GUI5();
				
				try {
					shell.close();
				} catch (Throwable e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			window5.open();
			}
		});
		btnNewButton_2.setFont(SWTResourceManager.getFont(".Helvetica Neue DeskInterface", 18, SWT.NORMAL));
		btnNewButton_2.setBounds(36, 162, 186, 48);
		btnNewButton_2.setText("查余额");
		
		Button btnNewButton_3 = new Button(shell, SWT.NONE);
		btnNewButton_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				GUI window5 = new GUI();
				
				try {
					shell.close();
				} catch (Throwable e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			window5.open();
			}
		});
		btnNewButton_3.setFont(SWTResourceManager.getFont(".Helvetica Neue DeskInterface", 18, SWT.NORMAL));
		btnNewButton_3.setBounds(228, 162, 186, 48);
		btnNewButton_3.setText("返回");
		
		Label lblNewLabel_1 = new Label(shell, SWT.NONE);
		lblNewLabel_1.setBounds(36, 178, 371, 48);

	}

}
