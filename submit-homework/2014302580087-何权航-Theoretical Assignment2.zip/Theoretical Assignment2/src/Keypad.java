
public class Keypad
 {
protected int a;
protected boolean b;

// no-argument constructor initializes the Scanner
 public Keypad()
 {

 } // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 {
	 b=false;
	 while(!b){System.out.print("");}
 return a;
  // we assume that user enters an integer
 } // end method getInput
 }