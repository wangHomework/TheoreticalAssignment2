import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.dyno.visual.swing.layouts.Constraints;
import org.dyno.visual.swing.layouts.GroupLayout;
import org.dyno.visual.swing.layouts.Leading;


//VS4E -- DO NOT REMOVE THIS LINE!
public class GUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JTextArea jTextArea0;
	private JScrollPane jScrollPane0;
	public ATM atm;
	String input;
	boolean ip=false;
	public Robot robot;
	private JButton jButton5;
	private JButton jButton6;
	private JButton jButton4;
	private JButton jButton0;
	private JButton jButton1;
	private JButton jButton9;
	private JButton jButton10;
	private JButton jButton3;
	private JButton jButton2;
	private JButton jButton7;
	private JButton jButton8;
	private JButton jButton11;
	private JButton jButton12;
	private JTextArea jTextArea1;
	private JScrollPane jScrollPane1;
	private JTextArea jTextArea2;
	private JScrollPane jScrollPane2;
	public GUI() {
		initComponents();
	}

	private void initComponents() {
		atm=new ATM();
		setLayout(new GroupLayout());
		add(getJScrollPane0(), new Constraints(new Leading(15, 600, 10, 10), new Leading(10, 135, 10, 10)));
		add(getJButton5(), new Constraints(new Leading(111, 10, 10), new Leading(229, 12, 12)));
		add(getJButton6(), new Constraints(new Leading(111, 12, 12), new Leading(277, 12, 12)));
		add(getJButton4(), new Constraints(new Leading(111, 12, 12), new Leading(171, 12, 12)));
		add(getJButton0(), new Constraints(new Leading(40, 10, 10), new Leading(171, 12, 12)));
		add(getJButton1(), new Constraints(new Leading(40, 12, 12), new Leading(229, 12, 12)));
		add(getJButton9(), new Constraints(new Leading(186, 10, 10), new Leading(225, 10, 10)));
		add(getJButton10(), new Constraints(new Leading(188, 10, 10), new Leading(279, 12, 12)));
		add(getJButton3(), new Constraints(new Leading(40, 12, 12), new Leading(277, 12, 12)));
		add(getJButton2(), new Constraints(new Leading(40, 12, 12), new Leading(325, 38, 12, 12)));
		add(getJButton7(), new Constraints(new Leading(111, 118, 12, 12), new Leading(325, 37, 10, 10)));
		add(getJButton8(), new Constraints(new Leading(188, 12, 12), new Leading(171, 12, 12)));
		add(getJScrollPane1(), new Constraints(new Leading(291, 282, 10, 10), new Leading(337, 25, 12, 12)));
		add(getJButton12(), new Constraints(new Leading(291, 281, 12, 12), new Leading(269, 60, 12, 12)));
		add(getJScrollPane2(), new Constraints(new Leading(291, 282, 10, 10), new Leading(237, 25, 12, 12)));
		add(getJButton11(), new Constraints(new Leading(291, 281, 12, 12), new Leading(168, 57, 12, 12)));
		setSize(651, 465);
	}

	private JScrollPane getJScrollPane2() {
		if (jScrollPane2 == null) {
			jScrollPane2 = new JScrollPane();
			jScrollPane2.setViewportView(getJTextArea2());
		}
		return jScrollPane2;
	}

	private JTextArea getJTextArea2() {
		if (jTextArea2 == null) {
			jTextArea2 = new JTextArea();
		}
		return jTextArea2;
	}

	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane();
			jScrollPane1.setViewportView(getJTextArea1());
		}
		return jScrollPane1;
	}

	private JTextArea getJTextArea1() {
		if (jTextArea1 == null) {
			jTextArea1 = new JTextArea();
		}
		return jTextArea1;
	}

	private JButton getJButton12() {
		if (jButton12 == null) {
			jButton12 = new JButton();
			jButton12.setText("Insert deposit envelope here");
		}
		return jButton12;
	}

	private JButton getJButton11() {
		if (jButton11 == null) {
			jButton11 = new JButton();
			jButton11.setText("Take cash here");
		}
		return jButton11;
	}

	private JButton getJButton8() {
		if (jButton8 == null) {
			jButton8 = new JButton();
			jButton8.setText("9");
jButton8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
                       jTextArea0.append("9");
			}
		});
		}
		return jButton8;
	}

	private JButton getJButton7() {
		if (jButton7 == null) {
			jButton7 = new JButton();
			jButton7.setText("ENTER");
jButton7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                    atm.keypad.a=Integer.parseInt(input);
                    atm.keypad.b=true;
					input="";
                    
					}
			});			
		}
		return jButton7;
	}

	private JButton getJButton2() {
		if (jButton2 == null) {
			jButton2 = new JButton();
			jButton2.setText("0");
jButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
                       jTextArea0.append("0");
			}
		});
		}
		return jButton2;
	}

	private JButton getJButton3() {
		if (jButton3 == null) {
			jButton3 = new JButton();
			jButton3.setText("1");
jButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			if(ip==false){
					input="1";
					ip=true;
					jTextArea0.append("1");
					return;
				}
				if(ip==true){
					input=input+"1";
				}
                       jTextArea0.append("1");
			}
		});
		}
		return jButton3;
	}

	private JButton getJButton10() {
		if (jButton10 == null) {
			jButton10 = new JButton();
			jButton10.setText("3");
jButton10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				       if(ip==false){
					input="3";
					ip=true;
				}
				if(ip==true){
					input=input+"3";
				}
                       jTextArea0.append("3");
			}
		});
		}
		return jButton10;
	}

	private JButton getJButton9() {
		if (jButton9 == null) {
			jButton9 = new JButton();
			jButton9.setText("6");
jButton9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
                       jTextArea0.append("6");
			}
		});
		}
		return jButton9;
	}

	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setText("4");
jButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				       if(ip==false){
					input="4";
					ip=true;
				}
				if(ip==true){
					input=input+"4";
				}
                       jTextArea0.append("4");
			}
		});
		}
		return jButton1;
	}

	private JButton getJButton0() {
		if (jButton0 == null) {
			jButton0 = new JButton();
			jButton0.setText("7");
            jButton0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					jTextArea0.append("7");
					return;                     
			}
		});

		}
		return jButton0;
	}

	private JButton getJButton4() {
		if (jButton4 == null) {
			jButton4 = new JButton();
			jButton4.setText("8");
jButton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
                       jTextArea0.append("8");
			}
		});
		}
		return jButton4;
	}

	private JButton getJButton6() {
		if (jButton6 == null) {
			jButton6 = new JButton();
			jButton6.setText("2");
jButton6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				      if(ip==false){
					input="2";
					ip=true;
				}
				if(ip==true){
					input=input+"2";
				}
                       jTextArea0.append("2");
			}
		});
		}
		return jButton6;
	}

	private JButton getJButton5() {
		if (jButton5 == null) {
			jButton5 = new JButton();
			jButton5.setText("5");
jButton5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				       if(ip==false){
					input="5";
					ip=true;
				}
				if(ip==true){
					input=input+"5";
				}
                       jTextArea0.append("5");
			}
		});
		}
		return jButton5;
	}

	private JScrollPane getJScrollPane0() {
		if (jScrollPane0 == null) {
			jScrollPane0 = new JScrollPane();
			jScrollPane0.setViewportView(getJTextArea0());
		}
		return jScrollPane0;
	}

	private JTextArea getJTextArea0() {
		if (jTextArea0 == null) {
			jTextArea0 = new JTextArea();
			//atm=new ATM();
			PrintStream ps=new PrintStream(System.out){
		      public void println(String x) {
		        jTextArea0.append(x + "\n");
		        jTextArea0.setCaretPosition(jTextArea0.getText().length());
		      }
		      public void print(String x){
		    	  jTextArea0.append(x);
		      jTextArea0.setCaretPosition(jTextArea0.getText().length());}
		      
		      public void print(double x){
		    	  jTextArea0.append(String.valueOf(x));
		      jTextArea0.setCaretPosition(jTextArea0.getText().length());}
		      };
			System.setOut(ps);
		}
		return jTextArea0;
	}

}
