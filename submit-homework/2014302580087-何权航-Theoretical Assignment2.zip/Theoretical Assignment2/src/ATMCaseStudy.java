
public class ATMCaseStudy
 {
 // main method creates and runs the ATM
 public static void main( String[] args )
 {
	 GUI gui=new GUI();
	 gui.setVisible(true);
	 gui.atm.run();

 } // end main
 } // end class ATMCaseStudy