  
// Represents the screen of the ATM

public class Screen
 {
// display a message without a carriage return
 public void displayMessage( String message )
 {
 System.out.print( message );
 
 Frame.textArea.append(message);
 
 } // end method displayMessage

 // display a message with a carriage return
 public void displayMessageLine( String message )
 {
 System.out.println( message+"\n" );
 Frame.textArea.append(message);
 } // end method displayMessageLine

 // displays a dollar amount
 public void displayDollarAmount( double amount )
 {
 System.out.printf( "$%,.2f", amount );
 String message=Double.toString(amount);
 Frame.textArea.append(message+"\n");
 } // end method displayDollarAmount
 } // end class Screen