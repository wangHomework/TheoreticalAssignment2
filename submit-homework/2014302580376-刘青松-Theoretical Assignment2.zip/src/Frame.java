import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTextArea;


public class Frame extends JFrame {

	private JPanel contentPane;
	public static JTextArea textArea; 
	public static String showText="";
	public static ATM atm;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
					Frame frame = new Frame();
					frame.setVisible(true);
					atm = new ATM();
					frame.atm.run();
				
	}

	/**
	 * Create the frame.
	 */
	public Frame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 399);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button_4 = new JButton("4");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.append("4");
				showText+="4";
				
				
			}
		});
		button_4.setBounds(10, 216, 60, 38);
		contentPane.add(button_4);
		
		JButton button_5 = new JButton("5");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.append("5");
				showText+="5";
			}
		});
		
		button_5.setBounds(80, 216, 60, 38);
		contentPane.add(button_5);
		
		JButton button_6 = new JButton("6");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.append("6");
				showText+="6";
			}
		});
		button_6.setBounds(149, 216, 60, 38);
		contentPane.add(button_6);
		
		JButton button_1 = new JButton("1");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.append("1");
				showText+="1";
			}
		});
		button_1.setBounds(10, 264, 60, 38);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("2");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.append("2");
				showText+="2";
			}
		});
		button_2.setBounds(80, 264, 60, 38);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("3");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.append("3");
				showText+="3";
			}
		});
		button_3.setBounds(149, 264, 60, 38);
		contentPane.add(button_3);
		
		JButton button_0 = new JButton("0");
		button_0.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			
			}
		});
		button_0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.append("0");
				showText+="0";
			}
		});
		button_0.setBounds(10, 312, 60, 38);
		contentPane.add(button_0);
		
		JButton button_back = new JButton("\u540E\u9000");
		button_back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		button_back.setBounds(80, 312, 60, 38);
		contentPane.add(button_back);
		
		JButton button_enter = new JButton("\u786E\u8BA4");
		button_enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				atm.keypad.number=Integer.parseInt(showText);
				atm.keypad.bl=true;
				showText="";
			}
		});
		button_enter.setBounds(149, 312, 60, 38);
		contentPane.add(button_enter);
		
		JButton button_7 = new JButton("7");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.append("7");
				showText+="7";
			}
		});
		button_7.setBounds(10, 168, 60, 38);
		contentPane.add(button_7);
		
		JButton button_8 = new JButton("8");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.append("8");
				showText+="8";
			}
		});
		button_8.setBounds(80, 168, 60, 38);
		contentPane.add(button_8);
		
		JButton button_9 = new JButton("9");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.append("9");
				showText+="9";
			}
		});
		button_9.setBounds(149, 168, 60, 38);
		contentPane.add(button_9);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 30, 414, 109);
		contentPane.add(scrollPane);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
	}
}
