import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad
 {
 // reads data from the command line
// no-argument constructor initializes the Scanner
public int getInt;
public int lalala=0;
/* public Keypad()
 {
 
 } // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 {
	 lalala=0;
	 if(lalala!=0){
		
	 	
	 	 return getInt;
	 	}
	 else{
		 Frame.textArea.append("\n�����˺������ʽ����");
		 return 0;
		 }
	 

	// we assume that user enters an integer
 } // end method getInput
 */

 public  int number;
	public boolean bl=false;
	public Keypad(){
	}
	public int getInput(){
		bl=false;
		 while(!bl){System.out.print("");}
		return number;
	}

 }