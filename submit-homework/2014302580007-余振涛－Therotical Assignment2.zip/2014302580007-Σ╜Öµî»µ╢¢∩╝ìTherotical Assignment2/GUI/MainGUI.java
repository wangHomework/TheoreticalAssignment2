package com.yuzhentao.GUI;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.PrintStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import com.yuzhentao.data.ATM;


public class MainGUI extends JFrame{
	private static final long serialVersionUID = -1254937559106371596L;
	private GridLayout mainLayout =null;
	private GridLayout buttomLayout=null;
	public JTextArea textArea =null;
	private JPanel panel_btn=null;
	private PrintStream printStream= null;
	private ATM atm =null;
	private JButton btn_grop[]=null;
	private JButton btn_ok =null;
	private String input=null; 

	public MainGUI() {
		atm = new ATM();
		mainLayout = new GridLayout(2, 1);
		buttomLayout = new GridLayout(4,3);

		this.setLayout(mainLayout);


		init_btn();
		init_panel();
		registListener();
		this.setSize(1000,600);
		this.setResizable(false);
		this.setVisible(true);

	}

	public void init(){
		input = new String();
		printStream = new PrintStream(System.out){
			public void println(String x) {
				textArea.append(x + "\n");
				textArea.setCaretPosition(textArea.getText().length());
			}
			public void print(String x){
				textArea.append(x);
				textArea.setCaretPosition(textArea.getText().length());}

			public void print(double x){
				textArea.append(String.valueOf(x));
				textArea.setCaretPosition(textArea.getText().length());}
		};
		System.setOut(printStream);
		atm.run();
	}

	private void init_panel(){


		textArea = new JTextArea();
		JScrollPane scroll = new JScrollPane(textArea);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		textArea.setAutoscrolls(true);
		textArea.setLineWrap(true);
		textArea.setBounds(0, 0, 400,300);
		this.add(scroll);

		this.add(panel_btn);
	}




	private void init_btn(){
		panel_btn = new JPanel();
		panel_btn.setLayout(buttomLayout);


		btn_grop=new JButton[10];
		for(int i=0;i<10;i++){
			btn_grop[i]=new JButton(i+"");
			panel_btn.add(btn_grop[i]);
		}
		btn_ok=new JButton("确认");
		panel_btn.add(btn_ok);


	}

	private void registListener(){
		BtnListener btnlistener = new BtnListener();
		MyKeyListener keyListener =new MyKeyListener();
		for(int i=0;i<10;i++){
			btn_grop[i].addActionListener(btnlistener);
		}
		btn_ok.addActionListener(btnlistener);
		textArea.addKeyListener(keyListener);
	}

	class MyKeyListener extends KeyAdapter{
		@Override
		public void keyTyped(KeyEvent e) {
			e.consume();
		}
	}


	class BtnListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			Object obj=e.getSource();
			for(int i=0;i<10;i++){
				if(obj==btn_grop[i]){
					System.out.print(i+"");
					input+=i;
					
				}
			}
			if(obj==btn_ok){
				if(input.equals(""))return;
				int in=Integer.valueOf(input).intValue();
				atm.keypad.setInput(in);
				atm.keypad.loop=false;
				input=new String();
			}
		}

	}





}
