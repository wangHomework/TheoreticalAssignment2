package com.yuzhentao.data;

public abstract class MyThread extends Thread {  

	private boolean suspend = false;  

	private String control = ""; 

	public void setSuspend(boolean suspend) {  
		if (!suspend) {  
			synchronized (control) {  
				control.notifyAll();
			}  
		}  
		this.suspend = suspend;  
	}  

	public boolean isSuspend() {  
		return this.suspend;  
	}  

	public void run() {  
		while (true) {  
			synchronized (control) {  
				if (suspend) {  
					try {  
						control.wait();  
					} catch (InterruptedException e) {  
						e.printStackTrace();  
					}  
				}  
			}  
			this.runPersonelLogic();  
		}  
	}  

	protected abstract void runPersonelLogic();

}
