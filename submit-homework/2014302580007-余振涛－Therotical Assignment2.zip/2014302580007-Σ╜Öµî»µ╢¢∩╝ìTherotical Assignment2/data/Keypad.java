package com.yuzhentao.data;
 // program uses Scanner to obtain user input
public class Keypad
{
	public boolean loop=true;
	private int input;
	//private Scanner input; // reads data from the command line
	// no-argument constructor initializes the Scanner
	public Keypad()
	{
		//input = new Scanner( System.in );
	} // end no-argument Keypad constructor

	// return an integer value entered by user
	public int getInput()
	{
		while(loop){
			System.out.print("");
		};
		 // we assume that user enters an integer
		loop=true;
		return input;
	} // end method getInput
	
	public void setloop(boolean loop){
		this.loop=loop;
	}
	
	public void setInput(int input){
		this.input=input;
	}

}