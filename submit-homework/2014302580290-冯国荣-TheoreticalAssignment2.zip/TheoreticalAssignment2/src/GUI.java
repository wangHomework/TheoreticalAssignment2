import java.awt.Color;
import java.awt.Image;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class GUI  {
	public ATM atm;
	public JTextArea textarea= new JTextArea();
	private JScrollPane scroll = new JScrollPane(textarea);
	private PrintStream output;
	public String input;	
	private boolean bool;
	private JButton btn0;
	private JButton btn1;
	private JButton btn2;
	private JButton btn3;
	private JButton btn4;
	private JButton btn5;
	private JButton btn6;
	private JButton btn7;
	private JButton btn8;
	private JButton btn9;
	private JButton btnqueren;
	private JButton btntuichu;
	private JFrame con;
	
	 public GUI(){
	// ��¼����
		
		atm = new ATM();
		//��������	
	     	con=new JFrame("ATM");
			con.setBounds(500, 400, 600, 350);
			con.setBackground(Color.blue);
			con.setLayout(null);
			
		//���ּ�ȷ����ť
			btn0=new JButton("0");
			btn1=new JButton("1");
			btn2=new JButton("2");
			btn3=new JButton("3");
			btn4=new JButton("4");
			btn5=new JButton("5");
			btn6=new JButton("6");
			btn7=new JButton("7");
			btn8=new JButton("8");
			btn9=new JButton("9");
			btnqueren=new JButton("ȷ��");
			btntuichu=new JButton("�˳�");
			con.add(btn0);
			con.add(btn1);
			con.add(btn2);
			con.add(btn3);
			con.add(btn4);
			con.add(btn5);
			con.add(btn6);
			con.add(btn7);
			con.add(btn8);
			con.add(btn9);
			con.add(btnqueren);
			con.add(btntuichu);
			btn1.setBounds(10,110,50,25);
			btn2.setBounds(80, 110, 50, 25);
			btn3.setBounds(150, 110, 50, 25);
			btn4.setBounds(10, 150, 50, 25);
			btn5.setBounds(80, 150, 50, 25);
			btn6.setBounds(150, 150, 50, 25);
			btn7.setBounds(10, 190, 50, 25);
			btn8.setBounds(80, 190, 50, 25);
			btn9.setBounds(150, 190, 50, 25);
			btn0.setBounds(10, 230, 50, 25);
			btnqueren.setBounds(80, 230, 70, 25);
			btntuichu.setBounds(150,230,70,25);
			btn1.setForeground(Color.green);
			btn2.setForeground(Color.green);
			btn3.setForeground(Color.green);
			btn4.setForeground(Color.green);
			btn5.setForeground(Color.green);
			btn6.setForeground(Color.green);
			btn7.setForeground(Color.green);
			btn8.setForeground(Color.green);
			btn9.setForeground(Color.green);
			btn0.setForeground(Color.green);
			btnqueren.setForeground(Color.red);
			btntuichu.setForeground(Color.red);
			
			
		//�˻�����������				
			final TextArea ta=new TextArea(10,40);
			ta.setText("Welcome to the ATM!");		
			ta.setEditable(false);//�����ı��򲻿ɱ��༭
			con.add(ta);
			ta.setBounds(250,110,300,150);
			
		//����һ������
			con.add(scroll);
			scroll.setBounds(250, 110, 300, 150);
			scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			
			
		//�԰�ť���Ӽ����¼���ʵ�ֲ���
			//��ť1
			btn1.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"1");
					get_input("1");
				
				}
			});
			//��ť2
			btn2.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"2");
					get_input("2");
					
				}
			});
			//��ť3
			btn3.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"3");
					get_input("3");
					
				}
			});
			///��ť4
			btn4.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"4");
					get_input("4");
					
				}
			});
			//��ť5
			btn5.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"5");
					get_input("5");
					
				}
			});
			//��ť6
			btn6.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"6");
					get_input("6");
				
				}
			});
			//��ť7
			btn7.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"7");
					get_input("7");
					
				}
			});
			//��ť8
			btn8.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"8");
					get_input("8");
				
				}
			});
			//��ť9
			btn9.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"9");
					get_input("9");
					
				}
			});
			//��ť0
			btn0.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"0");
					get_input("0");
				
				}
			});
			//enter��ť
			btnqueren.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
				 //�ж��Ƿ�����ֵ					 
					if (input.length() > 0) {
						atm.keypad.num = Integer.parseInt(input);
					    atm.keypad.b = true;
					    input = "";
					}
				}
			});
			btntuichu.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					
						System.exit(0);
				
				}
			});
			//����˵���Ϣ
			output = new PrintStream(System.out){
				public void println(String str) {
					ta.append(str + '\n');
				}
				public void print(String str) {
					ta.append(str);
				}
				public void println(double d) {
					ta.append(String.valueOf(d));
				}
			};
			System.setOut(output);
		    
			con.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			con.setVisible(true);
}
	//��ȡ����ֵ
	private void get_input(String i) {
		if (bool==false) {
			input = i;
			bool = true;
		}else {
			input = input + i;
		}
		//��JTextArea����ʾ����ֵ
		textarea.append(i);
	}

	}




