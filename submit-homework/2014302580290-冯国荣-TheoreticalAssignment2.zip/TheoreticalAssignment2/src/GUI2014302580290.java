
public class GUI2014302580290 {
	

		public static void main(String[] args) {
			GUI gui = new GUI();
		
			 gui.atm.run();
		
			
		}

	


}
