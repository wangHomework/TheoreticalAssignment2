package com.ATMGUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;


import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Dimension;
import java.awt.Component;
import javax.swing.border.BevelBorder;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Scanner;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JScrollPane;

public class ATMGUI extends JFrame {
	private JPanel contentPane;
	
	private Scanner input;
    
	public String AccountMessage = "";
	public JTextArea textArea = new JTextArea();
	public JTextField textField = new JTextField();
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */

	public ATMGUI() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setSize(new Dimension(14, 30));
		contentPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		textArea.setEditable(false);
		textField.setToolTipText("Please do use the buttons!");
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 414, 80);
		contentPane.add(scrollPane);
		
		//JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);

		
		
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.append(textField.getText());
				
			}
		});
		scrollPane.setRowHeaderView(textField);
		textField.setColumns(10);

		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, new Color(64, 224, 208), null, new Color(0, 128, 128), null));
		panel_1.setBounds(10, 94, 170, 158);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JButton button_2 = new JButton("1");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button_2.setIcon(null);
		button_2.setBackground(new Color(64, 224, 208));
		button_2.setForeground(new Color(0, 139, 139));
		button_2.setFont(new Font("Vijaya", Font.BOLD, 20));
		button_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				textArea.append("1");
			}
		});
		button_2.setMargin(new Insets(1, 8, 1, 8));
		button_2.setBounds(21, 10, 35, 28);
		panel_1.add(button_2);
		
		JButton button_10 = new JButton("2");
		button_10.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				textArea.append("2");
			}
		});
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		button_10.setMargin(new Insets(1, 8, 1, 8));
		button_10.setForeground(new Color(0, 139, 139));
		button_10.setFont(new Font("Vijaya", Font.BOLD, 20));
		button_10.setBackground(new Color(64, 224, 208));
		button_10.setBounds(66, 10, 35, 28);
		panel_1.add(button_10);
		
		JButton button_3 = new JButton("3");
		button_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea.append("3");
			}
		});
		button_3.setMargin(new Insets(1, 8, 1, 8));
		button_3.setForeground(new Color(0, 139, 139));
		button_3.setFont(new Font("Vijaya", Font.BOLD, 20));
		button_3.setBackground(new Color(64, 224, 208));
		button_3.setBounds(111, 10, 35, 28);
		panel_1.add(button_3);
		
		JButton button_7 = new JButton("6");
		button_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea.append("6");
			}
		});
		button_7.setMargin(new Insets(1, 8, 1, 8));
		button_7.setForeground(new Color(0, 139, 139));
		button_7.setFont(new Font("Vijaya", Font.BOLD, 20));
		button_7.setBackground(new Color(64, 224, 208));
		button_7.setBounds(111, 48, 35, 28);
		panel_1.add(button_7);
		
		JButton button_4 = new JButton("5");
		button_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea.append("5");
			}
		});
		button_4.setMargin(new Insets(1, 8, 1, 8));
		button_4.setForeground(new Color(0, 139, 139));
		button_4.setFont(new Font("Vijaya", Font.BOLD, 20));
		button_4.setBackground(new Color(64, 224, 208));
		button_4.setBounds(66, 48, 35, 28);
		panel_1.add(button_4);
		
		JButton button_1 = new JButton("4");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea.append("4");
			}
		});
		button_1.setMargin(new Insets(1, 8, 1, 8));
		button_1.setForeground(new Color(0, 139, 139));
		button_1.setFont(new Font("Vijaya", Font.BOLD, 20));
		button_1.setBackground(new Color(64, 224, 208));
		button_1.setBounds(21, 48, 35, 28);
		panel_1.add(button_1);
		
		JButton button = new JButton("7");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea.append("7");
			}
		});
		button.setMargin(new Insets(1, 8, 1, 8));
		button.setForeground(new Color(0, 139, 139));
		button.setFont(new Font("Vijaya", Font.BOLD, 20));
		button.setBackground(new Color(64, 224, 208));
		button.setBounds(21, 86, 35, 28);
		panel_1.add(button);
		
		JButton button_5 = new JButton("8");
		button_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea.append("8");
			}
		});
		button_5.setMargin(new Insets(1, 8, 1, 8));
		button_5.setForeground(new Color(0, 139, 139));
		button_5.setFont(new Font("Vijaya", Font.BOLD, 20));
		button_5.setBackground(new Color(64, 224, 208));
		button_5.setBounds(66, 86, 35, 28);
		panel_1.add(button_5);
		
		JButton button_6 = new JButton("9");
		button_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea.append("9");
			}
		});
		button_6.setMargin(new Insets(1, 8, 1, 8));
		button_6.setForeground(new Color(0, 139, 139));
		button_6.setFont(new Font("Vijaya", Font.BOLD, 20));
		button_6.setBackground(new Color(64, 224, 208));
		button_6.setBounds(111, 86, 35, 28);
		panel_1.add(button_6);
		
		JButton button_8 = new JButton("0");
		button_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea.append("0");
			}
		});
		button_8.setMargin(new Insets(1, 8, 1, 8));
		button_8.setForeground(new Color(0, 139, 139));
		button_8.setFont(new Font("Vijaya", Font.BOLD, 20));
		button_8.setBackground(new Color(64, 224, 208));
		button_8.setBounds(21, 120, 35, 28);
		panel_1.add(button_8);
		
		JButton btnEnter = new JButton("Enter");
		btnEnter.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO 锟皆讹拷锟斤拷锟缴的凤拷锟斤拷锟斤拷锟�
				AccountMessage = textField.getText();
				textArea.append(textField.getText());
				textArea.append("\n");
				textField.setText("");
			}
		});
		
		btnEnter.setMargin(new Insets(1, 8, 1, 8));
		btnEnter.setForeground(new Color(0, 139, 139));
		btnEnter.setFont(new Font("Vijaya", Font.BOLD, 20));
		btnEnter.setBackground(new Color(64, 224, 208));
		btnEnter.setBounds(66, 120, 80, 28);
		panel_1.add(btnEnter);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 139, 139), 4, true));
		panel_2.setBounds(190, 94, 234, 74);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblTakeCashHere = new JLabel("Take cash here ");
		lblTakeCashHere.setForeground(new Color(0, 128, 128));
		lblTakeCashHere.setFont(new Font("Vrinda", Font.BOLD | Font.ITALIC, 15));
		lblTakeCashHere.setHorizontalAlignment(SwingConstants.CENTER);
		lblTakeCashHere.setBounds(10, 10, 214, 26);
		panel_2.add(lblTakeCashHere);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 128, 128), 4, true));
		panel_3.setBounds(190, 178, 234, 74);
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblInsertDepositEnvelope = new JLabel("Insert deposit envelope here");
		lblInsertDepositEnvelope.setFont(new Font("Vrinda", Font.BOLD | Font.ITALIC, 15));
		lblInsertDepositEnvelope.setHorizontalAlignment(SwingConstants.CENTER);
		lblInsertDepositEnvelope.setForeground(new Color(0, 139, 139));
		lblInsertDepositEnvelope.setBounds(10, 10, 214, 26);
		panel_3.add(lblInsertDepositEnvelope);
		
		
			}
}
