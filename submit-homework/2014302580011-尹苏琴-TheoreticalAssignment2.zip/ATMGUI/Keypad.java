package com.ATMGUI;

import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad
 {
 private ATMGUI atmgui;
 private Scanner input; // reads data from the command line
// no-argument constructor initializes the Scanner
 public Keypad()
 {
 input = new Scanner( System.in);
 } // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 {
  ATM.frame.AccountMessage = "";
  while (ATM.frame.AccountMessage.equals("")){
   try {
    Thread.sleep(1);
   }catch (Exception e){e.printStackTrace();}
  }
  int i = Integer.parseInt(ATM.frame.AccountMessage);
  return i;
 //return input.nextInt(); // we assume that user enters an integer
 } // end method getInput
 }