package com.ATMGUI;

//Represents the screen of the ATM


public class Screen
{
	//private ATMGUI atmgui;
//display a message without a carriage return
public void displayMessage( String message )
{
	ATM.frame.textArea.append(message);
} // end method displayMessage

// display a message with a carriage return
public void displayMessageLine( String message )
{
	ATM.frame.textArea.append(message);
	ATM.frame.textArea.append("\n");
} // end method displayMessageLine

// displays a dollar amount
public void displayDollarAmount( double amount )
{
	String s = Double.toString(amount);
	ATM.frame.textArea.append(s);
} // end method displayDollarAmount
} // end class Screen
