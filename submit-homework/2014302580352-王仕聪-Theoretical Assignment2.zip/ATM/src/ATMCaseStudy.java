import java.io.IOException;

public class ATMCaseStudy
 {
 // main method creates and runs the ATM
 public static void main( String[] args ) throws IOException, InterruptedException
 {
	
  MainGui x=new MainGui();
 
 } // end main
 } // end class ATMCaseStudy