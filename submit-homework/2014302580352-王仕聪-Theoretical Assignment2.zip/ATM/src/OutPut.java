import java.io.IOException;

public class OutPut {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
      MainGui x=new MainGui();
      
	}

}
