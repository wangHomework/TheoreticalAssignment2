import java.util.Scanner; // program uses Scanner to obtain user input

import javax.swing.JTextArea;
public class Keypad
 {
	private int num;
    private JTextArea input;; // reads data from the command line
// no-argument constructor initializes the Scanner
 public Keypad(JTextArea input_)
 {
	 input = input_;
 } // end no-argument Keypad constructor

 // return an integer value entered by user
 public void input(int inputNum)
 {
     num = num * 10 + inputNum;
     input.append(String.format("%d", inputNum));
     input.setCaretPosition(input.getText().length());
 }

 public int getInput() throws InterruptedException
 {
	 
	 synchronized(this)
     {
         wait();
     }
     int tmp = num;
     num = 0;
     input.append("");
     return tmp;// we assume that user enters an integer
 } // end method getInput
 }