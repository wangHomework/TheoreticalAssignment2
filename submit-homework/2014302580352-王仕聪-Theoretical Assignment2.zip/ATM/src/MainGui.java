import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.KeyStroke;
import javax.swing.ScrollPaneConstants;
import javax.swing.WindowConstants;
public class MainGui  extends JFrame implements ActionListener{
	private JPanel p;
	private JPanel top;
	private JPanel left;
	private JPanel righttop;
	private JPanel rightbottom;
	private JButton k1 ;
	private JButton k2 ;
	private JButton k3 ;
	private JButton k4 ;
	private JButton k5 ;
	private JButton k6 ;
	private JButton k7 ;
	private JButton k8 ;
	private JButton k9 ;
	private JButton k0 ;
	private JButton enter ;
	private JButton end;
	public JTextArea screen;
	private ATM theATM;
    private Screen output;
    private Keypad keypad;
	private LoopedStreams loop;
	MainGui() throws IOException, InterruptedException {
		super("I have no money");
		
		p=new JPanel();//�ܻ���
		top=new JPanel();//����Ļ���
		left=new JPanel();

		righttop=new JPanel();
		rightbottom=new JPanel();

		screen=new JTextArea();
        screen.setLineWrap(true);
        screen.setOpaque(true);
        screen.setEditable(false);
        
        JScrollPane panel = new JScrollPane(screen,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        panel.setBounds(0, 0, 800, 200);



		k1=new JButton("1");
		k2=new JButton("2");
		k3=new JButton("3");
		k4=new JButton("4");
		k5=new JButton("5");
		k6=new JButton("6");
		k7=new JButton("7");
		k8=new JButton("8");
		k9=new JButton("9");
		k0=new JButton("0");
		enter=new JButton("Enter");
		end=new JButton("����û��");

		left.add(k1);
		left.add(k2);
		left.add(k3);
		left.add(k4);
		left.add(k5);
		left.add(k6);
		left.add(k7);
		left.add(k8);
		left.add(k9);
		left.add(k0);
		left.add(enter);
		left.add(end);

		top.add(panel);
		Color a=new Color(170,150,244);
		screen.setBackground(a);
		//righttop.setBackground(Color.red);
		//rightbottom.setBackground(Color.yellow);
		Icon icon1=new ImageIcon("img/1.jpg");  
		JLabel x1=new JLabel();
		x1.setIcon(icon1);
		Icon icon2=new ImageIcon("img/2.jpg");  
		JLabel x2=new JLabel();
		x2.setIcon(icon2);
        righttop.add(x1);
        rightbottom.add(x2);

		k1.addActionListener(this) ;//��ť�¼�����
		k2.addActionListener(this) ;//��ť�¼�����
		k3.addActionListener(this) ;//��ť�¼�����
		k4.addActionListener(this) ;//��ť�¼�����
		k5.addActionListener(this) ;//��ť�¼�����
		k6.addActionListener(this) ;//��ť�¼�����
		k7.addActionListener(this) ;//��ť�¼�����
		k8.addActionListener(this) ;//��ť�¼�����
		k9.addActionListener(this) ;//��ť�¼�����
		k0.addActionListener(this) ;//��ť�¼�����
		enter.addActionListener(this) ;//��ť�¼�����

		//���ÿ�ݼ�  
		//loop=new LoopedStreams(System.out,screen);
		//System.setOut(loop);
		//System.setErr(loop);

		//����

		this.add(p);
		p.setLayout(null);
		p.add(top);
		p.add(left);
		p.add(righttop);
		p.add(rightbottom);
		top.setBounds(0, 0, 800, 200);
		top.setLayout(null);
		screen.setBounds(0, 0, 800, 200);
		left.setBounds(0, 200, 300, 370);
		righttop.setBounds(310, 200, 480, 170);
		rightbottom.setBounds(310, 380, 480, 190);

		left.setLayout(new GridLayout(4, 3));// �������С��У�

		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		this.setVisible(true);//�ɼ�
		this.setBounds(0,0,800,600);//����ATM������Ĵ�С
		this.setResizable(false);//�����޸Ĵ�С
		
        keypad=new Keypad(screen);
	    output=new Screen(screen);
		theATM = new ATM(output,keypad);
		theATM.run();

	}
	//��дActionListener�ӿ��е��¼���������

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == k1){
			keypad.input(1);
		}
		else if(e.getSource() == k2){
			keypad.input(2);

		}
		else if(e.getSource() == k3){
			keypad.input(3);

		}
		else if(e.getSource() == k4){
			keypad.input(4);

		}
		else if(e.getSource() == k5){
			keypad.input(5);

		}
		else if(e.getSource() == k6){
			keypad.input(6);;

		}
		else if(e.getSource() == k7){
			keypad.input(7);

		}
		else if(e.getSource() == k8){
			keypad.input(8);

		}
		else if(e.getSource() == k9){
			keypad.input(9);

		}
		else if(e.getSource() == k0){
			keypad.input(0);

		}
		else if(e.getSource() == enter){
			synchronized (keypad) {
                keypad.notify();
            }
		}
		else{
			return;
		}
	}

}

