
// û����Screen��Keypad�࣬������������ATM���������д��

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.BevelBorder;


public class MainGUI2012300070048 extends JFrame{
	
	// ȷ����Ļ�����̺ʹ桢ȡ��ڵĳ��ȺͿ���
	private static final int SCREENWIDTH = 700;
	private static final int SCREENHEIGHT = 300;
	private static final int KEYPADHEIGHT = 300;
	private static final int KEYPADWIDTH = 250;
	private static final int CASHWIDTH = 450;
	private static final int CASHHEIGHT = 300;
	
	
	private JPanel screenPanelL;
	private JPanel keypadPanelL;
	private JPanel cashPanelL;
	private JTextArea screenL;
	private JButton[] number;		// ���̰���
	private JLabel cashInL;
	private JLabel cashOutL;
	private JLabel postScriptL;		// ���½ǵı�ע
	
	private boolean enterClickL;	// ���"Enter"
	
	public MainGUI2012300070048() {
		super("ATM");
		setLayout(null);
		enterClickL = false;
		
		// ���ô�����Ļ�����
		screenPanelL = new JPanel();
		screenPanelL.setLayout(null);
		screenPanelL.setBounds(0, 0, SCREENWIDTH, SCREENHEIGHT);
		add(screenPanelL);	
		screenL = new JTextArea();
		screenL.setBounds(0,0,SCREENWIDTH,SCREENHEIGHT);
		screenPanelL.add(screenL);
		
		// ���ô������̵����
		keypadPanelL = new JPanel();
		keypadPanelL.setBounds(0, SCREENHEIGHT, KEYPADWIDTH, KEYPADHEIGHT);
		keypadPanelL.setLayout(new GridLayout(4,0));
		add(keypadPanelL);
		number = new JButton[12];
		for (int i = 1; i < 10 ; i++) {
			number[i] = new JButton(Integer.toString(i));
			keypadPanelL.add(number[i]);
		}
		number[0] = new JButton("0");
		keypadPanelL.add(number[0]);
		number[10] = new JButton("Clear");
		keypadPanelL.add(number[10]);
		number[11] = new JButton("Enter");
		keypadPanelL.add(number[11]);
		
		ButtonHandlerL handlerL = new ButtonHandlerL();
		for (int i = 0; i < 12; i++) 
			number[i].addActionListener(handlerL);
		
		// ���ô����桢ȡ��ڵ����
		cashPanelL = new JPanel();
		cashPanelL.setBounds(KEYPADWIDTH, SCREENHEIGHT, CASHWIDTH, CASHHEIGHT);
		cashPanelL.setLayout(null);
		add(cashPanelL);
		cashInL = new JLabel("Cash in", JLabel.CENTER);
		cashInL.setBounds(50, 50, 300, 50);
		cashInL.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		cashOutL = new JLabel("Cash out", JLabel.CENTER);
		cashOutL.setBounds(50, 150, 300, 50);
		cashOutL.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		cashPanelL.add(cashInL);
		cashPanelL.add(cashOutL);		
		postScriptL = new JLabel("Clear���������������");
		postScriptL.setBounds(50, 250, 300, 50);
		cashPanelL.add(postScriptL);
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(SCREENWIDTH,650);
		setVisible(true);
	
	}
	
	private class ButtonHandlerL implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			if (event.getActionCommand() == "Enter") {
				enterClickL = true;
			}
			
			else if (event.getActionCommand() == "Clear") {
				String message = screenL.getText();
				int endIdxL = message.lastIndexOf(":") + 2;
				String inputL = message.substring(0, endIdxL);
				screenL.setText(inputL);
			}
				
			else {
				int numberPressL = Integer.parseInt(event.getActionCommand());
				if (numberPressL >= 0 || numberPressL <= 9)
					displayMessage(event.getActionCommand());
			}
		}
	}
	
	// ��ͣ����Enter��������������
	private void waitForClick() {
		while(true){
			if (enterClickL) {
				break;
			}
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	// ����
	public void clearScreenL() {
		screenL.setText(null);
	}
	
	// ����Ļ�����
	public void displayMessage(String message) {
		message = screenL.getText() + message; 
		screenL.setText(message);
	}
	
	// ����Ļ�����������
	public void displayMessageLine(String message) {
		message = screenL.getText() + message + "\n"; 
		screenL.setText(message);
	}
	
	// ����Ļ���������
	public void displayDollarAmount(double amount) {
		String amountL = String.valueOf(amount);
		amountL = screenL.getText() + amountL; 
		screenL.setText(amountL);
	}
	
	// �õ��û����������
	public int getInput() {
		waitForClick();
		String inputL = screenL.getText();
		int startIdxL = inputL.lastIndexOf(":") + 2;
		inputL = inputL.substring(startIdxL);
		int returnValue = Integer.parseInt(inputL);
		enterClickL = false;
		return returnValue;
	}
}
