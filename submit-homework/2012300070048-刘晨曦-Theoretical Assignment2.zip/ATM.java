public class ATM {
	private boolean userAuthenticated; // whether user is authenticated
	private int currentAccountNumber; // current user's account number
    private MainGUI2012300070048 machine;
	private CashDispenser cashDispenser; // ATM's cash dispenser
	private DepositSlot depositSlot; // ATM's deposit slot
	private BankDatabase bankDatabase; // account information database
	// constants corresponding to main menu options
	private static final int BALANCE_INQUIRY = 1;
	private static final int WITHDRAWAL = 2;
	private static final int DEPOSIT = 3;
	private static final int EXIT = 4;

	// no-argument ATM constructor initializes instance variables
	public ATM() {
		userAuthenticated = false; // user is not authenticated to start
		currentAccountNumber = 0; // no current account number to start
		cashDispenser = new CashDispenser(); // create cash dispenser
		depositSlot = new DepositSlot(); // create deposit slot
		bankDatabase = new BankDatabase(); // create acct info database
		machine = new MainGUI2012300070048();
	} // end no-argument ATM constructor
		// start ATM

	public void run() {
		// welcome and authenticate user; perform transactions
		while (true) {
			// loop while user is not yet authenticated
			while (!userAuthenticated) {
				machine.displayMessageLine("Welcome");
				authenticateUser(); // authenticate user
			} // end while
			machine.clearScreenL();
			performTransactions(); // user is now authenticated
			userAuthenticated = false; // reset before next ATM session
			currentAccountNumber = 0; // reset before next ATM session
			machine.displayMessageLine("\nThank you! Goodbye!");
			machine.clearScreenL();
		} // end while
	} // end method run

	// attempts to authenticate user against database
	private void authenticateUser() {
		machine.displayMessage("\nPlease enter your account number: ");
		
		int accountNumber = machine.getInput(); // input account number
		machine.displayMessage("\nEnter your PIN: "); // prompt for PIN
		int pin = machine.getInput(); // input PIN
		// set userAuthenticated to boolean value returned by database
		userAuthenticated = bankDatabase.authenticateUser(accountNumber, pin);

		// check whether authentication succeeded
		if (userAuthenticated) {
			currentAccountNumber = accountNumber; // save user's account #
		} // end if
		else {
			machine.displayMessageLine("\nInvalid account number or PIN. Please try again.");
		}
			
	} // end method authenticateUser

	// display the main menu and perform transactions
	private void performTransactions() {
		// local variable to store transaction currently being processed
		Transaction currentTransaction = null;
		boolean userExited = false; // user has not chosen to exit
		// loop while user has not chosen option to exit system
		while (!userExited) {
			// show main menu and get user selection
			int mainMenuSelection = displayMainMenu();
			machine.clearScreenL();
			// decide how to proceed based on user's menu selection
			switch (mainMenuSelection) {
			// user chose to perform one of three transaction types
			case BALANCE_INQUIRY:
			case WITHDRAWAL:
			case DEPOSIT:
				// initialize as new object of chosen type
				currentTransaction = createTransaction(mainMenuSelection);
				currentTransaction.execute(); // execute transaction
				break;
			case EXIT: // user chose to terminate session
				machine.displayMessageLine("\nExiting the system...");
				userExited = true; // this ATM session should end
				break;
			default: // user did not enter an integer from 1-4
				machine.displayMessageLine("\nYou did not enter a valid selection. Try again.");
				break;
			} // end switch
		} // end while
	} // end method performTransactions

	// display the main menu and return an input selection
	private int displayMainMenu() {
		machine.displayMessageLine("\nMain menu:");
		machine.displayMessageLine("1 - View my balance");
		machine.displayMessageLine("2 - Withdraw cash");
		machine.displayMessageLine("3 - Deposit funds");
		machine.displayMessageLine("4 - Exit\n");
		machine.displayMessage("Enter a choice: ");
		return machine.getInput(); // return user's selection
	} // end method displayMainMenu

	// return object of specified Transaction subclass
	private Transaction createTransaction(int type) {
		Transaction temp = null; // temporary Transaction variable
		switch (type) {
		case BALANCE_INQUIRY: // create new BalanceInquiry transaction
			temp = new BalanceInquiry(currentAccountNumber, machine, bankDatabase);
			break;
		case WITHDRAWAL: // create new Withdrawal transaction
			temp = new Withdrawal(currentAccountNumber, machine, bankDatabase, cashDispenser);
			break;
		case DEPOSIT: // create new Deposit transaction
			temp = new Deposit(currentAccountNumber, machine, bankDatabase, depositSlot);
			break;
		} // end switch

		return temp; // return the newly created object
	} // end method createTransaction
}
