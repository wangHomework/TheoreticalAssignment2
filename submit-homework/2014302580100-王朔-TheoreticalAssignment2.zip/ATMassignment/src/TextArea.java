import java.awt.EventQueue;

import javax.swing.JFrame;

public class TextArea {

	public static void main(String[] args) {
		TextAreaFrame textAreaFrame=new TextAreaFrame();
		textAreaFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		textAreaFrame.setSize(300,300);
		textAreaFrame.setVisible(true);
		textAreaFrame.getATM().run();
	}

}
