import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad
 {
	private boolean endInput;
	 private int input; // reads data from the command line
	// no-argument constructor initializes the Scanner
//	 public Keypad()
//	 {
//	 input = new Scanner( System.in );
//	 } // end no-argument Keypad constructor

	 public boolean isEndInput()
	 {
			return endInput;
	 }
		
	 // return an integer value entered by user
	 public int getInput()
	 {
		 this.setEndInput(false);
			while(!endInput){
				System.out.print("");
			}
		return input; // we assume that user enters an integer
	 } // end method getInput

	public void setInput(int input) {
		this.input=input;
	}

	public void setEndInput(boolean endInput) {
		this.endInput=endInput;
	}
 }