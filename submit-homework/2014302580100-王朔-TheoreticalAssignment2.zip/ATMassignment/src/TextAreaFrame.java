import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import com.ibm.icu.impl.TimeZoneGenericNames.Pattern;

public class TextAreaFrame extends JFrame
{
	private JPanel buttonJPanel;
	private JTextArea textArea;
	private JButton[] buttons;
	private GUIPrintStream out;
	private ATM atm;
	private String value="";

	
	public ATM getATM()
	{
		return atm;
	}
	
	public TextAreaFrame()
	{
//		initComponents();
//		System.setOut(new GUIPrintStream(System.out, textArea));
//		super("ATM");
		atm=new ATM();
		setTitle("ATM");
		
		buttons=new JButton[12];
		buttonJPanel=new JPanel();
		buttonJPanel.setLayout(new  GridLayout(4,3));
		for(int i=0;i<buttons.length;i++)
		{
			buttons[i]=new JButton(""+(i+1));
			
			if(i>=9)
			{
				switch(i)
				{
				case 9:
					buttons[i]=new JButton("Enter");
					break;
				case 10:
					buttons[i]=new JButton(""+(0));
					break;
				case 11:
					buttons[i]=new JButton("<-");
				    break;
				}
			
			}

			
			buttonJPanel.add(buttons[i]);
//			buttons[i].addActionListener(
//					new ActionListener()
//					{
//						public void actionPerformed(ActionEvent e)
//						{
//							JButton soubut = (JButton)e.getSource();
//							textArea.setText(textArea.getText()+soubut.getText());
//						}
//					}
//					);
		}
		
		buttons[0].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
//						value+="1";
						textArea.append("1");
						value+="1";
//						System.out.println(value);
					}
				}
				);
		buttons[1].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						value+="2";
						textArea.setText(textArea.getText()+"2");
					}
				}
				);
		buttons[2].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						value+="3";
						textArea.setText(textArea.getText()+"3");
					}
				}
				);
		buttons[3].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						value+="4";
						textArea.setText(textArea.getText()+"4");
					}
				}
				);
		buttons[4].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						value+="5";
						textArea.setText(textArea.getText()+"5");
					}
				}
				);
		buttons[5].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						value+="6";
						textArea.setText(textArea.getText()+"6");
					}
				}
				);
		buttons[6].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						value+="7";
						textArea.setText(textArea.getText()+"7");
					}
				}
				);
		buttons[7].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						value+="8";
						textArea.setText(textArea.getText()+"8");
					}
				}
				);
		buttons[8].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						value+="9";
						textArea.setText(textArea.getText()+"9");
					}
				}
				);
		buttons[9].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						if(value!="")
						{
						atm.keypad.setInput(Integer.parseInt(value));
						atm.keypad.setEndInput(true);
						value="";
						}
//						System.out.println(value);
						
					}
				}
				);
		buttons[10].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						value+="0";
						textArea.setText(textArea.getText()+"0");
					}
				}
				);
		buttons[11].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						if(value.length()!=0)
						{
							value=textArea.getText();
							value=value.substring(0,value.length()-1);
							textArea.setText(value);
						}

					}
				}
				);
		add(buttonJPanel,BorderLayout.SOUTH);
		
		
    	String content="";
    	
    	textArea=new JTextArea(content,300,150);
        out=new GUIPrintStream(System.out,textArea);
        System.setOut(out);
    	add(new JScrollPane(textArea));
	}
}

	


