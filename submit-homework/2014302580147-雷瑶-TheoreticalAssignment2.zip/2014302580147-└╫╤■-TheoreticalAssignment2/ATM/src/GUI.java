import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class GUI extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private ATM atm = new ATM();
	String input;
	boolean isFirst;
	
    public static void main(String[] args) {
        GUI ATMGUI=new GUI();
        ATMGUI.setVisible(true);
        
        ATMGUI.atm.run();
    }
    //��ʾ����
	private JTextArea textArea=new JTextArea();
	private JScrollPane scrollPane = new JScrollPane();
	
	
	//��ť����
    private JButton btn1=new JButton("1");
    private JButton btn2=new JButton("2");
    private JButton btn3=new JButton("3");
    private JButton btn4=new JButton("4");
    private JButton btn5=new JButton("5");
    private JButton btn6=new JButton("6");
    private JButton btn7=new JButton("7");
    private JButton btn8=new JButton("8");
    private JButton btn9=new JButton("9");
    private JButton btn0=new JButton("0");
	private JButton btnEnter=new JButton("Enter");
	
	private JLabel cash = new JLabel("Take cash here",JLabel.CENTER);
	private JLabel insert = new JLabel("Insert deposit envelope here",JLabel.CENTER);

    public GUI() {  
        initialize();  		  

        System.setOut(new GUIPrintStream(System.out, textArea)); // �ض���ͨ���ı�������������������С�  
    }  
    
    private void initialize(){
		setResizable(false);
		setBounds(100, 100, 440, 343);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setTitle("ATM");
        getContentPane().setBackground(Color.WHITE);
        
        isFirst = true;
        
        //��ʾ����
		scrollPane.setBounds(10, 10, 414, 120);
		add(scrollPane);		
		textArea.setEditable(false);
		scrollPane.setViewportView(textArea);
		
		//��ť���֡�����λ�ã�������Frame��Ϊ��ť�����¼���������
		//���ּ�0~9
		btn1.setBounds(10, 140, 55, 32);
		setBtnStyle(btn1);
		
		btn2.setBounds(75, 140, 55, 32);
		setBtnStyle(btn2);
		
		btn3.setBounds(140, 140, 55, 32);
		setBtnStyle(btn3);
		
		btn4.setBounds(10, 182, 55, 32);
		setBtnStyle(btn4);
		
		btn5.setBounds(75, 182, 55, 32);
		setBtnStyle(btn5);
		
		btn6.setBounds(140, 182, 55, 32);
		setBtnStyle(btn6);
		
		btn7.setBounds(10, 224, 55, 32);
		setBtnStyle(btn7);
		
		btn8.setBounds(75, 224, 55, 32);
		setBtnStyle(btn8);
		
		btn9.setBounds(140, 224, 55, 32);
		setBtnStyle(btn9);
		
		btn0.setBounds(10, 266, 55, 32);
		setBtnStyle(btn0);
		
		//Enter��
		btnEnter.setBounds(75, 266, 120, 32);
		add(btnEnter);
		btnEnter.setFocusPainted(false);		
		btnEnter.addActionListener(new EnterListener());
		btnEnter.setBackground(new Color(221,240,237));
		
		
		//�忨ȡǮ
		cash.setBounds(250, 110, 100, 150);
		add(cash);
		insert.setBounds(200, 182, 200, 120);
		add(insert);

    }

    private class NumberListener implements ActionListener
    {
		public void actionPerformed(ActionEvent event)
    	{
			String number = event.getActionCommand();
			if(isFirst){
				input = number;
				isFirst = false;
			}else{
				input = input + number;
			}
			System.out.print(number);
    	}
    }
    
    private class EnterListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent event){
    		atm.keypad.number = Integer.parseInt(input);
    		atm.keypad.flag = true;
    		input = "";
    	}
    }
    
    //�������ְ�ť����ʽ
    private void setBtnStyle(JButton btn)
    {
    	add(btn);
		btn.setFocusPainted(false);		
		btn.addActionListener(new NumberListener());
		btn.setBackground(new Color(185,220,237));
    }
    
}
