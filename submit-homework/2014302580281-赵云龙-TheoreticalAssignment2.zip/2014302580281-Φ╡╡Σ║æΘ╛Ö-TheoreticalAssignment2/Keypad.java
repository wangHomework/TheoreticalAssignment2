package myATM;
//import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad extends ATMCaseStudy
 {
 /*private Scanner input; // reads data from the command line
// no-argument constructor initializes the Scanner
 public Keypad()
 {
 input = new Scanner( System.in );
 } // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 {
 return input.nextInt(); // we assume that user enters an integer
 } // end method getInput*/
	public int getInput() 
	{
		while(!send)
	{
		try {
			Thread.sleep(1000);
			//System.out.println("sleep");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		send=false;
		String value=input;
		input="";
		return Integer.valueOf(value);
	}

	
 }