package myATM;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class ATMCaseStudy
 {
	protected static JTextArea textArea;
	protected static ATM theATM;
	public static boolean send=false;
	protected static String input="";
 // main method creates and runs the ATM
 public static void main( String[] args ) throws InterruptedException
 {
	 //build ATM
	 theATM = new ATM();
	//build window
	 JFrame window = new JFrame("myATM");
     window.setResizable(false);
     window.setVisible(true);
     window.setSize(500, 500);
     window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     window.getContentPane().setLayout(null);
     
     //build text
     textArea=new JTextArea();
     textArea.setBorder(BorderFactory.createRaisedBevelBorder());
     window.add(textArea);
     textArea.setBounds(50, 20, 400, 150);
     textArea.setVisible(true);
     textArea.setRows(10);
     textArea.setLineWrap(true);
     
     //add button 
     JButton button1=new JButton("1");
     window.add(button1);
     button1.setBounds(20, 400, 60, 60);
     button1.setBorder(BorderFactory.createRaisedBevelBorder());
     button1.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			textArea.setText(input+="1");
		}	 
     });
     JButton button2=new JButton("2");
     window.add(button2);
     button2.setBounds(80, 400, 60, 60);
     button2.setBorder(BorderFactory.createRaisedBevelBorder());
     button2.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			textArea.setText(input+="2");
		}	 
     });
     JButton button3=new JButton("3");
     window.add(button3);
     button3.setBounds(140, 400, 60, 60);
     button3.setBorder(BorderFactory.createRaisedBevelBorder());
     button3.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			textArea.setText(input+="3");
		}	 
     });JButton button4=new JButton("4");
     window.add(button4);
     button4.setBounds(20, 300, 60, 60);
     button4.setBorder(BorderFactory.createRaisedBevelBorder());
     button4.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			textArea.setText(input+="4");
		}	 
     });
     JButton button5=new JButton("5");
     window.add(button5);
     button5.setBounds(80, 300, 60, 60);
     button5.setBorder(BorderFactory.createRaisedBevelBorder());
     button5.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			textArea.setText(input+="5");
		}	 
     });
     JButton button6=new JButton("6");
     window.add(button6);
     button6.setBounds(140, 300, 60, 60);
     button6.setBorder(BorderFactory.createRaisedBevelBorder());
     button6.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			textArea.setText(input+="6");
		}	 
     });
     JButton button7=new JButton("7");
     window.add(button7);
     button7.setBounds(20, 200, 60, 60);
     button7.setBorder(BorderFactory.createRaisedBevelBorder());
     button7.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			textArea.setText(input+="7");
		}	 
     });
     JButton button8=new JButton("8");
     window.add(button8);
     button8.setBounds(80, 200, 60, 60);
     button8.setBorder(BorderFactory.createRaisedBevelBorder());
     button8.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			textArea.setText(input+="8");
		}	 
     });
     JButton button9=new JButton("9");
     window.add(button9);
     button9.setBounds(140, 200, 60, 60);
     button9.setBorder(BorderFactory.createRaisedBevelBorder());
     button9.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			textArea.setText(input+="9");
		}	 
     });
     JButton button0=new JButton("0");
     window.add(button0);
     button0.setBounds(200, 400, 60, 60);
     button0.setBorder(BorderFactory.createRaisedBevelBorder());
     button0.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			textArea.setText(input+="0");
		}	 
     });
     JButton enter=new JButton("ENTURN");
     window.add(enter);
     enter.setBounds(200, 200, 60, 200);
     enter.addActionListener(new ActionListener(){
    	 public void actionPerformed(ActionEvent e){
    		 send=true;
    	 }
     });
     theATM.run();
 } // end main
 } // end class ATMCaseStudy