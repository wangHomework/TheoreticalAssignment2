package cn.net.ziqiang;

public class Keypad {
    //private Scanner input; // reads data from the command line
    ATMFrame frame;
    boolean flag;
    // no-argument constructor initializes the Scanner
    public Keypad(ATMFrame frame) {
        //input = new Scanner(System.in);
        this.frame = frame;
        flag = false;

    } // end no-argument Keypad constructor

    // return an integer value entered by user
    public int getInput() {
        //return input.nextInt(); // we assume that user enters an integer
        flag = false;
        while (!flag) {
            //需有语句，否则会被编译优化
            System.out.print("");
        } //用于阻塞线程，直到外部调用enter方法
        System.out.println("阻塞完成");
        return frame.requireUserInput();
    } // end method getInput

    public void userDidEnter() {
        this.flag = true;
    }
//
//    public void setFlagFalse() {
//        this.flag = false;
//    }
}