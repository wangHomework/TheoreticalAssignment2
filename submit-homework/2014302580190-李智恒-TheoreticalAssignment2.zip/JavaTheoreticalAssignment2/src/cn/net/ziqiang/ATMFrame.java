package cn.net.ziqiang;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Created by Hubert on 15/11/1.
 */
public class ATMFrame extends JFrame {

    private static final Color ATM_COLOR = new Color(122, 173, 220);



    private JTextArea textArea;
    private JLabel backgroundImage;
    public ATM atm;
    private ArrayList<JButton> buttons;

    private String userInput = "";


    public ATMFrame() {

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(535, 410);
        setLayout(null);


        //设置背景图片
        backgroundImage = new JLabel(new ImageIcon("resource/ATM-background.png"));
        backgroundImage.setLayout(null);
        backgroundImage.setBounds(0, 0, this.getWidth(), this.getHeight());
        setContentPane(backgroundImage);

        //显示文本区域
        textArea = new JTextArea();
        textArea.setForeground(new Color(19, 153, 66));
        textArea.setEditable(false);
        //将文本区域放在JScrollPane中
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(65, 30, 400, 120);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollPane);


        //添加buttons
        buttons = new ArrayList<JButton>();
        ButtonListener btnListener = new ButtonListener();
        JButton button1 = new JButton("1");
        button1.setBounds(35, 200, 30, 30);
        buttons.add(button1);
        JButton button2 = new JButton("2");
        button2.setBounds(85, 200, 30, 30);
        buttons.add(button2);
        JButton button3 = new JButton("3");
        button3.setBounds(135, 200, 30, 30);
        buttons.add(button3);
        JButton button4 = new JButton("4");
        button4.setBounds(35, 250, 30, 30);
        buttons.add(button4);
        JButton button5 = new JButton("5");
        button5.setBounds(85, 250, 30, 30);
        buttons.add(button5);
        JButton button6 = new JButton("6");
        button6.setBounds(135, 250, 30, 30);
        buttons.add(button6);
        JButton button7 = new JButton("7");
        button7.setBounds(35, 300, 30, 30);
        buttons.add(button7);
        JButton button8 = new JButton("8");
        button8.setBounds(85, 300, 30, 30);
        buttons.add(button8);
        JButton button9 = new JButton("9");
        button9.setBounds(135, 300, 30, 30);
        buttons.add(button9);
        JButton button0 = new JButton("0");
        button0.setBounds(35, 350, 30, 30);
        buttons.add(button0);

        JButton enterBtn = new JButton("ENTER");
        enterBtn.setBounds(85, 350, 80, 30);
        buttons.add(enterBtn);
        add(enterBtn);

        for (JButton button: buttons) {
            button.addActionListener(btnListener);
            add(button);
        }

        atm = new ATM(this);


//        screen = new ATMScreenPanel();
//        numBtns = new NumBtnsPanel();
//        screen.setBounds(65, 30, 400, 120);
//        screen.setVisible(true);
//        numBtns.setBounds(27, 190, 140, 185);
//        numBtns.setVisible(true);
//
//        add(screen);
//        add(numBtns);

    }


    public class ButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton pressedButton = (JButton)e.getSource();
            String buttonText = pressedButton.getText();
            if (!buttonText.equals("ENTER")) {
                textArea.setText(textArea.getText() + buttonText);
                userInput += buttonText;
            } else {
                atm.keypad.userDidEnter();
            }

        }
    }

    public void updateTextArea(String input) {
        this.textArea.setText(this.textArea.getText() + input);
    }

    public int requireUserInput() {
        int number = Integer.parseInt(this.userInput);
        userInput = "";
        return number;
    }

}
