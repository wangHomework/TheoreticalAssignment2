package cn.net.ziqiang;

public class Main {

    public static void main(String[] args) {
        ATMFrame atmFrame = new ATMFrame();
        atmFrame.setVisible(true);
        atmFrame.atm.run();

    }
}
