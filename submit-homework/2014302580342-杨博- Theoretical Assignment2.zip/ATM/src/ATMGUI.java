import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Robot;
import java.awt.AWTException;

public class ATMGUI extends JFrame  {
 private JLabel jLabel;
 JTextArea jTextArea;
 private JButton jButton[];
 Robot robot;
 String GUIinput = "";
 String GUItemp= "";
 public boolean inputFlag = false;

public ATMGUI()
{
   super();
   this.setSize(800, 650);
   jButton  = new JButton[12];
   this.getContentPane().setLayout(null);
   this.add(getJLabel(), null);
   this.add(getJTextArea(), null);
  for(int i = 1;i<12;i++){
	   this.add(getJButton(i),null);
   }
  
   this.setTitle("ATMGUI");

}

private javax.swing.JLabel getJLabel() {
   if(jLabel == null) {
      jLabel = new javax.swing.JLabel();
      jLabel.setBounds(300, 300, 300, 30);
      //jLabel.setText("ȡ��");
   }
   return jLabel;
}

private javax.swing.JTextArea getJTextArea() {
   if(jTextArea == null) {
	   jTextArea = new javax.swing.JTextArea();
	   jTextArea.setBounds(10, 10, 760, 240);
	   jTextArea.setEditable(false);
	   jTextArea.setFont(new Font("΢���ź�",0,15));
   }
   return jTextArea;
}

private javax.swing.JButton getJButton(int i) {
	 try {

	     robot = new Robot();

	 } catch (AWTException e) {

	     //�׳����쳣��ʾƽ̨���ò�����ʹ�õͼ�����ؼ�,����֧��Robot��

	     e.printStackTrace();

	 }
   if(jButton[i] == null) {
	  switch(i){
	  case 1:
		  jButton[i] = new javax.swing.JButton();
		  jButton[i].setBounds(17,262, 75,75 );
		  jButton[i].setText("1");
		  jButton[i].setFont(new Font("΢���ź�",0,20));
		  jButton[i].addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                jTextArea.append("1");
	                GUIinput +="1";
	            }
	        });
		  break;
	  case 2:
		  jButton[i] = new javax.swing.JButton();
		  jButton[i].setBounds(99, 262, 75,75 );
		  jButton[i].setText("2");
		  jButton[i].setFont(new Font("΢���ź�",0,20));
		  jButton[i].addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                jTextArea.append("2");
	                GUIinput +="2";
	                
	            }
	        });
		  break;
	  case 3:
		  jButton[i] = new javax.swing.JButton();
		  jButton[i].setBounds(181,262, 75,75 );
		  jButton[i].setText("3");
		  jButton[i].setFont(new Font("΢���ź�",0,20));
		  jButton[i].addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                jTextArea.append("3");
	                GUIinput +="3";
	                
	            }
	        });
		  break;
	  case 4:
		  jButton[i] = new javax.swing.JButton();
		  jButton[i].setBounds(17,344, 75,75 );
		  jButton[i].setText("4");
		  jButton[i].setFont(new Font("΢���ź�",0,20));
		  jButton[i].addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	
	                jTextArea.append("4");
	                GUIinput +="4";
	                
	            }
	        });
		  break;
	  case 5:
		  jButton[i] = new javax.swing.JButton();
		  jButton[i].setBounds(99,344, 75,75 );
		  jButton[i].setText("5");
		  jButton[i].setFont(new Font("΢���ź�",0,20));
		  jButton[i].addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                //robot.keyPress(KeyEvent.VK_1);
	                //robot.keyRelease(KeyEvent.VK_1);
	                jTextArea.append("5");
	                GUIinput +="5";
	                
	            }
	        });
		  break;
	  case 6:
		  jButton[i] = new javax.swing.JButton();
		  jButton[i].setBounds(181,344, 75,75 );
		  jButton[i].setText("6");
		  jButton[i].setFont(new Font("΢���ź�",0,20));
		  jButton[i].addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                //robot.keyPress(KeyEvent.VK_1);
	                //robot.keyRelease(KeyEvent.VK_1);
	                jTextArea.append("6");
	                GUIinput +="6";
	                
	            }
	        });
		  break;
	  case 7:
		  jButton[i] = new javax.swing.JButton();
		  jButton[i].setBounds(17,426, 75,75 );
		  jButton[i].setText("7");
		  jButton[i].setFont(new Font("΢���ź�",0,20));
		  jButton[i].addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                //robot.keyPress(KeyEvent.VK_1);
	                //robot.keyRelease(KeyEvent.VK_1);
	                jTextArea.append("7");
	                GUIinput +="7";
	                
	            }
	        });
		  break;
	  case 8:
		  jButton[i] = new javax.swing.JButton();
		  jButton[i].setBounds(99,426, 75,75 );
		  jButton[i].setText("8");
		  jButton[i].setFont(new Font("΢���ź�",0,20));
		  jButton[i].addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                //robot.keyPress(KeyEvent.VK_1);
	                //robot.keyRelease(KeyEvent.VK_1);
	                
	               jTextArea.append("8");
	                GUIinput +="8"; 
	            }
	        });
		  break;
	  case 9:
		  jButton[i] = new javax.swing.JButton();
		  jButton[i].setBounds(181,426, 75,75 );
		  jButton[i].setText("9");
		  jButton[i].setFont(new Font("΢���ź�",0,20));
		  jButton[i].addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                //robot.keyPress(KeyEvent.VK_1);
	                //robot.keyRelease(KeyEvent.VK_1);
	                jTextArea.append("9");
	                GUIinput +="9";
	                
	            }
	        });
		  break;
	  case 10:
		  jButton[i] = new javax.swing.JButton();
		  jButton[i].setBounds(17,508, 75,75 );
		  jButton[i].setText("0");
		  jButton[i].setFont(new Font("΢���ź�",0,20));
		  jButton[i].addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                //robot.keyPress(KeyEvent.VK_1);
	                //robot.keyRelease(KeyEvent.VK_1);
	                jTextArea.append("0");
	                GUIinput +="0";
	                
	            }
	        });
		  break;
	  case 11:
		  jButton[i] = new javax.swing.JButton();
		  jButton[i].setBounds(99,508, 157,75 );
		  jButton[i].setText("enter");
		  jButton[i].setFont(new Font("΢���ź�",0,20));
		  jButton[i].addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	           
	                inputFlag = true;
	            }
	        });
		  break;
	  }
   }
   return jButton[i];
}

public void clearScreen(){
	jTextArea.setText("");
	
}
}

