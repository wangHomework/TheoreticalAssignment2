import javax.swing.*;

public class ATMCaseStudy extends Transaction
 { 

	
 public ATMCaseStudy(int userAccountNumber, Screen atmScreen, BankDatabase atmBankDatabase) {
		super(userAccountNumber, atmScreen, atmBankDatabase);
		// TODO Auto-generated constructor stub
	}

	// main method creates and runs the ATM
	public static void main(String[] args)
	{
		atmcase.run();
		
		//a.atmgui.setVisible(true);
	
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}
 } // end class ATMCaseStudy