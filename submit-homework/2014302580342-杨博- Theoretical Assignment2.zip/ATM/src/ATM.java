
public class ATM {
	private boolean userAuthenticated; 
	private int currentAccountNumber; 
	private Screen screen; 
	public ATMGUI atmgui ;
	private Keypad keypad; // ATM's keypad
	private CashDispenser cashDispenser; // ATM's cash dispenser
	private DepositSlot depositSlot; // ATM's deposit slot
	private BankDatabase bankDatabase; // account information database
	public int  stateFlag = 0; 
	public int accountNumber;
	public int pin;
	int mainMenuSelection =0;
	// constants corresponding to main menu options
	private static final int BALANCE_INQUIRY = 1;
	private static final int WITHDRAWAL = 2;
	private static final int DEPOSIT = 3;
	private static final int EXIT = 4;
	
	//display a message without a carriage return
	public void displayMessage( String message )
	{
	System.out.print( message );
	atmgui.jTextArea.append(message);

	} // end method displayMessage

	// display a message with a carriage return
	public void displayMessageLine( String message )
	{
	System.out.println( message );
	atmgui.jTextArea.append(message);
	} 

	// displays a dollar amount
	public void displayDollarAmount( double amount )
	{
	System.out.printf( "$%,.2f", amount );
	atmgui.jTextArea.append("$" );
	atmgui.jTextArea.append(Double.toString(amount));
	} // end method displayDollarAmount

	 // no-argument ATM constructor initializes instance variables
	 public ATM()
	 {
	 userAuthenticated = false; // user is not authenticated to start
	 currentAccountNumber = 0; // no current account number to start
	 screen = new Screen(); // create screen
	 keypad = new Keypad(); // create keypad
	 atmgui  = new ATMGUI();
	 atmgui.setVisible(true);
	 cashDispenser = new CashDispenser(); // create cash dispenser
	 depositSlot = new DepositSlot(); // create deposit slot
	 bankDatabase = new BankDatabase(); // create acct info database

	 
	  } // end no-argument ATM constructor
	 // start ATM
	 public int getInput(){
		   if(atmgui.inputFlag) {
			  if(atmgui.GUIinput == ""){
				  atmgui.clearScreen();
				  displayMessageLine("\nWrong account number or PIN. Please try again.\n" );
				 // stateFlag = 5;
				  atmgui.inputFlag = false;

			  }
			  atmgui.inputFlag = false;
			  atmgui.clearScreen();
			  stateFlag = 2;
			
			 //accountNumber = Integer.parseInt(atmgui.GUIinput);
			  return Integer.parseInt(atmgui.GUIinput);
			  }
		   return 0;
	 }
	 
	  private void  displayMainMenu()
	   {
		 
		  stateFlag = 5;
		  while(true){ 
				  switch(stateFlag){
				  case 5:
					  
					  displayMessageLine( "\nMain menu:" );
					  displayMessageLine( "\n1 - View my balance" );
					  displayMessageLine( "\n2 - Withdraw cash" );
					  displayMessageLine( "\n3 - Deposit funds" );
					  displayMessageLine( "\n4 - Exit\n" );
					  displayMessage( "Enter a choice: " );
					  stateFlag = 6;
					  break;
				  case 6:
					  mainMenuSelection = getInput();
					  if(mainMenuSelection !=0){
						  atmgui.GUIinput="";
						 return;  
					  }
					 
					 /* if(atmgui.inputFlag) {
						  if(atmgui.GUIinput == ""){
							  atmgui.clearScreen();
							  displayMessageLine("\nWrong account number or PIN. Please try again.\n" );
							  stateFlag = 5;
							  atmgui.inputFlag = false;
							  break;
						  }
						  mainMenuSelection  =  Integer.parseInt(atmgui.GUIinput);
						  atmgui.inputFlag = false;
						  atmgui.GUIinput="";
						  atmgui.clearScreen();
						  return;  
					  }*/
					  break;
				  }
		  }
	   }
	 public void run()
	  {
	  // welcome and authenticate user; perform transactions
		  while ( true ){
			  // loop while user is not yet authenticated
			  while ( !userAuthenticated )
			  	{
				  	authenticateUser(); // authenticate user
			  	} // end while
			 
			  performTransactions(); // user is now authenticated
			  
			  userAuthenticated = false; // reset before next ATM session
			  currentAccountNumber = 0; // reset before next ATM session
			  
			 displayMessageLine( "\nThank you! Goodbye!" );
			 break;
			 
		 } 
	  }
	 
	  private void authenticateUser()
	  {
		  
		  
		  switch(stateFlag){
		  case 0:	  
			 displayMessageLine("\nWelcome");
			displayMessage( "\n\nPlease enter your account number: " );
			 accountNumber = 0;
			 pin = 0;
			 stateFlag = 1;
			 break;
		  case 1:
			  accountNumber = getInput();
			  if(accountNumber != 0)
				  displayMessage( "\n\nEnter your PIN: " ); 
			  	  atmgui.GUIinput="";
			  /*if(atmgui.inputFlag) {
				  if(atmgui.GUIinput == ""){
					  atmgui.clearScreen();
					  atmgui.inputFlag = false;
					  displayMessageLine("\nWrong account number or PIN. Please try again.\n" );
					  stateFlag = 0;
					  break;
				  }
					 accountNumber =  Integer.parseInt(atmgui.GUIinput);
					 atmgui.inputFlag = false;
					 atmgui.GUIinput="";
					 stateFlag = 2;
					 displayMessage( "\n\nEnter your PIN: " ); 
			  }*/
			  break;
			
		  case 2:
			
			  if(atmgui.inputFlag){
				  if(atmgui.GUIinput == ""){
					  atmgui.clearScreen();
					  displayMessageLine("\nWrong account number or PIN. Please try again.\n" );
					  atmgui.inputFlag = false;
					  stateFlag = 0;
					  break;
				  }
					 pin = Integer.parseInt(atmgui.GUIinput);
					 atmgui.inputFlag = false;
					 atmgui.GUIinput="";
					 stateFlag = 3;	 
			  }
			  break;
			  
		  case 3:
			 userAuthenticated =bankDatabase.authenticateUser( accountNumber, pin );
			 // userAuthenticated =bankDatabase.authenticateUser( 12345, 54321 );

			 
			  if ( userAuthenticated )
			 {
			  currentAccountNumber = accountNumber;
			  atmgui.clearScreen();
			  } 
			  else{
				  atmgui.clearScreen();
				  displayMessageLine("\nInvalid account number or PIN. Please try again.\n" );
				  stateFlag = 0;
				  atmgui.inputFlag = false;
			  }
			  break;
			  
		  default :
			  break;
			  
		
		  }	 
	  }

	
	  private void performTransactions()
	  {
	 // local variable to store transaction currently being processed
	  Transaction currentTransaction = null;
	  boolean userExited = false; // user has not chosen to exit
	
	   while ( !userExited )
	  {
		   displayMainMenu();
	   switch ( mainMenuSelection )
	   {
	
	  case BALANCE_INQUIRY:
	  case WITHDRAWAL:
	  case DEPOSIT:
	   
	  currentTransaction =
	   createTransaction( mainMenuSelection );
	  currentTransaction.execute(); 
	 break;
	   case 4: 
		   displayMessageLine( "\nExiting the system..." );
	   userExited = true; // this ATM session should end
	   break;
	   default: // user did not enter an integer from 1-4
		   displayMessageLine(
	   "\nYou did not enter a valid selection. Try again." );
	   break;
	   } 
	   }
	  } 
	  
	

	  private Transaction createTransaction( int type )
	   {
	   Transaction temp = null;
	  switch ( type )
	  {
	   case BALANCE_INQUIRY:
	   temp = new BalanceInquiry(
	   currentAccountNumber, screen, bankDatabase );
	  break;
	   case WITHDRAWAL: 
	   temp = new Withdrawal( currentAccountNumber, screen,
	  bankDatabase, keypad, cashDispenser );
	   break;
	   case DEPOSIT:
	   temp = new Deposit( currentAccountNumber, screen,
	   bankDatabase, keypad, depositSlot );
	   break;
	   } 
	 
	   return temp; 
	   }
	   }
