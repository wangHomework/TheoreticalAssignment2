
// Represents the screen of the ATM

public class Screen
 {
// display a message without a carriage return
 public void displayMessage( String message )
 {
	 GUI.show+=message;
	 GUI.textArea.setText(GUI.show);
 } // end method displayMessage

 // display a message with a carriage return
 public void displayMessageLine( String message )
 {
	 GUI.show+="\n"+message;
	 GUI.textArea.setText(GUI.show);
 } // end method displayMessageLine

 // displays a dollar amount
 public void displayDollarAmount( double amount )
 {
	 GUI.show+=amount;
	 GUI.textArea.setText(GUI.show);
 } // end method displayDollarAmount
 } // end class Screen