/**
 _ooOoo_
                  o8888888o
                  88" . "88
                  (| -_- |)
                  O\  =  /O
               ____/`---'\____
             .'  \\|     |//  `.
            /  \\|||  :  |||//  \
           /  _||||| -:- |||||-  \
           |   | \\\  -  /// |   |
           | \_|  ''\---/''  |   |
           \  .-\__  `-`  ___/-. /
         ___`. .'  /--.--\  `. . __
      ."" '<  `.___\_<|>_/___.'  >'"".
     | | :  `- \`.;`\ _ /`;.`/ - ` : | |
     \  \ `-.   \_ __\ /__ _/   .-` /  /
======`-.____`-.___\_____/___.-`____.-'======
                   `=---='
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                                        ���汣��       ����BUG
*@author Vintony.Lee
* @version 1.0
* Note
* �޻���˵
 */


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GUI {
	private JFrame frame;
	static String input;
	public static String show=" ";
	boolean empty=true;
	static ATM atm;
	public static JTextArea textArea;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
					atm=new ATM();
					GUI window = new GUI();
					window.frame.setVisible(true);
					atm.run();
	}

	/**
	 * Create the application.
	 */
	public GUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 650, 580);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(10, 10, 614, 238);
		frame.getContentPane().add(textArea);
		
		JButton button = new JButton("4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(empty==true)
				{
					input="4";
					show="4";
					empty=false;
				}else
				{
					input+="4";
					show+="4";
				}
				textArea.setText(show);
			}
		});
		button.setBounds(10, 318, 50, 50);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("7");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(empty==true)
				{
					input="7";
					show="7";
					empty=false;
				}else
				{
					input+="7";
					show+="7";
				}
				textArea.setText(show);
			}
		});
		button_1.setBounds(10, 378, 50, 50);
		frame.getContentPane().add(button_1);
		
		JButton button_2 = new JButton("1");
		button_2.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				if(empty==true)
				{
					input="1";
					show="1";
					empty=false;
				}else
				{
					input+="1";
					show+="1";
				}
				textArea.setText(show);
			}
		});
		button_2.setBounds(10, 258, 50, 50);
		frame.getContentPane().add(button_2);
		
		JButton button_3 = new JButton("2");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(empty==true)
				{
					input="2";
					show="2";
					empty=false;
				}else
				{
					input+="2";
					show+="2";
				}
				textArea.setText(show);
			}
		});
		button_3.setBounds(70, 258, 50, 50);
		frame.getContentPane().add(button_3);
		
		JButton button_4 = new JButton("5");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(empty==true)
				{
					input="5";
					show="5";
					empty=false;
				}else
				{
					input+="5";
					show+="5";
				}
				textArea.setText(show);
			}
		});
		button_4.setBounds(70, 318, 50, 50);
		frame.getContentPane().add(button_4);
		
		JButton button_5 = new JButton("8");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(empty==true)
				{
					input="8";
					show="8";
					empty=false;
				}else
				{
					input+="8";
					show+="8";
				}
				textArea.setText(show);
			}
		});
		button_5.setBounds(70, 378, 50, 50);
		frame.getContentPane().add(button_5);
		
		JButton button_6 = new JButton("3");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{if(empty==true)
			{
				input="3";
				show="3";
				empty=false;
			}else
			{
				input+="3";
				show+="3";
			}
			textArea.setText(show);
			}
		});
		button_6.setBounds(130, 258, 50, 50);
		frame.getContentPane().add(button_6);
		
		JButton button_7 = new JButton("6");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(empty==true)
				{
					input="6";
					show="6";
					empty=false;
				}else
				{
					input+="6";
					show+="6";
				}
				textArea.setText(show);
			}
		});
		button_7.setBounds(130, 318, 50, 50);
		frame.getContentPane().add(button_7);
		
		JButton button_8 = new JButton("9");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(empty==true)
				{
					input="9";
					show="9";
					empty=false;
				}else
				{
					input+="9";
					show+="9";
				}
				textArea.setText(show);
			}
		});
		button_8.setBounds(130, 378, 50, 50);
		frame.getContentPane().add(button_8);
		
		JButton button_9 = new JButton("0");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(empty==true)
				{
					input="0";
					show="0";
					empty=false;
				}else
				{
					input+="0";
					show+="0";
				}
				textArea.setText(show);
			}
		});
		button_9.setBounds(10, 438, 50, 93);
		frame.getContentPane().add(button_9);
		
		JButton btnEnter = new JButton("ENTER");
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					atm.keypad.number = Integer.parseInt(input);
					} catch (NumberFormatException e1) { e1.printStackTrace();}
				atm.keypad.enter=true;
				input="";
				empty=true;
			}
		});
		btnEnter.setBounds(70, 438, 110, 42);
		frame.getContentPane().add(btnEnter);
		
		JButton btnBackspace = new JButton("BACKSPACE");
		btnBackspace.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(empty==true)
			{
				input="";
				show="";
				empty=true;
			}else
			{
				if(input.length()!=0){
				input=input.substring(0, input.length()-1);
				show=show.substring(0,show.length()-1);
				}
				if(input.length()==0){
					empty=true;
				}
			}
				textArea.setText(show);
		}
		});
		btnBackspace.setBounds(70, 490, 110, 41);
		frame.getContentPane().add(btnBackspace);
		
		JLabel label = new JLabel("                             \u53D6   \u6B3E   \u5904");
		label.setBounds(190, 281, 434, 87);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("                             \u5B58   \u6B3E   \u5904");
		label_1.setBounds(190, 423, 434, 105);
		frame.getContentPane().add(label_1);
		
		
	}
}
