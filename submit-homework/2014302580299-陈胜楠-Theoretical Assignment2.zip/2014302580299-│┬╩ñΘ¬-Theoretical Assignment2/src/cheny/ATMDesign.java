package cheny;
	import java.awt.Color;
	import java.awt.EventQueue;

	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JTextArea;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;

public class  ATMDesign extends JFrame {
		 JFrame list;
		 JTextArea show;
		 JButton[] jbNum =new JButton[10];
		 JButton enter ;
		 JButton balance;
		 JButton withdraw;
		 JButton deposit;
		 JButton exit;
		 static String ID = "";
		 static String PIN = "";
		 static String amount = "";
		 int choice=1;
		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						ATMDesign frame = new ATMDesign();
						frame.display();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the frame.
		 */
		 // ���������ڣ�����һ��Text��
		void display(){
	    list = new JFrame("ATM");
	    list.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    list.setSize(500, 500);
	    list.setBackground(Color.GREEN); // ���ô��ڱ�����ɫ
	    list.setResizable(false);
	    list.setLayout(null);
	    show = new JTextArea();
	    show.setBounds(20, 20,450, 180);
	    show.setDisabledTextColor(Color.BLACK);// ���ô�����ɫ
	    show.setEditable(false); // �ı��򲻿ɱ༭
	    list.getContentPane().add(show);
	    // ������岢���ò��� 
	    // ����0~9��ť����
	    jbNum = new JButton[10];
	    for (int i = 9; i >= 0; i--) {
	        jbNum[i] = new JButton(String.valueOf(i));
	        jbNum[i].setForeground(Color.BLUE);
	        jbNum[i].setBounds(20+70*(i%3), 220+i/3*65, 70, 63);
	        jbNum[i].addActionListener(new myattention());
	        list.add(jbNum[i]);   
	    }
	    //���� ���밴ť
	    enter=new JButton();
	    enter.setBounds(90, 415, 140, 63);
	    enter.setText("ENTER");
	    enter.addActionListener(new myattention());
	    list.add(enter); 
	    //���� ��ѯ��ť
	   balance=new JButton();
	    balance.setText("Balance");
	    balance.setBounds(300, 220, 100, 55);
	    balance.addActionListener(new myattention());
	    list.add(balance); 
	    //����ȡ�ť
	    withdraw = new JButton();
	    withdraw.setText("Withdraw");
	    list.add(withdraw);
	    withdraw.setBounds(400, 220, 100, 55);
	    withdraw.addActionListener(new myattention());
	    //���� ��ť
	    deposit = new JButton();
	    deposit.setText("Deposit");
	    list.add(deposit);
	    deposit.setBounds(300, 275, 100, 55);
	    deposit.addActionListener(new myattention());
	    //�����˳���ť
	    exit = new JButton();
	    exit.setText("Exit");
	    list.add(exit);
	    exit.setBounds(400, 275, 100, 55);
	    exit.addActionListener(new myattention());
	    show.setText("Welcome\nPlease enter your account number: \n");
	    list.setVisible(true);
	    }
class myattention implements ActionListener{
		   ATMD atm=new ATMD();
		   public void actionPerformed(ActionEvent e){
			   if(e.getSource()==balance){
				   choice = 4;
	                show.setText(atm.getBalance());
	                choice = 3; 
			   }
			   if(e.getSource()==withdraw){
				   choice = 5;
	               show.setText(atm.getBalance() + "\n\nInput amount:\n");
	                }
			   if(e.getSource()==deposit){
				   choice = 6;
	               show.setText("Input deposit amount:\n");
                   amount = "";
	                }
			   if(e.getSource()==exit){
				   choice = 7;
	               show.setText("Welcome\nPlease enter your account number: \n");
	               balance.setEnabled(false);
                   withdraw.setEnabled(false);
                   deposit.setEnabled(false);
                   exit.setEnabled(false);
                   amount = "";
                   ID="";
                   PIN="";
                   choice = 1;
	                }
			   if(e.getSource()==enter){
				   switch (choice)
	                {
	                    case 1:
	                    	choice = 2;
	                        show.append( "\nEnter your PIN: \n");
	                        break;
	                    case 2:
	                        if (!ID.equals("") && !PIN.equals("") && atm.authenticateUser(Integer.parseInt(ID), Integer.parseInt(PIN)))
	                        {
	                        	choice = 3;
	                            show.setText("User" + ID + ", welcome!\n Press keys to begin your transaction");
	                            balance.setEnabled(true);
	                            deposit.setEnabled(true);
	                            withdraw.setEnabled(true);
	                            exit.setEnabled(true);
	                        }
	                        else
	                        {
	                        	choice = 1;
	                           ID = "";
	                            PIN = "";
	                            show.setText("Welcome\nPlease enter your account number: \n");
	                        }
	                        break;
	                    case 5:
	                        if (amount.equals(""))
	                        {
	                            show.setText("Invalid amount! Try again:\n");
	                        }
	                        else
	                        {
	                            if (atm.withdraw(Integer.parseInt(amount)))
	                            {
	                                show.setText("Take your money!");
	                                amount = "";
	                                choice = 3;
	                            }
	                            else
	                            {
	                                show.setText("You don't have so much money available! Try less money:\n");
	                                amount = "";
	                            }
	                        }
	                        break;
	                    case 6:
	                        if (amount.equals(""))
	                        {
	                            show.setText("Invalid amount! Try again:\n");
	                        }
	                        else
	                        {
	                            atm.deposit(Integer.parseInt(amount));
	                            show.setText("You've been deposit " + amount + "!\n#The money is temporarily unavailable#");
	                            amount = "";
	                        }
	                        break;
	                }
			   }
			   if(e.getSource()==jbNum[1]){
				   switch (choice)
	                {
	                    case 1:
	                        ID += "1";
	                        show.setText(show.getText() + "1");
	                        break;
	                    case 2:
	                        PIN += "1";
	                        show.setText(show.getText() + "*");
	                        break;
	                    case 5:
	                    case 6:
	                        amount += "1";
	                        show.setText(show.getText() + "1");
	                        break;
	                }
				   }
				   if(e.getSource()==jbNum[2]){
					   switch (choice)
		                {
		                    case 1:
		                        ID += "2";
		                        show.append( "2");
		                        break;
		                    case 2:
		                        PIN += "2";
		                        show.append( "*");
		                        break;
		                    case 5:
		                    case 6:
		                        amount += "2";
		                        show.append( "2");
		                        break;
		                }
					   }
				   if(e.getSource()==jbNum[3]){
					   switch (choice)
		                {
		                    case 1:
		                        ID += "3";
		                        show.append( "3");
		                        break;
		                    case 2:
		                        PIN += "3";
		                        show.append( "*");
		                        break;
		                    case 5:
		                    case 6:
		                        amount += "3";
		                        show.append( "3");
		                        break;
		                }
					   }
				   if(e.getSource()==jbNum[4]){
					   switch (choice)
		                {
		                    case 1:
		                        ID += "4";
		                        show.append( "4");
		                        break;
		                    case 2:
		                        PIN += "4";
		                        show.append( "*");
		                        break;
		                    case 5:
		                    case 6:
		                        amount += "4";
		                        show.append( "4");
		                        break;
		                }
					   }
				   if(e.getSource()==jbNum[5]){
					   switch (choice)
		                {
		                    case 1:
		                        ID += "5";
		                        show.append( "5");
		                        break;
		                    case 2:
		                        PIN += "5";
		                        show.append( "*");
		                        break;
		                    case 5:
		                    case 6:
		                        amount += "5";
		                        show.append( "5");
		                        break;
		                }
					   }
				   if(e.getSource()==jbNum[6]){
					   switch (choice)
		                {
		                    case 1:
		                        ID += "6";
		                        show.append( "6");
		                        break;
		                    case 2:
		                        PIN += "6";
		                        show.append( "*");
		                        break;
		                    case 5:
		                    case 6:
		                        amount += "6";
		                        show.append( "6");
		                        break;
		                }
					   }
				   if(e.getSource()==jbNum[7]){
					   switch (choice)
		                {
		                    case 1:
		                        ID += "7";
		                        show.append( "7");
		                        break;
		                    case 2:
		                        PIN += "7";
		                        show.append( "*");
		                        break;
		                    case 5:
		                    case 6:
		                        amount += "7";
		                        show.append( "7");
		                        break;
		                }
					   }
				   if(e.getSource()==jbNum[8]){
					   switch (choice)
		                {
		                    case 1:
		                        ID += "8";
		                        show.append( "8");
		                        break;
		                    case 2:
		                        PIN += "8";
		                        show.append( "*");
		                        break;
		                    case 5:
		                    case 6:
		                        amount += "8";
		                        show.append( "8");
		                        break;
		                }
					   }
				   if(e.getSource()==jbNum[9]){
					   switch (choice)
		                {
		                    case 1:
		                        ID += "9";
		                        show.append( "9");
		                        break;
		                    case 2:
		                        PIN += "9";
		                        show.append( "*");
		                        break;
		                    case 5:
		                    case 6:
		                        amount += "9";
		                        show.append( "9");
		                        break;
		                }
					   }
				   if(e.getSource()==jbNum[0]){
					   switch (choice)
		                {
		                    case 1:
		                        ID += "0";
		                        show.append( "0");
		                        break;
		                    case 2:
		                        PIN += "0";
		                        show.append( "*");
		                        break;
		                    case 5:
		                    case 6:
		                        amount += "0";
		                        show.append( "0");
		                        break;
		                }
					   }
				   }
		   }
}
					   
			
			   
			   




