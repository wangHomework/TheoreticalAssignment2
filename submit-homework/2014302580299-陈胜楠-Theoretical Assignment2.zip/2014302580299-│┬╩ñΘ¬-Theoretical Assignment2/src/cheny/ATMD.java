package cheny;

public class ATMD {
		private BankDatabase bankDatabase; // account information database
		// constants corresponding to main menu options
		 public ATMD()
		 {
		 bankDatabase = new BankDatabase(); // create acct info database
		  } // end no-argument ATM constructor
		 // start ATM
		  public boolean authenticateUser(int accountNumber, int pin)
		    {
		        return bankDatabase.authenticateUser(accountNumber, pin);
		    }

		 public String getBalance()
		    {
		        double availableBalance = bankDatabase.getAvailableBalance(Integer.parseInt(ATMDesign.ID));

		        double totalBalance = bankDatabase.getTotalBalance(Integer.parseInt(ATMDesign.ID));

		        return "\nBalance Information:\n     - Available balance: " + availableBalance + "\n     - Total balance: " + totalBalance;
		    }

		    public boolean withdraw(int amount)
		    {
		        return bankDatabase.take(Integer.parseInt(ATMDesign.ID), amount);
		    }

		    public void deposit(int amount)
		    {
		        bankDatabase.put(Integer.parseInt(ATMDesign.ID), amount);
		    }
		}



