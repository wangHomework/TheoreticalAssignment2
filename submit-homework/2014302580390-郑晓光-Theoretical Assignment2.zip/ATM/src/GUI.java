import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;




public class GUI extends JFrame {
	public String str="";//��Ϊ��������ݺ�keypad��Input���м����
	public JTextArea jt=new JTextArea();
	public ATM atm;
public GUI(){
	setTitle("ATM");
	setSize(800,800);
	
	Container c=getContentPane();
	c.setLayout(new GridLayout(2,1,700,100));
	JPanel p1=new JPanel();
	p1.setLayout(new GridLayout(3,40,30,30));
	JScrollPane p2=new JScrollPane(jt);
	p2.setVisible(true);
	c.add(p2);
	c.add(p1);
	jt.setBackground(Color.yellow);
	jt.append("(ps:The two accounts in bankDatebase we have already known)");

    JButton b1=new JButton("1");
    JButton b2=new JButton("2");
    JButton b3=new JButton("3");
	JButton b4=new JButton("4");
	JButton b5=new JButton("5");
	JButton b6=new JButton("6");
	JButton b7=new JButton("7");
	JButton b8=new JButton("8");
	JButton b9=new JButton("9");
	JButton b0=new JButton("0");
	JButton bDelete=new JButton("Backspace");
	JButton bEnter=new JButton("Enter");
	JLabel label1=new JLabel("Take cash here");
	JTextField field1=new JTextField();
	JLabel label2=new JLabel("Insert deposit envelope here");
	JTextField field2=new JTextField();
	field1.setBackground(Color.blue);
	field2.setBackground(Color.blue);
	b1.addActionListener(new bAction());
	b2.addActionListener(new bAction());
	b3.addActionListener(new bAction());
	b4.addActionListener(new bAction());
	b5.addActionListener(new bAction());
	b6.addActionListener(new bAction());
	b7.addActionListener(new bAction());
	b8.addActionListener(new bAction());
	b9.addActionListener(new bAction());
	b0.addActionListener(new bAction());
	bDelete.addActionListener(new bAction());
	bEnter.addActionListener(new bAction());

  
   
	p1.add(b1);
	p1.add(b2);
	p1.add(b3);
	p1.add(b4);
	p1.add(b5);
	p1.add(b6);
	p1.add(b7);
	p1.add(b8);
	p1.add(b9);
	p1.add(b0);
	p1.add(bDelete);
	p1.add(bEnter);
	p1.add(label1);
	p1.add(field1);
	p1.add(label2);
	p1.add(field2);
	
	setVisible(true);
	setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    //���ı��������ATMȻ��run()
	atm=new ATM(jt);
    atm.run();
    

	
}
class bAction implements ActionListener{
	public void actionPerformed(ActionEvent e){
		String content = e.getActionCommand();
		switch(content)
		{
		case"1":
		case"2":
		case"3":
		case"4":
		case"5":
		case"6":
		case"7":
		case"8":
		case"9":
		case"0":
			jt.append(content);
			str+=content;
			break;
		case"Backspace":
			int l=str.length();
			str=str.substring(0,l-2 );
			break;
		case"Enter":
			//��Keypad�������һЩ�޸ģ�ʹ��getInput()������return���ı�������Ķ�����
			atm.keypad.input=Integer.valueOf(str).intValue();
			atm.keypad.isInput=true;
			str="";
			break;
		
		}
}
}

	public static void main(String[] args) {
	GUI a=new GUI();
	}

}
