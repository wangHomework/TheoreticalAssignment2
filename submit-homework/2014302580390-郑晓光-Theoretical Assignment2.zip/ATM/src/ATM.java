import javax.swing.JTextArea;

//ATM��
public class ATM {
	private boolean userAuthenticated; // whether user is authenticated�û��Ƿ���֤��
	private int currentAccountNumber; // current user's account number��ȷ���˺�
	private Screen screen; // ATM's screen
	public Keypad keypad; // ATM's keypad
	private CashDispenser cashDispenser; // ATM's cash dispenser�Զ�����
	private DepositSlot depositSlot; // ATM's deposit slotͶ�Ҳ�
	private BankDatabase bankDatabase; // account information database�˻���Ϣ����
	// constants corresponding to main menu options
	private static final int BALANCE_INQUIRY = 1;//����ѯ
	private static final int WITHDRAWAL = 2;//ȡ
	private static final int DEPOSIT = 3;//��
	private static final int EXIT = 4;//�˳�
	
	 // no-argument ATM constructor initializes instance variables�޲����Ĺ��캯��
	 public ATM(JTextArea jt)
	 {
	 userAuthenticated = false; // user is not authenticated to start
	 currentAccountNumber = 0; // no current account number to start
	 screen = new Screen(jt); // create screen
	 keypad = new Keypad(); // create keypad
	 cashDispenser = new CashDispenser(); // create cash dispenser
	 depositSlot = new DepositSlot(); // create deposit slot
	 bankDatabase = new BankDatabase(); // create acct info database
	  } // end no-argument ATM constructor
	 
	 // start ATM
	 public void run()
	  {
	  // welcome and authenticate user��ӭ����֤�û�; perform transactionsִ�н���
	  while ( true )
	  {
	  // loop while user is not yet authenticatedѭ����֤�˻�
	  while ( !userAuthenticated )
	  {
	  screen.displayMessage("\nWelcome");
	  authenticateUser(); // authenticate user//��֤�û�
	  } // end while
	 
	  performTransactions(); // user is now authenticated�û����ڱ���֤��
	  userAuthenticated = false; // reset before next ATM session����һ��ATM�Ựǰ����
	  currentAccountNumber = 0; // reset before next ATM session
	 screen.displayMessageLine( "\nThank you! Goodbye!");
	  } // end while
	  } // end method run
	 
	  
	 // attempts to authenticate user against database���Զ��û�����������֤���ݿ�
	  private void authenticateUser()
	  {
	 screen.displayMessage( "\nPlease enter your account number: ");
	  int accountNumber = keypad.getInput(); // input account number
	 screen.displayMessage( "\nEnter your PIN: "); // prompt for PIN��ʾ
	  int pin = keypad.getInput(); // input PIN
	  // set userAuthenticated to boolean value returned by database��userAuthenticated����Ϊ�������ݷ��ص�bool����
	 userAuthenticated =
	  bankDatabase.authenticateUser( accountNumber, pin );
	 
	  // check whether authentication succeeded�����֤�Ƿ�ɹ�
	  if ( userAuthenticated )
	 {
	  currentAccountNumber = accountNumber; // save user's account #�����˻�
	  } // end if
	  else
	  screen.displayMessageLine(
	  "Invalid account number or PIN. Please try again.\n");
	  } // end method authenticateUser
	 
	  // display the main menu and perform transactions��ʾ��ҳ��ִ�н���
	  private void performTransactions()
	  {
	 // local variable to store transaction currently being processed�����洢��ǰ���ڴ����Ľ��ױ��ر���
	  Transaction currentTransaction = null;
	  boolean userExited = false; // user has not chosen to exit
	 // loop while user has not chosen option to exit system
	   while ( !userExited )
	  {
	  // show main menu and get user selection
	  int mainMenuSelection = displayMainMenu();
	   // decide how to proceed based on user's menu selection
	   switch ( mainMenuSelection )
	   {
	  // user chose to perform one of three transaction types
	  case BALANCE_INQUIRY:
	   case WITHDRAWAL:
	  case DEPOSIT:
	   // initialize as new object of chosen type
	  currentTransaction =
	   createTransaction( mainMenuSelection );
	  currentTransaction.execute(); // execute transaction
	 break;
	   case EXIT: // user chose to terminate session
	   screen.displayMessageLine( "\nExiting the system...");
	   userExited = true; // this ATM session should end
	   break;
	   default: // user did not enter an integer from 1-4
	   screen.displayMessageLine(
	   "\nYou did not enter a valid selection. Try again.");
	   break;
	   } // end switch
	   } // end while
	  } // end method performTransactions
	  
	   // display the main menu and return an input selection
	  private int displayMainMenu()
	   {
	   screen.displayMessageLine( "\nMain menu:");
	   screen.displayMessageLine( "1 - View my balance");
	   screen.displayMessageLine( "2 - Withdraw cash");
	   screen.displayMessageLine( "3 - Deposit funds");
	   screen.displayMessageLine( "4 - Exit\n");
	   screen.displayMessage( "Enter a choice: ");
	   return keypad.getInput(); // return user's selection
	  } // end method displayMainMenu
	 
	  // return object of specified Transaction subclass
	  private Transaction createTransaction( int type )
	   {
	   Transaction temp = null; // temporary Transaction variable
	  switch ( type )
	  {
	   case BALANCE_INQUIRY: // create new BalanceInquiry transaction
	   temp = new BalanceInquiry(
	   currentAccountNumber, screen, bankDatabase );
	  break;
	   case WITHDRAWAL: // create new Withdrawal transaction
	   temp = new Withdrawal( currentAccountNumber, screen,
	  bankDatabase, keypad, cashDispenser );
	   break;
	   case DEPOSIT: // create new Deposit transaction
	   temp = new Deposit( currentAccountNumber, screen,
	   bankDatabase, keypad, depositSlot );
	   break;
	   } // end switch
	 
	   return temp; // return the newly created object
	   } // end method createTransaction
	   }
