package net.zghen.util;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.*;

import static net.zghen.util.Data.*;

public class Atm {
	public static JTextArea screen;
	
	public static JTextField input;
	public static JButton submit;
	
	public static int finish;
	
	private static JFrame frame;
	private static JButton btna;
	
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		finish = 1;
		frame = new JFrame("ATM- welcome");

		input = new JTextField();
		btna = new JButton("INPUT");
		
		btna.setBackground(Color.green);
		btna.addActionListener(new ActionListener(){
	    	   public void actionPerformed(ActionEvent e){
	    		   btnaAction();
	    	   }
	       });
		frame.setLayout(new GridLayout(5,2,100,20));
	//	frame.add(label);
		screen = new JTextArea("welcome");
		screen.setText("ATM\nwelcome\n");
		screen.setSize(frame.getWidth(), 100);
		frame.add(screen);
		frame.add(input);
		frame.add(btna);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 500);
		frame.setLocation(500, 200);
		int balance = (int) (Math.random() * 1000);
		int passwdpass = 0;
		int onceLuck = 1;
		int exitcode = 0;
		while(true){
			if(exitcode == 1){
				break;
			}
			screen.setText(welcome);
			finish = 0;
			mywait();
			screen.setText("please input passwd:");
			finish= 0;
			mywait();
			
			while(true){
				if(Math.random() < 0.7){
					passwdpass++;
					if(passwdpass < 2)
						screen.setText("wrong passwd, forget?\ntry again:");
					else 
						screen.setText("wrong passwd, maybe your birthday conld be ok.\ntry again:");
					finish = 0;
					mywait();
				}
				else{
					screen.setText("ok, you are so *luck*.");
					Thread.sleep(1700);
					break;
				}
			}
			do{
				screen.setText("what do you want to do?\n1:balance\n2: withdrawal\n3: deposit \n4:good luck");
				finish = 0;
				mywait();
				
				if(input.getText().equals("1")){
					screen.setText("you have only " + balance + " yuan.\n");
					btna.setText("back");
					finish = 0;
					mywait();
					btna.setText("INPUT");
				}else if(input.getText().equals("2")){
					screen.setText("ok, hope you have enough money.\ninput the number you want to get:");
					finish = 0;
					mywait();
					if(Integer.parseInt(input.getText()) > balance){
						screen.setText("you don't have enough money, maybe I can borrow you some.\ndon't thanks me.");
						balance = 0;
						Thread.sleep(1500);
						screen.setText("finish...");
						Thread.sleep(1500);
						continue;
					}else{
						screen.setText("you have enough money, wait...");
						balance -= Integer.parseInt(input.getText());
						Thread.sleep(1500);
						screen.setText("finish...");
						Thread.sleep(1500);
					}
				}else if(input.getText().equals("3")){
					screen.setText("Ok, I'm *very* glad to serve you.\nplease input the number:");
					finish = 0;
					mywait();
					if(Math.random() < 0.6){
						screen.setText(">system crash");
						Thread.sleep(1000);
						screen.setText(">system crash.");
						Thread.sleep(1000);
						screen.setText(">system crash..");
						Thread.sleep(1000);
						screen.setText(">system crash...");
						Thread.sleep(1000);
						screen.setText(">system crash....");
						Thread.sleep(1000);
						screen.setText("Trying to resume the system.\nThe money you input may be lost. If there is any info, we will let you know at first time.\ngood luck\n back");
						Thread.sleep(1500);
						screen.setText("Trying to resume the system.\nThe money you input may be lost. If there is any info, we will let you know at first time.\ngood luck\n back..");
						Thread.sleep(1500);
						screen.setText("Trying to resume the system.\nThe money you input may be lost. If there is any info, we will let you know at first time.\ngood luck\n back...");
						Thread.sleep(1500);
						screen.setText("Trying to resume the system.\nThe money you input may be lost. If there is any info, we will let you know at first time.\ngood luck\n back....");
						Thread.sleep(1500);
						screen.setText("Trying to resume the system.\nThe money you input may be lost. If there is any info, we will let you know at first time.\ngood luck\n back.....");
						Thread.sleep(3000);
					}else{
						screen.setText("Ok, good luck to you, maybe you should deposit again.(try again) \nBest service for you");
						balance += Integer.parseInt(input.getText());
						btna.setText("back");
						finish = 0;
						mywait();
						btna.setText("INPUT");
					}
				}else if(input.getText().equals("4")){
					if(Math.random() < 0.5){
						if(onceLuck == 0){
							screen.setText("you get one yuan, using it to 走上人生巅峰\n. Best service for you");
							balance = 1;
							onceLuck = 2;
						}else{
							balance += 404;
							screen.setText("good luck, you get 404 yuan from the server.");
						}
						btna.setText("back");
						finish = 0;
						mywait();
						btna.setText("INPUT");
					}else{
						if(onceLuck == 1){
							screen.setText("you lose all your money, maybe trying another time can help you 走上人生巅峰\n Best service for you");
							balance = 0;
							onceLuck = 0;
						}else{
							int aaa = (int) (Math.random() * 1000);
							if(balance - aaa < 0){
								screen.setText("you lose all. ... a ha ha ");
								balance = 0;
								Thread.sleep(1000);
								screen.setText("you may have this question: where can I exit this system.\n It's here\n input \"exit\" to go out. \n input \"fuck,borrow me some money\" to try again.");
								finish = 0;
								mywait();
								if(input.getText().equals("exit")){
									screen.setText("Best service for you. Good luck");
									Thread.sleep(1700);
									exitcode = 1;
									break;
								}else if(input.getText().equals("fuck,borrow me some money")){
									screen.setText("I love you so much. ");
									Thread.sleep(2000);
								}else{
									screen.setText("oh, maybe you need money, see you balance, ");
									Thread.sleep(3000);
								}
							}else{
								screen.setText("Wrong place for you, lose money "+ aaa + " yuan.");
								balance -= aaa;
							}
						}
						
						btna.setText("back");
						finish = 0;
						mywait();
						btna.setText("INPUT");
						
					}
				}
			}while(exitcode == 0);
			
		}
		System.exit(0);
	}
	public static  void mywait(){
		if(finish == 1){
			return;
		}
		input.setText("");
		while(finish == 0){
			try {
				//Thread.currentThread();
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return;
	}
	public static void btnaAction(){
		finish = 1;
	}
}


