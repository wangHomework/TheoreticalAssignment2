package net.zghen.util;

public class Data {
	static public  String welcome = "welcome\n please input your id:";
	

}
