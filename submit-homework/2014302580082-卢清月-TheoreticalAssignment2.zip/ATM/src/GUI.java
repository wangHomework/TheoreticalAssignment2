import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public  class GUI extends Frame  {	
     JLabel jl = new JLabel("Write your amout");
	 public ATM  atm;
	 private String input = "";
   	 private JTextArea textarea = new JTextArea();
     private Keypad keypad;
     public  GUI(){
     //���ô���
     this.setResizable(false);	 
     this.setTitle( "Welcome to ATM" );
     this.setSize(600,550);
     this.setBackground(Color.pink);
     this.setVisible(true);
     setLayout(null);

     //��ʼ�������
     textarea.setOpaque(true);
     textarea.setEditable(false);
     textarea.setBounds(20, 200, 455, 20);
    
     //��ʼ�������
     JTextArea output = new JTextArea();
     output.setLineWrap(true);
     output.setOpaque(true);
     output.setEditable(false);
     JScrollPane panel = new JScrollPane(output);
     panel.setBounds(10, 10, 455, 180);
    
     //���ı��������JScrollPane��
     JScrollPane scrollPane = new JScrollPane(textarea);
     scrollPane.setBounds(65, 30, 400, 120);
     scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
     add(scrollPane);
     
     //���������ð�ť
        JButton b1=new JButton("1");
		add(b1);
		b1.setBounds(10,200,60,40);
		JButton b2=new JButton("2");
		add(b2);
		b2.setBounds(80,200,60,40);
		JButton b3=new JButton("3");
		add(b3);
		b3.setBounds(150,200,60,40);
		JButton b4=new JButton("4");
		add(b4);
		b4.setBounds(10,270,60,40);
		JButton b5=new JButton("5");
		add(b5);
		b5.setBounds(80,270,60,40);
		JButton b6=new JButton("6");
		add(b6);
		b6.setBounds(150,270,60,40);
		JButton b7=new JButton("7");
		add(b7);
		b7.setBounds(10,340,60,40);
		JButton b8=new JButton("8");
		add(b8);
		b8.setBounds(80,340,60,40);
		JButton b9=new JButton("9");
		add(b9);
		b9.setBounds(150,340,60,40);
		JButton b0=new JButton("0");
		add(b0);
		b0.setBounds(10,410,60,40);
		JButton be=new JButton("Enter");
		add(be);
		be.setBounds(80,410,130,40);
				
		//�԰�ť���Ӽ����¼�
		//��ť0��9
		b1.addActionListener(new ActionListener() { 			
			public void actionPerformed(ActionEvent e) {
				textarea.setText(textarea.getText()+"1");
				get_input("1");		
			}
			private void get_input(String string) {
				// TODO Auto-generated method stub				
			}		
		});
		
		b2.addActionListener(new ActionListener() { 			
			public void actionPerformed(ActionEvent e) {
				textarea.setText(textarea.getText()+"2");
				get_input("2");		
			}
			private void get_input(String string) {
				// TODO Auto-generated method stub				
			}		
		});
		
		b3.addActionListener(new ActionListener() { 			
			public void actionPerformed(ActionEvent e) {
				textarea.setText(textarea.getText()+"3");
				get_input("3");		
			}
			private void get_input(String string) {
				// TODO Auto-generated method stub				
			}		
		});
		
		b4.addActionListener(new ActionListener() { 			
			public void actionPerformed(ActionEvent e) {
				textarea.setText(textarea.getText()+"4");
				get_input("4");		
			}
			private void get_input(String string) {
				// TODO Auto-generated method stub				
			}		
		});
		
		b5.addActionListener(new ActionListener() { 			
			public void actionPerformed(ActionEvent e) {
				textarea.setText(textarea.getText()+"5");
				get_input("5");		
			}
			private void get_input(String string) {
				// TODO Auto-generated method stub				
			}		
		});
		
		b6.addActionListener(new ActionListener() { 			
			public void actionPerformed(ActionEvent e) {
				textarea.setText(textarea.getText()+"6");
				get_input("6");		
			}
			private void get_input(String string) {
				// TODO Auto-generated method stub				
			}		
		});
		
		b7.addActionListener(new ActionListener() { 			
			public void actionPerformed(ActionEvent e) {
				textarea.setText(textarea.getText()+"7");
				get_input("7");		
			}
			private void get_input(String string) {
				// TODO Auto-generated method stub				
			}		
		});
		
		b8.addActionListener(new ActionListener() { 			
			public void actionPerformed(ActionEvent e) {
				textarea.setText(textarea.getText()+"8");
				get_input("8");		
			}
			private void get_input(String string) {
				// TODO Auto-generated method stub				
			}		
		});
		
		b9.addActionListener(new ActionListener() { 			
			public void actionPerformed(ActionEvent e) {
				textarea.setText(textarea.getText()+"9");
				get_input("9");		
			}
			private void get_input(String string) {
				// TODO Auto-generated method stub				
			}		
		});
		
		b0.addActionListener(new ActionListener() { 			
			public void actionPerformed(ActionEvent e) {
				textarea.setText(textarea.getText()+"0");
				get_input("0");		
			}
			private void get_input(String string) {
				// TODO Auto-generated method stub				
			}		
		});
		
		
		//"ENTER"��ť
		be.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                synchronized (keypad) {
                    keypad.notify();
                }
            }
     });
		
	 
     }
     
     public int userInput() {
         int number = Integer.parseInt(this.input);
         input = "";
         return number;
     }
     //������
     public static void main(String[] args) {
 		GUI mygui = new GUI();
 	
 		 mygui.atm.run();
 		
 		
     }
}

