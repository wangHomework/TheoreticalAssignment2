package atmdemo;

import javax.swing.JTextArea;

public abstract class Transaction {
	private int accountNumber; // indicates account involved
	private BankDatabase bankDatabase; // account info database
	
	protected JTextArea textArea=new JTextArea();
	// Transaction constructor invoked by subclasses using super()
	public Transaction(int userAccountNumber, BankDatabase atmBankDatabase,JTextArea atmTextArea) {
		accountNumber = userAccountNumber;
		bankDatabase = atmBankDatabase;
		textArea=atmTextArea;
	} // end Transaction constructor

	// return account number
	public int getAccountNumber() {
		return accountNumber;
	}

	// end method getAccountNumber

	// return reference to bank database
	public BankDatabase getBankDatabase() {
		return bankDatabase;
	} // end method getBankDatabase

	// perform the transaction (overridden by each subclass)
	abstract public void execute(JTextArea atmTextArea,int number);

} // end class Transaction
