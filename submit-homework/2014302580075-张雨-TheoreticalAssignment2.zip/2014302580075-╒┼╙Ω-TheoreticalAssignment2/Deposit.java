package atmdemo;

import javax.swing.JTextArea;

public class Deposit extends Transaction {
	private double amount; // amount to deposit
	private DepositSlot depositSlot; // reference to deposit slot
	private final static int CANCELED = -1; // constant for cancel option
	private JTextArea textArea=new JTextArea();

	// Deposit constructor
	public Deposit(int userAccountNumber, BankDatabase atmBankDatabase,
			DepositSlot atmDepositSlot,JTextArea atmTextArea) {
		// initialize superclass variables
		super(userAccountNumber,  atmBankDatabase,atmTextArea);

		depositSlot = atmDepositSlot;
	} // end Deposit constructor

	// perform transaction
	@Override
	public void execute(JTextArea atmTextArea,int depositNumber) {
		BankDatabase bankDatabase = getBankDatabase(); // get reference
		textArea=atmTextArea;
		
		// get deposit amount from user
		amount=(double)depositNumber/100;
		// check whether user entered a deposit amount or canceled
		if (amount != CANCELED) {
			// request deposit envelope containing specified amount
			textArea.append("\nPlease insert a deposit envelope containing ");
			textArea.append(Double.toString(amount));
			textArea.append(".");
			// receive deposit envelope
			boolean envelopeReceived = depositSlot.isEnvelopeReceived();

			// check whether deposit envelope was received
			if (envelopeReceived) {
				textArea.append("\nYour envelope has been "
						+ "received.\nNOTE: The money just deposited will not "
						+ "be \n available until we verify the amount of any\n " + "enclosed cash and your checks clear.\n");
				
				// credit account to reflect the deposit
				bankDatabase.credit(getAccountNumber(), amount);
			} // end if
			else // deposit envelope not received
			{
				textArea.append("\nYou did not insert an " + "envelope, \n so the ATM has canceled your transaction.");
			} // end else
		} // end if
		else // user canceled instead of entering amount
		{
			textArea.append("\nCanceling transaction...");
		} // end else
	} // end method execute
} // end class Deposit
