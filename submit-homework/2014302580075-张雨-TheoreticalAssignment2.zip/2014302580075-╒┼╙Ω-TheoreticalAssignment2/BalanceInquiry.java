package atmdemo;

import javax.swing.JTextArea;

public class BalanceInquiry extends Transaction {
	// BalanceInquiry constructor
	public BalanceInquiry(int userAccountNumber,BankDatabase atmBankDatabase,JTextArea atmTextArea) {
		super(userAccountNumber,atmBankDatabase,atmTextArea);
	} // end BalanceInquiry constructor

	// performs the transaction
	@Override
	public void execute(JTextArea atmTextArea,int number) {
		// get references to bank database and screen
		BankDatabase bankDatabase = getBankDatabase();
		JTextArea textArea=atmTextArea;

		// get the available balance for the account involved
		double availableBalance = bankDatabase.getAvailableBalance(getAccountNumber());

		// get the total balance for the account involved
		double totalBalance = bankDatabase.getTotalBalance(getAccountNumber());

		// display the balance information on the screen
		textArea.append("\nBalance Information:\n");
		textArea.append(" - Available balance: ");
		textArea.append(Double.toString(availableBalance));
		textArea.append("\n - Total balance: ");
		textArea.append(Double.toString(totalBalance));
		textArea.append("");
	} // end method execute

	
}
