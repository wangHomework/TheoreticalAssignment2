package atmdemo;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

public class ATMGUI extends JFrame {
	//UI�������
	private JPanel contentPane;
	private JButton button_1 = new JButton("1");
	private JButton button_2 = new JButton("2");
	private JButton button_3 = new JButton("3");
	private JButton button_4 = new JButton("4");
	private JButton button_5 = new JButton("5");
	private JButton button_6 = new JButton("6");
	private JButton button_7 = new JButton("7");
	private JButton button_8 = new JButton("8");
	private JButton button_9 = new JButton("9");
	private JButton button_0 = new JButton("0");
	private JButton btnEnter = new JButton("Enter");
	private JButton btnTakecashhere = new JButton("TakeCashHere");
	private JButton btnNewButton = new JButton("InsertDepositEnvelopeHere");
	private JLabel lblAtm = new JLabel("ATM");
	private JScrollPane scrollPane = new JScrollPane();
	private JTextArea textArea = new JTextArea();
	private JButton button_Inquiry = new JButton("\u4F59\u989D\u67E5\u8BE2");
	private JButton button_Deposit = new JButton("\u5B58\u94B1");
	private JButton button_Withdral = new JButton("\u53D6\u94B1");
	private JButton button_Exit = new JButton("\u9000\u51FA");
	private String account=""; 
	private String psw="";
	private String number="";
	private int depositNumber;
	private int withdrawOrder;
	//��������¼�����
	private static  int EVENT=5;
	private static final int BALANCE_INQUIRY = 1;
	private static final int WITHDRAWAL = 2;
	private static final int DEPOSIT = 3;
	private static final int EXIT = 4;
	private static final int INPUTACCOUNT=5;
	private static final int INPUTPSW=6;
	
	//ATM�������
	
	private boolean userAuthenticated; // whether user is authenticated
	private int currentAccountNumber; // current user's account number
	private CashDispenser cashDispenser; // ATM's cash dispenser
	private DepositSlot depositSlot; // ATM's deposit slot
	private BankDatabase bankDatabase; // account information database
	// constants corresponding to main menu options
	
	
	/**
	 * Create the frame.���캯��
	 */
	public ATMGUI() {
		//��ʼ��ATM
		userAuthenticated = false; // user is not authenticated to start
		currentAccountNumber = 0; // no current account number to start		
		cashDispenser = new CashDispenser(); // create cash dispenser
		depositSlot = new DepositSlot(); // create deposit slot
		bankDatabase = new BankDatabase(); // create acct info database
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 496, 409);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		button_1.setBounds(0, 290, 50, 30);
		contentPane.add(button_1);
		button_2.setBounds(60, 290, 50, 30);
		contentPane.add(button_2);
		button_3.setBounds(120, 290, 50, 30);
		contentPane.add(button_3);
		button_4.setBounds(0, 250, 50, 30);
		contentPane.add(button_4);
		button_5.setBounds(60, 250, 50, 30);
		contentPane.add(button_5);
		button_6.setBounds(120, 250, 50, 30);
		contentPane.add(button_6);
		button_7.setBounds(0, 210, 50, 30);
		contentPane.add(button_7);
		button_8.setBounds(60, 210, 50, 30);
		contentPane.add(button_8);
		button_9.setBounds(120, 210, 50, 30);
		
		
		contentPane.add(button_9);
		button_0.setBounds(0, 330, 49, 30);
		contentPane.add(button_0);
		btnEnter.setBounds(60, 330, 110, 30);
		contentPane.add(btnEnter);
		btnTakecashhere.setBounds(288, 210, 182, 66);
		contentPane.add(btnTakecashhere);
		btnNewButton.setBounds(288, 283, 182, 66);
		
		contentPane.add(btnNewButton);
		lblAtm.setBounds(221, 10, 27, 20);
		contentPane.add(lblAtm);
		
		
		scrollPane.setBounds(10, 40, 460, 160);
		contentPane.add(scrollPane);
		
		
		scrollPane.setViewportView(textArea);
		
		
		
		button_Inquiry.setBounds(185, 210, 93, 23);
		contentPane.add(button_Inquiry);
		button_Inquiry.setEnabled(false);
		
		
		button_Deposit.setBounds(185, 250, 93, 23);
		contentPane.add(button_Deposit);
		button_Deposit.setEnabled(false);
		
		
		button_Withdral.setBounds(185, 294, 93, 23);
		contentPane.add(button_Withdral);
		button_Withdral.setEnabled(false);
		
		
		button_Exit.setBounds(185, 334, 93, 23);
		contentPane.add(button_Exit);
		button_Exit.setEnabled(false);
	}
	
	
	/**
	 * Launch the application.
	 */
	public void run() {
		
		this.setVisible(true);
		
		textArea.append("Welcome!\nPlease enter your account number: ");
		button_0.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				switch (EVENT) {
				case INPUTACCOUNT:
					textArea.setText(textArea.getText()+button_0.getText());
					account=account+button_0.getText();					
					break;
				case INPUTPSW:
					textArea.setText(textArea.getText()+button_0.getText());
					psw=psw+button_0.getText();
					break;
				case DEPOSIT:
					textArea.setText(textArea.getText()+button_0.getText());
					number=number+button_0.getText();
					break;
				case WITHDRAWAL:
					textArea.setText(textArea.getText()+button_0.getText());
					number=number+button_0.getText();
					break;
				default:
					break;
				}
			}
			
		});
		button_1.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				switch (EVENT) {
				case INPUTACCOUNT:
					textArea.setText(textArea.getText()+button_1.getText());
					account=account+button_1.getText();
					break;
				case INPUTPSW:
					textArea.setText(textArea.getText()+button_1.getText());
					psw=psw+button_1.getText();
					break;
				case DEPOSIT:
					textArea.setText(textArea.getText()+button_1.getText());
					number=number+button_1.getText();
					break;
				case WITHDRAWAL:
					textArea.setText(textArea.getText()+button_1.getText());
					number=number+button_1.getText();
					break;
				default:
					break;
				}
			}
			
		});
		button_2.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				switch (EVENT) {
				case INPUTACCOUNT:
					textArea.setText(textArea.getText()+button_2.getText());
					account=account+button_2.getText();
					
					break;
				case INPUTPSW:
					textArea.setText(textArea.getText()+button_2.getText());
					psw=psw+button_2.getText();
					break;
				case DEPOSIT:
					textArea.setText(textArea.getText()+button_2.getText());
					number=number+button_2.getText();
					break;
				case WITHDRAWAL:
					textArea.setText(textArea.getText()+button_2.getText());
					number=number+button_2.getText();
					break;
				default:
					break;
				}
			}
			
		});
		button_3.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				switch (EVENT) {
				case INPUTACCOUNT:
					textArea.setText(textArea.getText()+button_3.getText());
					account=account+button_3.getText();
					
					break;
				case INPUTPSW:
					textArea.setText(textArea.getText()+button_3.getText());
					psw=psw+button_3.getText();
					break;
				case DEPOSIT:
					textArea.setText(textArea.getText()+button_3.getText());
					number=number+button_3.getText();
					break;
				case WITHDRAWAL:
					textArea.setText(textArea.getText()+button_3.getText());
					number=number+button_3.getText();
					break;
				default:
					break;
				}
			}
			
		});
		button_4.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				switch (EVENT) {
				case INPUTACCOUNT:
					textArea.setText(textArea.getText()+button_4.getText());
					account=account+button_4.getText();
					
					break;
				case INPUTPSW:
					textArea.setText(textArea.getText()+button_4.getText());
					psw=psw+button_4.getText();
					break;
				case DEPOSIT:
					textArea.setText(textArea.getText()+button_4.getText());
					number=number+button_4.getText();
					break;
				case WITHDRAWAL:
					textArea.setText(textArea.getText()+button_4.getText());
					number=number+button_4.getText();
					break;
				default:
					break;
				}
			}
			
		});
		button_5.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				switch (EVENT) {
				case INPUTACCOUNT:
					textArea.setText(textArea.getText()+button_5.getText());
					account=account+button_5.getText();
					
					break;
				case INPUTPSW:
					textArea.setText(textArea.getText()+button_5.getText());
					psw=psw+button_5.getText();
					break;
				case DEPOSIT:
					textArea.setText(textArea.getText()+button_5.getText());
					number=number+button_5.getText();
					break;
				case WITHDRAWAL:
					textArea.setText(textArea.getText()+button_5.getText());
					number=number+button_5.getText();
					break;
				default:
					break;
				}
			}
			
		});
		button_6.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				switch (EVENT) {
				case INPUTACCOUNT:
					textArea.setText(textArea.getText()+button_6.getText());
					account=account+button_6.getText();
					
					break;
				case INPUTPSW:
					textArea.setText(textArea.getText()+button_6.getText());
					psw=psw+button_6.getText();
					break;
				case DEPOSIT:
					textArea.setText(textArea.getText()+button_6.getText());
					number=number+button_6.getText();
					break;
				case WITHDRAWAL:
					textArea.setText(textArea.getText()+button_6.getText());
					number=number+button_6.getText();
					break;
				default:
					break;
				}
			}
			
		});
		button_7.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				switch (EVENT) {
				case INPUTACCOUNT:
					textArea.setText(textArea.getText()+button_7.getText());
					account=account+button_7.getText();
					
					break;
				case INPUTPSW:
					textArea.setText(textArea.getText()+button_7.getText());
					psw=psw+button_7.getText();
					break;
				case DEPOSIT:
					textArea.setText(textArea.getText()+button_7.getText());
					number=number+button_7.getText();
					break;
				case WITHDRAWAL:
					textArea.setText(textArea.getText()+button_7.getText());
					number=number+button_7.getText();
					break;
				default:
					break;
				}
			}
			
		});
		button_8.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				switch (EVENT) {
				case INPUTACCOUNT:
					textArea.setText(textArea.getText()+button_8.getText());
					account=account+button_8.getText();
					
					break;
				case INPUTPSW:
					textArea.setText(textArea.getText()+button_8.getText());
					psw=psw+button_8.getText();
					break;
				case DEPOSIT:
					textArea.setText(textArea.getText()+button_8.getText());
					number=number+button_8.getText();
					break;
				case WITHDRAWAL:
					textArea.setText(textArea.getText()+button_8.getText());
					number=number+button_8.getText();
					break;
				default:
					break;
				}
			}
			
		});
		button_9.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				switch (EVENT) {
				case INPUTACCOUNT:
					textArea.setText(textArea.getText()+button_9.getText());
					account=account+button_9.getText();					
					break;
				case INPUTPSW:
					textArea.setText(textArea.getText()+button_9.getText());
					psw=psw+button_9.getText();
					break;
				case DEPOSIT:
					textArea.setText(textArea.getText()+button_9.getText());
					number=number+button_9.getText();
					break;
				case WITHDRAWAL:
					textArea.setText(textArea.getText()+button_9.getText());
					number=number+button_9.getText();
					break;
				default:
					break;
				}
			}
			
		});
		btnEnter.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO �Զ����ɵķ������
				switch (EVENT) {
				case INPUTACCOUNT:
					
					EVENT=INPUTPSW;
					textArea.setText(textArea.getText()+"\nEnter your PIN: ");
					break;
				case INPUTPSW:
					
					userAuthenticated = bankDatabase.authenticateUser(Integer.parseInt(account), Integer.parseInt(psw));
					// check whether authentication succeeded
					if (userAuthenticated) {
						currentAccountNumber = Integer.parseInt(account); // save user's account #
						textArea.append("\n��¼�ɹ�����ʼ�����ɣ�");
						button_Deposit.setEnabled(true);
						button_Exit.setEnabled(true);
						button_Inquiry.setEnabled(true);
						button_Withdral.setEnabled(true);
					} // end if
					else {
						account="";
						psw="";
						number="";
						textArea.setText(textArea.getText()+"\n Invalid account number or PIN. Please try again.\n");
						textArea.append("\nPlease enter your account number: ");
						EVENT=INPUTACCOUNT;
					}
						
					break;
				case WITHDRAWAL:
					withdrawOrder=Integer.parseInt(number);
					number="";
					Transaction withdrawal=createTransaction(WITHDRAWAL);
					withdrawal.execute(textArea,withdrawOrder);
					break;
				case DEPOSIT:
					depositNumber=Integer.parseInt(number);
					number="";
					Transaction deposit=createTransaction(DEPOSIT);
					deposit.execute(textArea,depositNumber);
					
					break;
				default:
					break;
				}
			}
			
		});
		button_Inquiry.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				EVENT=BALANCE_INQUIRY;
				if (EVENT==BALANCE_INQUIRY) {
					Transaction balanceInquiry=createTransaction(BALANCE_INQUIRY);
					balanceInquiry.execute(textArea,0);
				}
			}
			
		});
		button_Deposit.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				EVENT=DEPOSIT;
				if (EVENT==DEPOSIT) {
					
					textArea.append("\nPlease enter a deposit amount in CENTS (or 0 to cancel): ");
					EVENT=DEPOSIT;
				}
				
			}
			
		});
		button_Withdral.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				EVENT=WITHDRAWAL;
				if (EVENT==WITHDRAWAL) {
					textArea.append("\nWithdrawal Menu:\n");
					textArea.append("1 - $20\n");
					textArea.append("2 - $40\n");
					textArea.append("3 - $60\n");
					textArea.append("4 - $100\n");
					textArea.append("5 - $200\n");
					textArea.append("6 - Cancel transaction\n");
					textArea.append("\nChoose a withdrawal amount: \n");
				}
				
			}
			
		});
		button_Exit.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				EVENT=EXIT;
				if (EVENT==EXIT) {
					account="";
					psw="";
					number="";
					textArea.setText(textArea.getText()+"\nExiting the system...");
					userAuthenticated = false; // reset before next ATM session
					currentAccountNumber = 0; // reset before next ATM session
					textArea.setText("\nThank you! Goodbye!\n");
					EVENT=INPUTACCOUNT;
					textArea.append("\nPlease enter your account number: ");
					button_Deposit.setEnabled(false);
					button_Exit.setEnabled(false);
					button_Inquiry.setEnabled(false);
					button_Withdral.setEnabled(false);
				}
			}
			
		});
	}



	// return object of specified Transaction subclass
	private Transaction createTransaction(int type) {
		Transaction temp = null; // temporary Transaction variable
		switch (type) {
		case BALANCE_INQUIRY: // create new BalanceInquiry transaction
			temp = new BalanceInquiry(currentAccountNumber, bankDatabase,textArea);
			break;
		case WITHDRAWAL: // create new Withdrawal transaction
			temp = new Withdrawal(currentAccountNumber, bankDatabase, cashDispenser,textArea);
			break;
		case DEPOSIT: // create new Deposit transaction
			temp = new Deposit(currentAccountNumber, bankDatabase, depositSlot,textArea);
			break;
		} // end switch

		return temp; // return the newly created object
	} // end method createTransaction
	
}

