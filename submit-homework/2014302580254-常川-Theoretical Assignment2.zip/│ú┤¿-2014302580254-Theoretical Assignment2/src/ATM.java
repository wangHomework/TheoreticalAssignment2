import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import java.awt.FlowLayout;

import javax.swing.JTextArea;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;


public class ATM extends JFrame {
	private boolean userAuthenticated; // whether user is authenticated
	private BankDatabase bankDatabase; // account information database
	private int currentAccountNumber; // no-argument ATM constructor initializes instance variables
	 public ATM()
	 {
    	userAuthenticated = false; // user is not authenticated to start
    	currentAccountNumber = 0; // no current account number to start
	 	bankDatabase = new BankDatabase(); // create acct info database
	 } // end no-argument ATM constructor
	 	// start ATM
	
    
	 public void run()
	 {
	 	// welcome and authenticate user; perform transactions
	 	// loop while user is not yet authenticated
	 	//��¼�����ʵ��
	 	JFrame beginFrame = new JFrame();
	 	beginFrame.setTitle("ATM");
	 	beginFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
	 	beginFrame.setBounds(300,300,500,300);
	 	beginFrame.setVisible(true);
	 	beginFrame.setResizable(false);
	 	JPanel panel = new JPanel();
	 	panel.setLayout(null);
	 	beginFrame.add(panel);
	 	JLabel label1 = new JLabel();
	 	//���õ�¼�������ʾ
	 	label1.setText("ATM");
	 	label1.setBounds(230,0,100,100);
	 	 label1.setFont(new Font("",Font.ITALIC,30));
	 	 label1.setForeground(Color.BLUE);
	 	panel.add(label1);
	 	//�����˻�������������ʾ
	 	JLabel accountLabel = new JLabel();
	 	accountLabel.setText("Account:");
	 	accountLabel.setBounds(80,80,50,50);
	 	panel.add(accountLabel);
	 	JLabel pinLabel = new JLabel();
	 	pinLabel.setText("Password:");
	 	pinLabel.setBounds(73,140,80,50);
	 	panel.add(pinLabel);
	 	//�˻�����ʵ��
	 	JTextField accountField = new JTextField(30);
	 	panel.add(accountField);
	 	accountField.setBounds(135,80,200,40);
	 	//��������ʵ��
	 	JPasswordField pinField = new JPasswordField(30);
	 	panel.add(pinField);
	 	pinField.setBounds(135,140,200,40);
	 	//ͨ��Enter����½ATM
	 	JButton enterButton = new JButton("Enter");
	 	panel.add(enterButton);
	 	enterButton.setBounds(190,200,80,50);
	 	//Enter���İ�ť����¼�
	 	enterButton.addActionListener(new ActionListener() { 

	            @Override 

	            public void actionPerformed(ActionEvent e) {
	            	//�ж�������û����Ƿ�����Լ������Ƿ���ȷ
	            	String account=accountField.getText();
	            	char[] pass = pinField.getPassword();
	            	String password = new String(pass);
	            	userAuthenticated =
	    	 				bankDatabase.authenticateUser( Integer.parseInt(account), Integer.parseInt(password));
	            	currentAccountNumber = Integer.parseInt(account);
	            	//ʵ�ֲ�������
	            	class Frame2 extends JFrame
	            	{	
	            		
	            		public Frame2()
	            		{
	            			 bankDatabase = new BankDatabase();
	            			 //���ò�������Ĳ���
	            			this.setVisible(true);
	            			this.setBounds(80,80,800,600);
	            			this.setResizable(false);
	            			JPanel panel = new JPanel();
	            			panel.setLayout(null);
	            			this.add(panel);
	            			//������ʾ��Ϣ�����û���������
	            			String str1 = "Main menu:";
	            			JLabel label1 = new JLabel(str1);
	            			panel.add(label1);
	            			label1.setFont(new Font("",Font.ITALIC,15));
	            			label1.setBounds(0,0,100,50);
	            			
	            			String str2 = "1 - View my balance;";
	            			JLabel label2 = new JLabel(str2);
	            			panel.add(label2);
	            			label2.setFont(new Font("",Font.ITALIC,15));
	            			label2.setBounds(40,20,200,50);
	            			
	            			String str3 = "2 - Withdraw cash;" ;
	            			JLabel label3 = new JLabel(str3);
	            			panel.add(label3);
	            			label3.setFont(new Font("",Font.ITALIC,15));
	            			label3.setBounds(40,40,200,50);
	            			
	            			String str4 = "3 - Deposit funds;";
	            			JLabel label4 = new JLabel(str4);
	            			panel.add(label4);
	            			label4.setFont(new Font("",Font.ITALIC,15));
	            			label4.setBounds(40,60,200,50);
	            			
	            			String str5 = "4 - Exit\n;" ;
	            			JLabel label5 = new JLabel(str5);
	            			panel.add(label5);
	            			label5.setFont(new Font("",Font.ITALIC,15));
	            			label5.setBounds(40,80,200,50);
	            			
	            			String str6 =  "Enter a choice: "  ;
	            			JLabel label6 = new JLabel(str6);
	            			panel.add(label6);
	            			label6.setFont(new Font("",Font.ITALIC,15));
	            			label6.setBounds(0,120,200,50);
	            			
	            			String str7 =  "Enter the number you want to withdrew: "  ;
	            			JLabel label7 = new JLabel(str7);
	            			panel.add(label7);
	            			label7.setFont(new Font("",Font.ITALIC,15));
	            			label7.setBounds(0,210,300,50);
	            			
	            			//��ʾ���������
	            			JTextArea text = new JTextArea(200,200);
	            			panel.add(text);
	            			text.setBounds(0,350,800,450);
	            			
	            			
	            			//���ò�����ť���û���ͨ������ĸ���ťʵ��ǰ���ᵽ���ĸ�����
	            			JButton button1 = new JButton("1");
	            			panel.add(button1);
	            			button1.setBounds(40,170,80,40);
	            			button1.addActionListener(new ActionListener() { 

	            	            @Override 

	            	            public void actionPerformed(ActionEvent e) {
	            	            	text.setText("");
	            	            	text.append("Balance Information:"+"\r\n"+"\r\n");
	            	            	text.append("- Available balance:"+bankDatabase.getAvailableBalance(Integer.parseInt(account))
	            	            			+"\r\n"+"\r\n");
	            	            	text.append(" - Total balance:"+bankDatabase.getTotalBalance(Integer.parseInt(account)));
	            	            }
	            	         });
	            			
	            			JButton button2 = new JButton("2");
	            			panel.add(button2);
	            			button2.setBounds(180,170,80,40);
	            			button2.addActionListener(new ActionListener() { 

	            	            @Override 

	            	            public void actionPerformed(ActionEvent e) {
	            	            	text.setText("");
	            	            	text.append("Withdrawal Menu:"+"\r\n");
	            	            	text.append("1 - $20" +"\r\n");
	            	            	text.append("2 - $40" +"\r\n");
	            	            	text.append("3 - $60" +"\r\n");
	            	            	text.append("4 - $100" +"\r\n");
	            	            	text.append("5 - $200" +"\r\n");
	            	            	text.append("6 - Cancel transaction" +"\r\n");
	            	            	
	            	            }
	            	         });
	            			
	            			JButton button3 = new JButton("3");
	            			panel.add(button3);
	            			button3.setBounds(320,170,80,40);
	            			button3.addActionListener(new ActionListener() { 

	            	            @Override 

	            	            public void actionPerformed(ActionEvent e) {
	            	            	text.setText("Please enter a deposit amount in CENTS(ͨ��������textArea������Ȼ��enter������):");
	            	            	text.append("\r\n"+"                    ");
	            	            	
	            	            }
	            	         });
	            			
	            			//����enter���������û���Ǯ����Ŀ
	            			JButton enterButton = new JButton("Enter");
	            			panel.add(enterButton);
	            			enterButton.setBounds(660,280,80,40);
	            			
	            			enterButton.addActionListener(new ActionListener() { 

	            	            @Override 

	            	            public void actionPerformed(ActionEvent e) {
	            	            	String string2 = text.getText();
	            	            	Pattern p = Pattern.compile("[0-9]");
	            	            	Matcher m = p.matcher(string2);
	            	            	String str = "";
	            	            	text.setText("");
	            	            	while(m.find())
	            	            	{
	            	            		str +=m.group();
	            	            		if(str != "")
		            	            	{
		            	            		text.setText("Please insert a deposit envelope containing "+str+"\r\n" +"\r\n");
		            	            		text.append("Your envelope has been received."+"\r\n");
		            	            		text.append("NOTE: The money just deposited will not be available until we verify the amount of any enclosed cash and your checks clear."+"\r\n");

		            	            	}
	            	            	}
	            	            }
	            	         });
	            			
	            			
	            			JButton button4 = new JButton("4");
	            			panel.add(button4);
	            			button4.setBounds(460,170,80,40);
	            			button4.addActionListener(new ActionListener() { 

	            	            @Override 

	            	            public void actionPerformed(ActionEvent e) {
	            	            	System.exit(0);

	            	            }
	            	         });
	            			
	            			//���ð�ť�������û�ȡǮ��Ŀ
	            			JButton button5 = new JButton("1");
	            			panel.add(button5);
	            			button5.setBounds(0,280,80,40);
	            			
	            			button5.addActionListener(new ActionListener() { 

	            	            @Override 

	            	            public void actionPerformed(ActionEvent e) {
	            	            	text.setText("\r\n"+"\r\n"+"\r\n"+"                    $20 has been dispensed. Please take your cash now.");
	            	            }
	            	         });
	            			
	            			JButton button6 = new JButton("2");
	            			panel.add(button6);
	            			button6.setBounds(110,280,80,40);
	            			
	            			button6.addActionListener(new ActionListener() { 

	            	            @Override 

	            	            public void actionPerformed(ActionEvent e) {
	            	            	text.setText("\r\n"+"\r\n"+"\r\n"+"                    $40 has been dispensed. Please take your cash now.");
	            	            }
	            	         });
	            			
	            			JButton button7 = new JButton("3");
	            			panel.add(button7);
	            			button7.setBounds(220,280,80,40);
	            			
	            			button7.addActionListener(new ActionListener() { 

	            	            @Override 

	            	            public void actionPerformed(ActionEvent e) {
	            	            	text.setText("\r\n"+"\r\n"+"\r\n"+"                    $60 has been dispensed. Please take your cash now.");
	            	            }
	            	         });
	            			
	            			JButton button8 = new JButton("4");
	            			panel.add(button8);
	            			button8.setBounds(330,280,80,40);
	            			
	            			button8.addActionListener(new ActionListener() { 

	            	            @Override 

	            	            public void actionPerformed(ActionEvent e) {
	            	            	text.setText("\r\n"+"\r\n"+"\r\n"+"                    $100 has been dispensed. Please take your cash now.");
	            	            }
	            	         });
	            			
	            			JButton button9 = new JButton("5");
	            			panel.add(button9);
	            			button9.setBounds(440,280,80,40);
	            			
	            			button9.addActionListener(new ActionListener() { 

	            	            @Override 

	            	            public void actionPerformed(ActionEvent e) {
	            	            	text.setText("\r\n"+"\r\n"+"\r\n"+"                     $200 has been dispensed. Please take your cash now.");
	            	            }
	            	         });
	            			
	            			JButton button11 = new JButton("6");
	            			panel.add(button11);
	            			button11.setBounds(550,280,80,40);
	            			
	            			button11.addActionListener(new ActionListener() { 

	            	            @Override 

	            	            public void actionPerformed(ActionEvent e) {
	            	            	text.setText("\r\n"+"\r\n"+"\r\n"+"                    You have canceled the withdrawl");

	            	            }
	            	         });
	            		}
	            	}
	            	//ͨ��if-else�ж��û�������˻��������Ƿ����
	            	if(userAuthenticated )
	            	{
	            	
	            	new Frame2();//����˻���������������ȷ��������������
	            	}
	            	else
	            	{
	            		//����û�������󣬵�����ʾ�򲢰��˻�����������������Ϊ��
	            		JOptionPane.showMessageDialog(beginFrame.getContentPane(),
	            				"�û�����������������!", "ϵͳ��Ϣ", JOptionPane.INFORMATION_MESSAGE);
	            		accountField.setText("");
	            		pinField.setText("");

	            	}

	            } 

	        });
	 	 
	 } 
	 
	
}
