public class BalanceInquiry extends Transaction
 {public double availableBalance;
 public double totalBalance ;
 // BalanceInquiry constructor
 public BalanceInquiry( int userAccountNumber, BankDatabase atmBankDatabase,MianMenu frame )
 {
	 super( userAccountNumber, atmBankDatabase );
 } // end BalanceInquiry constructor

 // performs the transaction

 public void execute()
 {
	// get references to bank database and screen
	  BankDatabase bankDatabase = getBankDatabase();
	 
	  // get the available balance for the account involved
	  availableBalance =
	  bankDatabase.getAvailableBalance( getAccountNumber() );
	 
	  // get the total balance for the account involved
	  totalBalance =
	  bankDatabase.getTotalBalance( getAccountNumber() );
	  }
 
 }