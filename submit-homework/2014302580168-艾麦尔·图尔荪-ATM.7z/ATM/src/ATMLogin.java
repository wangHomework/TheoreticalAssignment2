import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ATMLogin extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	private boolean userAuthenticated; // whether user is authenticated
    static	public int currentAccountNumber;// current user's account number
	private MianMenu menu;
	private BankDatabase bankDatabase; 
	private JPanel contentPane;
	private JTextField Accountnumber;
	private JPasswordField passwordField;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ATMLogin frame = new ATMLogin();
					Toolkit toolkit = Toolkit.getDefaultToolkit();

					int x = (int)(toolkit.getScreenSize().getWidth()-frame.getWidth())/2;

					int y = (int)(toolkit.getScreenSize().getHeight()-frame.getHeight())/2;

					frame.setLocation(x, y);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ATMLogin() {
		userAuthenticated=false;
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblWelcome = new JLabel("Welcome\uFF01");
		
		JLabel accounttext = new JLabel("Please enter your account number:");
		
		JLabel pintest = new JLabel(" Enter your PIN:");
		
		Accountnumber = new JTextField();
		Accountnumber.setColumns(10);
		
		passwordField = new JPasswordField();
		
		JButton btnEnterbtn = new JButton("EnterBtn");
		btnEnterbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				authenticateUser();
				if(!userAuthenticated){
					JOptionPane.showMessageDialog(null, "accountnumber or pin is wrong!","Warning",JOptionPane.INFORMATION_MESSAGE,null);
				}
				else{
					menu= new MianMenu();
					menu.setSize(450, 300);
					Toolkit toolkit = Toolkit.getDefaultToolkit();

					int x = (int)(toolkit.getScreenSize().getWidth()-menu.getWidth())/2;

					int y = (int)(toolkit.getScreenSize().getHeight()-menu.getHeight())/2;

					menu.setLocation(x, y);
					menu.setVisible(true);
				}
				
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
							.addGap(177)
							.addComponent(lblWelcome))
						.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addContainerGap()
									.addComponent(accounttext))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(110)
									.addComponent(pintest, GroupLayout.PREFERRED_SIZE, 98, GroupLayout.PREFERRED_SIZE)))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(passwordField, GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
								.addComponent(Accountnumber, GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap(219, Short.MAX_VALUE)
							.addComponent(btnEnterbtn)))
					.addGap(134))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblWelcome)
					.addGap(29)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(accounttext)
						.addComponent(Accountnumber, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(pintest)
						.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(38)
					.addComponent(btnEnterbtn)
					.addContainerGap(86, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
	@SuppressWarnings("deprecation")
	private void authenticateUser(){
		 int accountNumber=Integer.parseInt( Accountnumber.getText());
		int pin =Integer.parseInt(passwordField.getText());
		bankDatabase= new BankDatabase();
		 userAuthenticated =  bankDatabase.authenticateUser( accountNumber, pin ); 
			if(userAuthenticated){
				  currentAccountNumber = accountNumber; // save user's account   
			}
			}
}