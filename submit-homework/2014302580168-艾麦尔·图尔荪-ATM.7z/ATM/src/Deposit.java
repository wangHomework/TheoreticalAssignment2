

public class Deposit extends Transaction
 { private int input;
	private MianMenu menu;
 private double amount; // amount to deposit
// private Keypad keypad; // reference to keypad
 private DepositSlot depositSlot; // reference to deposit slot
 //private final static int CANCELED = 0; // constant for cancel option

 // Deposit constructor
 public Deposit( int userAccountNumber,
 BankDatabase atmBankDatabase,
 DepositSlot atmDepositSlot,int input )
 {
 // initialize superclass variables
 super( userAccountNumber, atmBankDatabase );

 // initialize references to keypad and deposit slot
 //keypad = atmKeypad;
// depositSlot = atmDepositSlot;
 } // end Deposit constructor

 // perform transaction
 @Override
 public void execute()
 {
 BankDatabase bankDatabase = getBankDatabase(); // get reference
 //Screen screen = getScreen(); // get reference

 amount = promptForDepositAmount(); // get deposit amount from user

 // check whether user entered a deposit amount or canceled
 //equst deposit envelope containing specified amount
menu.Firstlebel.setText("Please insert a deposit envelope containing " );
menu.SecendLebel.setText( ""+amount);
menu.ThirdLabel.setText(".");
 // receive deposit envelope
 boolean envelopeReceived = depositSlot.isEnvelopeReceived();

 // check whether deposit envelope was received
 if ( envelopeReceived )
 {menu.Firstlebel.setText( "\nYour envelope has been " +
 "received.\nNOTE: The money just deposited will not " +
 "be available until we verify the amount of any " +
 "enclosed cash and your checks clear." );
 menu.SecendLebel.setText(null);
 menu.ThirdLabel.setText(null);
//credit account to reflect the deposit*/
 bankDatabase.credit( getAccountNumber(), amount );
 } // end if
 else // deposit envelope not received
 {
menu.Firstlebel.setText( "\nYou did not insert an " +
 "envelope, so the ATM has canceled your transaction." );
 } // end else
 }  // end method execute

 // prompt user to enter a deposit amount in cents
 private double promptForDepositAmount()
 {
 //Screen screen = getScreen(); // get reference to screen

 // display the prompt
/* screen.displayMessage( "\nPlease enter a deposit amount in " +
 "CENTS (or 0 to cancel): " );*/
 // receive input of deposit amount

 // check whether the user canceled or entered a valid amount
	
 return ( double )input  / 100; // return dollar amount
 } // end else
 } // end method promptForDepositAmount
  // end class Deposit