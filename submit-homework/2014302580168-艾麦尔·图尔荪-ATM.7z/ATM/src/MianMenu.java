import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
public class MianMenu extends JFrame  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BankDatabase bankDatabase;
	private CashDispenser cashDispenser; // ATM's cash dispenser
	private DepositSlot depositSlot; // ATM's deposit slot
	private BalanceInquiry test;
	JLabel Firstlebel;
	JLabel SecendLebel;
    JLabel ThirdLabel;
    JButton WithdrawCashBtn ;
    JButton ViewmyBalanceBtn;
	JButton DepositfundsBtn ;
	JButton ExitBtn;
	/*
	 * Launch the application.
	 */
/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MianMenu frame = new MianMenu();
					frame.setSize(450, 300);
					Toolkit toolkit = Toolkit.getDefaultToolkit();

					int x = (int)(toolkit.getScreenSize().getWidth()-frame.getWidth())/2;

					int y = (int)(toolkit.getScreenSize().getHeight()-frame.getHeight())/2;

					frame.setLocation(x, y);
					frame.setVisible(true);
				
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public MianMenu() {
		getContentPane().setLayout(new BorderLayout(0, 0));
		JPanel panel_1 = new JPanel();
		getContentPane().add(panel_1, BorderLayout.CENTER);
		
		JLabel Firstlebel = new JLabel("   ");
		
		JLabel SecendLebel = new JLabel("  ");
		
		JLabel ThirdLabel = new JLabel("   ");
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_panel_1.createSequentialGroup()
					.addGap(45)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING)
						.addComponent(ThirdLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE)
						.addComponent(SecendLebel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE)
						.addComponent(Firstlebel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(47)
					.addComponent(Firstlebel)
					.addGap(18)
					.addComponent(SecendLebel)
					.addGap(40)
					.addComponent(ThirdLabel)
					.addContainerGap(111, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.WEST);
		
		JButton ViewmyBalanceBtn = new JButton("View my balance");
		ViewmyBalanceBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		test= new BalanceInquiry(
							ATMLogin.currentAccountNumber, bankDatabase,MianMenu.this);
//		test.execute();
				 Firstlebel.setText("Informations: ");
				 SecendLebel.setText(" Available balance:"+test.availableBalance);
				 ThirdLabel.setText("Total balance:"+test.totalBalance);
			}
		});
		JButton WithdrawCashBtn = new JButton("Withdraw cash");
		WithdrawCashBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s=JOptionPane.showInputDialog(null,"Please input amount to withdraw","Input",JOptionPane.QUESTION_MESSAGE);
				int amount=Integer.parseInt(s);
				new  Withdrawal( ATMLogin.currentAccountNumber,
						bankDatabase,cashDispenser ,amount);
			}
		});
		JButton DepositfundsBtn = new JButton("Deposit funds");
		DepositfundsBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 String s=JOptionPane.showInputDialog(null,"Please enter a deposit amount in","Input",JOptionPane.QUESTION_MESSAGE);
				 int  input =Integer.parseInt(s);
				new Deposit(ATMLogin.currentAccountNumber,
		    			   bankDatabase, depositSlot ,input);
			}
		});
		JButton ExitBtn = new JButton("Exit");
		ExitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});

		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
						.addComponent(ViewmyBalanceBtn, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(WithdrawCashBtn, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(DepositfundsBtn, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(ExitBtn, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(ViewmyBalanceBtn)
					.addGap(50)
					.addComponent(WithdrawCashBtn)
					.addGap(47)
					.addComponent(DepositfundsBtn)
					.addGap(28)
					.addComponent(ExitBtn)
					.addContainerGap(34, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		
		
		
}
}