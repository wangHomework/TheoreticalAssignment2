import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JOptionPane;
import javax.swing.JPanel;



@SuppressWarnings("serial")
public class GUI extends JFrame{
	public JTextArea text;
	public JButton button1;
	public JButton button2;
	public JButton button3;
	public JButton button4;
	public JButton button5;
	public JButton button6;
	public JButton button7;
	public JButton button8;
	public JButton button9;
	public JButton button0;
	public JButton enter;
	
	public GUI(){
		super("ATM");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(600,400);
		setVisible(true);
		
		JPanel panel= new JPanel();
		add(panel);
		panel.setLayout(null);

		JTextArea text=new JTextArea();
		panel.add(text);
		text.setBounds(0,0,300,10000);
		
		MyPrintStream myPrintStream=new MyPrintStream(System.out,text);
		System.setOut(myPrintStream);
		System.setErr(myPrintStream);

		
		JButton button1=new JButton("1");
		panel.add(button1);
		button1.setBounds(350,50,50,50);
		
		JButton button2=new JButton("2");
		panel.add(button2);
		button2.setBounds(410,50,50,50);

		JButton button3=new JButton("3");
		panel.add(button3);
		button3.setBounds(470,50,50,50);

		JButton button4=new JButton("4");
		panel.add(button4);
		button4.setBounds(350,125,50,50);

		JButton button5=new JButton("5");
		panel.add(button5);
		button5.setBounds(410,125,50,50);

		JButton button6=new JButton("6");
		panel.add(button6);
		button6.setBounds(470,125,50,50);
		
		JButton button7=new JButton("7");
		panel.add(button7);
		button7.setBounds(350,200,50,50);
		
		JButton button8=new JButton("8");
		panel.add(button8);
		button8.setBounds(410,200,50,50);
		
		JButton button9=new JButton("9");
		panel.add(button9);
		button9.setBounds(470,200,50,50);
		
		JButton button0=new JButton("0");
		panel.add(button0);
		button0.setBounds(350,275,50,50);
		
		
		JButton enter=new JButton("Enter");
		panel.add(enter);
		enter.setBounds(410,275,100,50);
		
		ButtonHandler handler=new ButtonHandler();
		button1.addActionListener( handler );
		button2.addActionListener( handler );
		button3.addActionListener( handler );
		button4.addActionListener( handler );
		button5.addActionListener( handler );
		button6.addActionListener( handler );
		button7.addActionListener( handler );
		button8.addActionListener( handler );
		button9.addActionListener( handler );
		button0.addActionListener( handler );
		enter.addActionListener( handler );
		
	}
	
	private class ButtonHandler implements ActionListener
	{

		
		public void actionPerformed(ActionEvent event) {
			
			JOptionPane.showMessageDialog(GUI.this,String.format("��Ǹ����ť�Ǽٵģ�\n���ڿ���̨�ü�������!\nYou pressed: %s", event.getActionCommand()));
		}
		
	}
}
