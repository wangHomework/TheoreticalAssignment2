
public class ATMCase {
	public static void main(String[]args){
		new GUI();
		ATM theATM = new ATM();
		theATM.run();
		}
}
