import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;

import javax.swing.*;

;

public class ATMGUI extends JFrame implements ActionListener {
	private float balance = 0;

	public static void main(String args[]) {

		ATMGUI atmgui = new ATMGUI();
		atmgui.setSize(400, 300);
		atmgui.setLocation(400, 300);
		atmgui.setTitle("��ӭ�����������");
		atmgui.setVisible(true);
		// ATM atm=new ATM();
		// atmgui.atm.run();
		// atmgui.setResizable(false);;
		atmgui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	Container c = getContentPane();
	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	JTextArea text = new JTextArea();
	JTextArea text1 = new JTextArea();
	TextField t1 = new TextField(40);
	TextField t2 = new TextField(40);

	JButton b0 = new JButton("0");
	JButton b1 = new JButton("1");
	JButton b2 = new JButton("��Ǯ");
	JButton b3 = new JButton("ȡ��");
	JButton b4 = new JButton("���");
	JButton b5 = new JButton("");
	JButton b6 = new JButton("");
	JButton b7 = new JButton("7");
	JButton b8 = new JButton("8");
	JButton b9 = new JButton("9");
	JButton b10 = new JButton("yes");
	JButton b11 = new JButton("no");
	JButton b12 = new JButton("delet");

	public ATMGUI() {

		setLayout(new FlowLayout(FlowLayout.LEFT));
		add(b0);
		add(b1);
		add(b2);
		add(b3);
		add(b4);
		add(b5);
		add(b6);
		add(b7);
		add(b8);
		add(b9);
		add(b10);
		add(b11);
		add(b12);
		// add(text);
		add(t1);
		add(t2);
		t1.setText("");
		t2.setText("");

		b0.addActionListener(this);

		b1.addActionListener(this);

		b2.addActionListener(this);

		b3.addActionListener(this);

		b4.addActionListener(this);

		b5.addActionListener(this);

		b6.addActionListener(this);

		b7.addActionListener(this);

		b8.addActionListener(this);

		b9.addActionListener(this);

		b10.addActionListener(this);

		b11.addActionListener(this);

		b12.addActionListener(this);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand() == b0.getText()) {
			t2.setText("100");

		}
		if (e.getActionCommand() == b1.getText()) {
			t2.setText("200");

		}
		if (e.getActionCommand() == b4.getText()) {
			t2.setText("��" + String.valueOf(balance));

		}
		if (e.getActionCommand() == b3.getText()) {
			if (Float.parseFloat(t2.getText()) > balance) {
				t2.setText("�������˿ûǮ��");
			} else {
				balance -= Float.parseFloat(t2.getText());
			}
			// t2.setText(String.valueOf(balance));

		}
		if (e.getActionCommand() == b2.getText()) {

			{
				balance += Float.parseFloat(t2.getText());
			}
			// t2.setText(String.valueOf(balance));

		}

	}
}
