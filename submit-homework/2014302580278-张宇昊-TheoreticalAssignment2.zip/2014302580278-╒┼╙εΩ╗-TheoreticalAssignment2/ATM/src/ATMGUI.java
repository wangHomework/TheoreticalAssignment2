import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class ATMGUI {
	private static JFrame mainJF;
	private static JPanel panel;
	private static JTextArea area;			//��ʾ��
	private static JButton btn1;
	private static JButton btn2;
	private static JButton btn3;
	private static JButton btn4;
	private static JButton btn5;
	private static JButton btn6;
	private static JButton btn7;
	private static JButton btn8;
	private static JButton btn9;
	private static JButton btn0;
	private static JButton btnOK;
	private static JButton btnWithdraw;
	private static JButton btnDeposit;
	private static JButton btnExit;
	private static String display;					//��ʾ������
	private static int doingType = 1;				//Ҫ������ʲô��0��û��Ҫ��1ΪID��2Ϊ���룬3Ϊȡ������4Ϊ�����
	static BankDatabase bdb = new BankDatabase();	//�½�һ�����ݿ�
	
	private static String inputWord = "";
	private static String myId = "";
	private static String inputPassword = "";
	private static String myPassword = "";
	private static String movingMoney = "";
	private static String asterisk = "";			//�Ǻ�
	
	
	
	//�������ڿ��
	public static void frame() {
		
		mainJF = new JFrame("ATM");
		mainJF.setBounds(300, 100, 700, 600);
		
		mainJF.setLayout(null);
		mainJF.setResizable(false);
		mainJF.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//�Ϸ���ʾ��
		panel = new JPanel();
		panel.setBounds(50, 50, 600, 200);
		panel.setBackground(Color.getHSBColor(0, 50, 10));
		mainJF.add(panel);
		area = new JTextArea();
		area.setBounds(0, 0, 600, 200);
		area.setBackground(Color.getHSBColor(0, 50, 10));
		Font font = new Font("Serif",0,40);
		area.setFont(font);
		area.setEditable(false);
		panel.add(area);
		
		display = new String("��ӭʹ��ATMϵͳ"+"\n"+"�������û�ID"+"\n");
		area.setText(display);
		
		//���ð�ť
		btn1 = new JButton("1");
		btn1.setBounds(440, 260, 60, 60);
		btn1.paintComponents(null);
		btn1.setVisible(true);
		mainJF.add(btn1);
		
		btn2 = new JButton("2");
		btn2.setBounds(510, 260, 60, 60);
		btn2.paintComponents(null);
		btn2.setVisible(true);
		mainJF.add(btn2);
		
		btn3 = new JButton("3");
		btn3.setBounds(580, 260, 60, 60);
		btn3.paintComponents(null);
		btn3.setVisible(true);
		mainJF.add(btn3);
		
		btn4 = new JButton("4");
		btn4.setBounds(440, 330, 60, 60);
		btn4.paintComponents(null);
		btn4.setVisible(true);
		mainJF.add(btn4);
		
		btn5 = new JButton("5");
		btn5.setBounds(510, 330, 60, 60);
		btn5.paintComponents(null);
		btn5.setVisible(true);
		mainJF.add(btn5);
		
		btn6 = new JButton("6");
		btn6.setBounds(580, 330, 60, 60);
		btn6.paintComponents(null);
		btn6.setVisible(true);
		mainJF.add(btn6);
		
		btn7 = new JButton("7");
		btn7.setBounds(440, 400, 60, 60);
		btn7.paintComponents(null);
		btn7.setVisible(true);
		mainJF.add(btn7);
		
		btn8 = new JButton("8");
		btn8.setBounds(510, 400, 60, 60);
		btn8.paintComponents(null);
		btn8.setVisible(true);
		mainJF.add(btn8);
		
		btn9 = new JButton("9");
		btn9.setBounds(580, 400, 60, 60);
		btn9.paintComponents(null);
		btn9.setVisible(true);
		mainJF.add(btn9);
		
		btn0 = new JButton("0");
		btn0.setBounds(440, 470, 60, 60);
		btn0.paintComponents(null);
		btn0.setVisible(true);
		mainJF.add(btn0);
		
		btnOK = new JButton("OK");
		btnOK.setBounds(510, 470, 130, 60);
		btnOK.paintComponents(null);
		btnOK.setVisible(true);
		mainJF.add(btnOK);
		
		btnWithdraw = new JButton("Withdraw");
		btnWithdraw.setBounds(70, 260, 240, 80);
		btnWithdraw.paintComponents(null);
		btnWithdraw.setVisible(true);
		mainJF.add(btnWithdraw);
		
		btnDeposit = new JButton("Deposit");
		btnDeposit.setBounds(70, 350, 240, 80);
		btnDeposit.paintComponents(null);
		btnDeposit.setVisible(true);
		mainJF.add(btnDeposit);
		
		btnExit = new JButton("Log Out");
		btnExit.setBounds(70, 440, 240, 80);
		btnExit.paintComponents(null);
		btnExit.setVisible(true);
		mainJF.add(btnExit);
		
		mainJF.setVisible(true);
	}
	
	//�������ݣ���textarea��ͬ����ʾ��ͬʱ�����Ϸ�����
	public static void input(){
		area.setText(display);
		inputWord = "";
		inputPassword = "";
		asterisk = "";
		movingMoney = "";
		
		btn1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (doingType){
				case 1:
					inputWord += "1";	
					area.setText(display + inputWord);
					break;
				case 2:
					inputPassword += "1";
					asterisk += "*";
					area.setText(display + asterisk);
					break;
				case 3:
					movingMoney += "1";
					area.setText(display + movingMoney);
					break;
				case 4:
					movingMoney += "1";
					area.setText(display + movingMoney);
					break;
				}
			}
		});
		
		btn2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (doingType){
				case 1:
					inputWord += "2";	
					area.setText(display + inputWord);
					break;
				case 2:
					inputPassword += "2";
					asterisk += "*";
					area.setText(display + asterisk);
					break;
				case 3:
					movingMoney += "2";
					area.setText(display + movingMoney);
					break;
				case 4:
					movingMoney += "2";
					area.setText(display + movingMoney);
					break;
				}
			}
		});
		
		btn3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (doingType){
				case 1:
					inputWord += "3";	
					area.setText(display + inputWord);
					break;
				case 2:
					inputPassword += "3";
					asterisk += "*";
					area.setText(display + asterisk);
					break;
				case 3:
					movingMoney += "3";
					area.setText(display + movingMoney);
					break;
				case 4:
					movingMoney += "3";
					area.setText(display + movingMoney);
					break;
				}
			}
		});
		
		btn4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (doingType){
				case 1:
					inputWord += "4";	
					area.setText(display + inputWord);
					break;
				case 2:
					inputPassword += "4";
					asterisk += "*";
					area.setText(display + asterisk);
					break;
				case 3:
					movingMoney += "4";
					area.setText(display + movingMoney);
					break;
				case 4:
					movingMoney += "4";
					area.setText(display + movingMoney);
					break;
				}
			}
		});
		
		btn5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (doingType){
				case 1:
					inputWord += "5";	
					area.setText(display + inputWord);
					break;
				case 2:
					inputPassword += "5";
					asterisk += "*";
					area.setText(display + asterisk);
					break;
				case 3:
					movingMoney += "5";
					area.setText(display + movingMoney);
					break;
				case 4:
					movingMoney += "5";
					area.setText(display + movingMoney);
					break;
				}
			}
		});
		
		btn6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (doingType){
				case 1:
					inputWord += "6";	
					area.setText(display + inputWord);
					break;
				case 2:
					inputPassword += "6";
					asterisk += "*";
					area.setText(display + asterisk);
					break;
				case 3:
					movingMoney += "6";
					area.setText(display + movingMoney);
					break;
				case 4:
					movingMoney += "6";
					area.setText(display + movingMoney);
					break;
				}
			}
		});
		
		btn7.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (doingType){
				case 1:
					inputWord += "7";	
					area.setText(display + inputWord);
					break;
				case 2:
					inputPassword += "7";
					asterisk += "*";
					area.setText(display + asterisk);
					break;
				case 3:
					movingMoney += "7";
					area.setText(display + movingMoney);
					break;
				case 4:
					movingMoney += "7";
					area.setText(display + movingMoney);
					break;
				}	
			}
		});
		
		btn8.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (doingType){
				case 1:
					inputWord += "8";	
					area.setText(display + inputWord);
					break;
				case 2:
					inputPassword += "8";
					asterisk += "*";
					area.setText(display + asterisk);
					break;
				case 3:
					movingMoney += "8";
					area.setText(display + movingMoney);
					break;
				case 4:
					movingMoney += "8";
					area.setText(display + movingMoney);
					break;
				}
			}
		});
		
		btn9.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (doingType){
				case 1:
					inputWord += "9";	
					area.setText(display + inputWord);
					break;
				case 2:
					inputPassword += "9";
					asterisk += "*";
					area.setText(display + asterisk);
					break;
				case 3:
					movingMoney += "9";
					area.setText(display + movingMoney);
					break;
				case 4:
					movingMoney += "9";
					area.setText(display + movingMoney);
					break;
				}	
			}
		});
		
		btn0.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (doingType){
				case 1:
					inputWord += "0";	
					area.setText(display + inputWord);
					break;
				case 2:
					inputPassword += "0";
					asterisk += "*";
					area.setText(display + asterisk);
					break;
				case 3:
					movingMoney += "0";
					area.setText(display + movingMoney);
					break;
				case 4:
					movingMoney += "0";
					area.setText(display + movingMoney);
					break;
				}
			}
		});
		
		btnExit.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				mainJF.dispose();
				doingType = 1;
				frame();
				input();
			}
		});
		
		btnOK.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (doingType){
				case 1:
					myId = inputWord;
					doingType ++;
					display = "��������������"+"\n";
					area.setText(display);
					break;
				case 2:
					myPassword = inputPassword;
					display = "���ã�";
					mainMenu();
					break;
				case 3:
					doingType = 0;
					if(Integer.parseInt(movingMoney) <= bdb.getAccount(Integer.parseInt(myId)).getAvailableBalance()){
						bdb.getAccount(Integer.parseInt(myId)).availableBalance -= Double.parseDouble(movingMoney);
						display = "ȡ��ɹ����������Ǯ��\n�ǲ����Ѿ�����" + movingMoney + "��Ǯ�ˣ�\n���ȷ����������";
						
						btnOK.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								// TODO Auto-generated method stub
								display = "�㻹�濴������";
								mainMenu();
							}
						});
					}
					else{
						display = "û��ô��Ǯ��";
						mainMenu();
					}
					area.setText(display);
					break;
				case 4:
					doingType = 0;
					bdb.getAccount(Integer.parseInt(myId)).availableBalance += Double.parseDouble(movingMoney);
					display = "���ɹ���";
					inputWord = myId;
					mainMenu();
				}
				return;
			}	
		});
		return;
	}
	
	//������½������˵�
	public static void mainMenu(){
		if(bdb.authenticateUser(Integer.parseInt(myId), Integer.parseInt(myPassword)))
		{
			doingType = 0;
			Account myAcc = bdb.getAccount(Integer.parseInt(myId));
			display += "���������" + myAcc.getAvailableBalance() + "\n" + "��ѡ���ȡ��ҵ����˳���½";
			area.setText(display);
			
			//������ȡ��
			btnWithdraw.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					mainJF.dispose();
					doingType = 3;
					frame();
					display = "������ȡ����" + "\n";
					input();
				}
			});
			
			//���������
			btnDeposit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					mainJF.dispose();
					doingType = 4;
					frame();
					display = "����������" + "\n";
					input();
				}
			});
		}
		else
		{
			mainJF.dispose();
			frame();
			display = "�������"+"\n"+"�����������û�ID"+"\n";
			doingType --;
			input();
		}
	}
	
	public static void main(String[] args) {	
		frame();
		input();
	}
}

